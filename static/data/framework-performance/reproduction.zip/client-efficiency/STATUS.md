# Client CPU hardware-efficiency campaign

2026-10-29 02:47 UTC: all seven measurements complete and copied to laptop. Raw committed-order/CPU calculations, binary hashes, affinity, session continuity, settings/schema and all195file cold restores verified. Original MySQL active again; PostgreSQL and all campaign MySQL instances inactive. Original AppArmor policy byte-restored, no running campaign units, no temporary inter-host keys created. Final archive/catalog/copy receipts are separate sibling files.

## Results

Fresh SF1000/32worker/localTCP cases,60s warm-up+120s planned measurement, approximately115s complete counter windows. One invocation per tool/core budget, no confidence intervals. Physical client cores1/2; DB48cores unchanged.

Committed New-Orders/s:
- Native go-tpc with reusable statements: one core1574.65; two cores2180.59.
- Native go-tpc without statement reuse: one core760.63; two cores1133.97.
- Stroppy go-tpc port: one core753.44; two cores1161.19.
- Fresh eight-core native-reuse DB-headroom control:6208.05/s.

Orders per client CPU-second:
- Native reuse:1585.27(one core),1554.96(two).
- Native no-reuse:761.16(one),742.81(two).
- Stroppy:754.03(one),728.40(two).

All three one-core clients used99.3–99.9%of their budget. Fresh eight-core control establishes DB can handle much more than low-core cases. One-core results therefore support client-CPU efficiency comparison: native reuse about2xorders/CPU-second; Stroppy and no-reuse native close. Stroppy throughput -0.9%atonecore,+2.4%attwocores versus native no-reuse; slightly higher throughput is not higher CPU efficiency.

Strict predeclared cross-budget client-limit gate failed for every tool: two-core utilization only70.1%native reuse,76.3%native no-reuse,79.7%Stroppy, below90%threshold. Throughput gains1.38x/1.49x/1.54x and fresh control2.85–5.47xfaster still show DB headroom; two-core cases have mixed limits, not proven fully CPU-bound. No global DB-ceiling or cause-isolation claim.

## Evidence and preservation

`summaries/results.md`,JSON,CSV,verification.json andruntime.html retain results/decision gates/limitations. Per-case raw samples, CPUticks/clockrate, timing, commands, affinity, stdout/stderr and deadline classifications live under `remote/bm1/runs/`. SDK raw reports remain `completed_with_errors`; native/SDKdeadline cancellations remain disclosed. Zero in-window sampler errors,32sessions present, no log/free-buffer waits. CPU costs cover process user+systemtime, not energy or uncharged host IRQ/softirq/observer work.

New remote `/opt/stroppy-client-efficiency-20261029`; working datadir `/storage1/stroppy-client-efficiency-20261029/mysql/work`. Earlier read-only go-tpc template source preserved; previous campaigns/archives untouched. No baseline reruns substituted for fresh control, binary changes, publication, repository commits, dataset deletion or rental cancellation.
