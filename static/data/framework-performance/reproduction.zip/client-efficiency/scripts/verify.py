#!/usr/bin/env python3
"""Verify each efficiency metric against the same raw CPU and committed-order samples."""
import argparse
import datetime
import hashlib
import json
import math
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('root',type=Path)
args=parser.parse_args()
root=args.root
load=lambda path:json.loads(path.read_text())
report=load(root/'summaries/results.json')
assert report['status']=='complete' and report['completed_cases']==7
base_variables=(root/'manifests/baseline-mysql-variables.txt').read_text()
base_schema=(root/'manifests/baseline-schema.sql').read_bytes()
manifest=load(root/'manifests/go-tpc-snapshot.json')
windows=[]
checks=[]
for spec_path in sorted((root/'specs').glob('[0-9][0-9]-*.json')):
    spec=load(spec_path)
    directory=root/'remote/bm1/runs'/spec['id']
    assert load(directory/'spec.json')==spec
    summary=load(directory/'summary.json')
    assert summary['valid'] and summary['sample_errors']==0
    meta=load(directory/'meta.json')
    assert meta['exit_code']==0 and not meta.get('watchdog_expired')
    assert meta['environment']['GOMAXPROCS']==str(spec['client_cores'])
    assert meta['command'][:3]==['taskset','-c',spec['client_cpuset']]
    executable=Path(meta['command'][3]).name
    assert meta['binary_sha256']==load(root/'manifests/binaries.json')[executable]
    classification=load(directory/'completion-classification.json')
    assert classification.get('measurement_valid',classification.get('valid_completion',False))
    records=[json.loads(line) for line in (directory/'monitor/samples.jsonl').read_text().splitlines()]
    assert not any('sample_error' in row for row in records)
    measured=[row for row in records if spec['warmup_seconds']<=datetime.datetime.fromisoformat(row['utc']).timestamp()-meta['started_epoch']<=spec['warmup_seconds']+spec['measurement_seconds'] and 'mysql' in row]
    assert len(measured)>=22 and all(sum(line.startswith('bench\t') for line in row.get('sessions',[]))==32 for row in measured)
    assert all(0<after['monotonic']-before['monotonic']<8 for before,after in zip(measured,measured[1:]))
    first,last=measured[0],measured[-1]
    seconds=last['monotonic']-first['monotonic']
    orders=last['new_orders']-first['new_orders']
    assert seconds>=109 and orders==summary['committed_new_orders']
    assert math.isclose(orders/seconds,summary['new_orders_per_second'],rel_tol=1e-12)
    for key,label,cpuset in [('client.pid','client',spec['client_cpuset']),('mysql.pid','database',spec['database_cpuset'])]:
        assert all(row[key]['allowed_cpus']==cpuset for row in measured)
        assert len({row[key]['pid'] for row in measured})==1
        ticks=lambda row:row[key]['utime_ticks']+row[key]['stime_ticks']
        cpu=(ticks(last)-ticks(first))/last['clock_ticks_per_second']
        assert math.isclose(cpu,summary[label+'_cpu_seconds'],rel_tol=1e-12)
        assert math.isclose(cpu*1e6/orders,summary[label+'_cpu_microseconds_per_new_order'],rel_tol=1e-12)
    restore=root/'remote/bm1/restores'/spec['id']
    reset=load(restore/'complete.json')
    assert reset['server_stopped'] and reset['verified_files']==len(manifest['files'])
    assert reset['template']=='/storage1/stroppy-tpcc-headtohead-20261028/mysql/template-go-tpc'
    assert (restore/'schema.sql').read_bytes()==base_schema
    normalized=(restore/'mysql-config.txt').read_text().replace('stroppy-client-efficiency-20261029','stroppy-tpcc-headtohead-20261028')
    assert normalized==base_variables,'effective server settings differ beyond campaign paths'
    for key,value in summary['statement_counter_deltas'].items():
        assert value==last['mysql'][key]-first['mysql'][key]
    if spec['tool']=='stroppy':
        raw=load(directory/'report.json')
        assert raw['status']==meta['raw_report_status'] and raw.get('errors')==meta.get('errors')
    windows.append((meta['started_epoch'],meta['finished_epoch']))
    checks.append({'id':spec['id'],'raw_orders_cpu_verified':True,'settings_schema_template_matched':True,'binary_hash':meta['binary_sha256']})
windows.sort()
assert all(a[1]<=b[0] for a,b in zip(windows,windows[1:]))
cleanup=load(root/'remote/bm1/cleanup/complete.json')
assert cleanup['status']=='seven_cases_complete_original_services_restored'
for name,expected in load(root/'manifests/binaries.json').items():
    with (root/'artifacts'/name).open('rb') as stream:
        assert hashlib.file_digest(stream,'sha256').hexdigest()==expected
receipt={'status':'verified','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':checks,'no_client_overlap':True,'cleanup':cleanup,'cpu_cost_scope':'process user+system CPU time; not whole-host energy or uncharged IRQ/softirq work','single_invocation_per_budget':True}
(root/'summaries/verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'verified','cases':len(checks)}))
