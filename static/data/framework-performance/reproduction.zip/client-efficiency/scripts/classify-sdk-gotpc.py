#!/usr/bin/env python3
"""Check SDK deadline-only operation/connection-cleanup failures without changing reports."""
import argparse
import datetime
import json
from pathlib import Path
import re


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    args = parser.parse_args()
    spec = json.loads((args.run / 'spec.json').read_text())
    meta = json.loads((args.run / 'meta.json').read_text())
    report = json.loads((args.run / 'report.json').read_text())
    duration = spec['warmup_seconds'] + spec['measurement_seconds']
    deadline = meta['started_epoch'] + duration
    stderr = (args.run / 'stderr.log').read_text()
    warnings = []
    reasons = []
    for line in stderr.splitlines():
        if '\tWARN\t' not in line and '\tERROR\t' not in line:
            continue
        match = re.match(r'^(\S+)\s', line)
        if not match:
            reasons.append('untimed warning/error line')
            continue
        stamp = datetime.datetime.fromisoformat(match[1]).timestamp()
        warnings.append({'utc': match[1], 'seconds_from_deadline': stamp-deadline, 'line': line})
        if abs(stamp-deadline) > 2 or 'sql: connection is already closed' not in line:
            reasons.append('warning/error not the verified deadline connection-close signature')
    errors = report.get('errors', {})
    if errors.get('failed_queries') != 0 or errors.get('retry_attempts') != 0:
        reasons.append('unexpected query failure/retry counters')
    groups = errors.get('groups', [])
    if any(group.get('operation') != 'run' or group.get('class') != 'unknown' for group in groups):
        reasons.append('unexpected terminal error group')
    if errors.get('terminal_errors', 0) > spec['active_clients'] or errors.get('failed_iterations') != errors.get('terminal_errors'):
        reasons.append('terminal cleanup count cannot be bounded to workers')
    contribution = next(item['data'] for item in report['workload_reports'] if item['kind'] == 'go-tpc.tpcc')
    failed_operations = sum(contribution['failed'])
    if failed_operations > spec['active_clients']:
        reasons.append('more than one final failed operation per worker')
    execution = report['executions']['run']
    if not duration-1 <= execution['measurement_seconds'] <= duration+3:
        reasons.append('executor did not finish at the agreed time budget')
    if meta.get('exit_code') != 0 or not deadline-1 <= meta.get('finished_epoch', 0) <= deadline+5:
        reasons.append('client failed or ended outside timeout boundary')
    records = [json.loads(line) for line in (args.run / 'monitor/samples.jsonl').read_text().splitlines()]
    observed = []
    for row in records:
        elapsed = datetime.datetime.fromisoformat(row['utc']).timestamp() - meta['started_epoch']
        if spec['warmup_seconds'] <= elapsed <= duration-5:
            sessions = sum(line.startswith('bench\t') for line in row.get('sessions', []))
            observed.append(sessions)
            if 'sample_error' in row or sessions != spec['active_clients']:
                reasons.append('in-window worker/session continuity not verified')
    if len(observed) < spec['measurement_seconds']//5-3:
        reasons.append('insufficient complete in-window samples')
    if errors.get('terminal_errors', 0) and not warnings:
        reasons.append('reported cleanup errors lack timestamped evidence')
    result = {'measurement_valid': not reasons, 'classification': 'budget_boundary_operations_and_connection_cleanup' if not reasons else 'invalid', 'raw_report_status': report['status'], 'boundary_failed_operations': failed_operations, 'boundary_terminal_cleanup_errors': errors.get('terminal_errors'), 'failed_queries': errors.get('failed_queries'), 'minimum_in_window_sessions': min(observed, default=0), 'timestamped_warnings': warnings, 'reasons': sorted(set(reasons)), 'rule': 'ignore-error=false; full worker session continuity; no early warnings; at most one final failed operation/cleanup per worker; reported close errors and executor completion at exact budget deadline; raw JSON and error counts unchanged'}
    (args.run / 'completion-classification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    raise SystemExit(0 if result['measurement_valid'] else 1)


if __name__ == '__main__':
    main()
