#!/usr/bin/env python3
"""Hash campaign evidence after writes finish; exclude private control material."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile

EXCLUDED = {'client_ed25519', 'authorized_keys-before', 'transport-authorized-key', 'mysql.sock', 'mysql.sock.lock', 'mysql.pid'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('archive', type=Path)
    args = parser.parse_args()
    if args.archive.exists():
        raise FileExistsError(args.archive)
    files = []
    for path in sorted(args.root.rglob('*')):
        if not path.is_file() or any(part in EXCLUDED for part in path.parts) or '__pycache__' in path.parts or path == args.root / 'summaries/evidence-manifest.json':
            continue
        if path.is_symlink() and not path.resolve().is_relative_to(args.root.resolve()):
            raise RuntimeError('archive symlink escapes evidence root: ' + str(path))
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            while block := stream.read(8 * 1024 * 1024):
                digest.update(block)
        files.append({'path': str(path.relative_to(args.root)), 'size': path.stat().st_size, 'sha256': digest.hexdigest()})
    manifest = args.root / 'summaries/evidence-manifest.json'
    manifest.write_text(json.dumps({'files': files}, indent=2) + '\n')
    with tarfile.open(args.archive, 'x:gz') as output:
        for item in files:
            output.add(args.root / item['path'], arcname=item['path'], recursive=False)
        output.add(manifest, arcname='summaries/evidence-manifest.json', recursive=False)
    digest = hashlib.sha256()
    with args.archive.open('rb') as stream:
        while block := stream.read(8 * 1024 * 1024):
            digest.update(block)
    args.archive.with_suffix(args.archive.suffix + '.sha256').write_text(digest.hexdigest() + '  ' + args.archive.name + '\n')
    print(json.dumps({'files': len(files), 'archive_bytes': args.archive.stat().st_size, 'sha256': digest.hexdigest()}))


if __name__ == '__main__':
    main()
