#!/usr/bin/env python3
"""Copy finished efficiency measurements and stop on an external terminal state."""
import argparse
import json
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parent.parent
REMOTE='/opt/stroppy-client-efficiency-20261029'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','-i','/Users/ariel/.ssh/ssh-key-postgres-august','root@185.184.128.203']
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--until-cases',type=int,default=0)
args=parser.parse_args()
seen=set()
for attempt in range(120):
    try:
        probe=subprocess.run(SSH+[f"find {REMOTE}/runs -maxdepth 2 -name summary.json -printf '%h\\n'; systemctl show bench-efficiency-campaign -p ActiveState; test ! -f {REMOTE}/cleanup/complete.json || printf 'RESTORED\\n'"],capture_output=True,text=True,timeout=60)
        if probe.returncode:
            raise RuntimeError(probe.stderr)
        lines=probe.stdout.splitlines()
        completed={line for line in lines if line.startswith(REMOTE+'/runs/')}
        terminal='ActiveState=failed' in lines or 'RESTORED' in lines
        if completed-seen or terminal or attempt==0:
            destination=ROOT/'remote/bm1'
            destination.mkdir(parents=True,exist_ok=True)
            subprocess.run(['rsync','-az','--exclude=artifacts/','--exclude=homes/','--exclude=mysql.sock','--exclude=mysql.sock.lock','--exclude=mysql.pid','-e','ssh -i /Users/ariel/.ssh/ssh-key-postgres-august',f'root@185.184.128.203:{REMOTE}/',str(destination)+'/'],check=True,timeout=180)
            subprocess.run(['python3','-I',str(ROOT/'scripts/report.py'),str(ROOT)],check=True)
            seen|=completed
            print(json.dumps({'completed_cases':len(completed),'states':[line for line in lines if not line.startswith('/')]}),flush=True)
        if 'ActiveState=failed' in lines:
            raise SystemExit('Efficiency supervisor failed; diagnose preserved evidence before resuming')
        if 'RESTORED' in lines or args.until_cases and len(completed)>=args.until_cases:
            break
    except (RuntimeError,subprocess.TimeoutExpired,subprocess.CalledProcessError) as error:
        print('Observation failed; remote work not restarted: '+str(error),flush=True)
    time.sleep(120)
else:
    raise SystemExit('Local observation deadline reached; remote work remains independent')
