#!/usr/bin/env python3
"""Run the bounded core-budget matrix and restore original MySQL and confinement."""
import datetime
import json
from pathlib import Path
import subprocess
import time

ROOT=Path('/opt/stroppy-client-efficiency-20261029')
for spec in sorted((ROOT/'specs').glob('[0-9][0-9]-*.json')):
    value=json.loads(spec.read_text())
    directory=ROOT/'runs'/value['id']
    assert not directory.exists(),'existing run requires diagnosis'
    subprocess.run(['python3','-I',str(ROOT/'scripts/run.py'),str(spec)],check=True)
    summaries=[json.loads(path.read_text()) for path in (ROOT/'runs').glob('*/summary.json')]
    (ROOT/'STATUS-RUNTIME.json').write_text(json.dumps({'completed_cases':len(summaries),'target_cases':7,'last_completed':value['id']},indent=2)+'\n')
subprocess.run(['systemctl','stop','bench-client-efficiency-mysql'],check=True)
policy=Path('/etc/apparmor.d/local/usr.sbin.mysqld')
assert policy.read_bytes()==(ROOT/'inventory/apparmor-during').read_bytes()
policy.write_bytes((ROOT/'inventory/apparmor-original').read_bytes())
subprocess.run(['apparmor_parser','-r','/etc/apparmor.d/usr.sbin.mysqld'],check=True)
subprocess.run(['systemctl','start','bench-mysql'],check=True)
deadline=time.monotonic()+360
while subprocess.run(['mysqladmin','--socket=/run/mysqld/bench.sock','ping'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
    assert time.monotonic()<deadline,'original MySQL readiness timeout'
    time.sleep(2)
services={name:subprocess.run(['systemctl','is-active',name],capture_output=True,text=True).stdout.strip() for name in ['bench-mysql','bench-postgres','bench-client-efficiency-mysql','bench-tpcc-headtohead-mysql','bench-gotpc-noreuse-mysql']}
assert services=={'bench-mysql':'active','bench-postgres':'inactive','bench-client-efficiency-mysql':'inactive','bench-tpcc-headtohead-mysql':'inactive','bench-gotpc-noreuse-mysql':'inactive'}
(ROOT/'cleanup').mkdir()
(ROOT/'cleanup/complete.json').write_text(json.dumps({'status':'seven_cases_complete_original_services_restored','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'services':services,'apparmor_original_restored':True,'interhost_keys_created':False},indent=2)+'\n')
