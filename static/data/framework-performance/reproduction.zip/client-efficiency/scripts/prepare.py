#!/usr/bin/env python3
"""Stage matched low-core client-efficiency specifications and proven evidence helpers."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent.parent
OLD = ROOT.with_name('stroppy-tpcc-headtohead-20261028')
FOLLOWUP = ROOT.with_name('stroppy-gotpc-noreuse-20261028')
REMOTE = '/opt/stroppy-client-efficiency-20261029'
for source, names in [(OLD, ['sampler.py','classify-sdk-gotpc.py','archive-evidence.py']), (FOLLOWUP, ['snapshot.py','classify-gotpc.py','setup-server.py'])]:
    for name in names:
        text = (source/'scripts'/name).read_text()
        if name == 'snapshot.py':
            text = text.replace("ROOT = Path('/opt/stroppy-gotpc-noreuse-20261028')", f"ROOT = Path('{REMOTE}')").replace("WORK = Path('/storage1/stroppy-gotpc-noreuse-20261028/mysql/work')", "WORK = Path('/storage1/stroppy-client-efficiency-20261029/mysql/work')").replace("UNIT = 'bench-gotpc-noreuse-mysql'", "UNIT = 'bench-client-efficiency-mysql'")
        else:
            text = text.replace('stroppy-tpcc-headtohead-20261028', 'stroppy-client-efficiency-20261029').replace('stroppy-gotpc-noreuse-20261028','stroppy-client-efficiency-20261029').replace('bench-gotpc-noreuse-mysql','bench-client-efficiency-mysql')
        if name == 'sampler.py':
            text = text.replace('STATUS = [', 'STATUS = ["Com_stmt_prepare", "Com_stmt_execute", "Com_stmt_close", "Com_stmt_reprepare", "Prepared_stmt_count", ')
        if name == 'classify-gotpc.py':
            text = text.replace("if spec['statement_reuse'] is False:", "if True:")
        if name == 'setup-server.py':
            text = text.replace("('bench-postgres', 'bench-tpcc-headtohead-mysql', 'bench-client-efficiency-mysql')", "('bench-postgres', 'bench-tpcc-headtohead-mysql', 'bench-gotpc-noreuse-mysql', 'bench-client-efficiency-mysql')")
        (ROOT/'scripts'/name).write_text(text)
(ROOT/'configs/mysql.cnf').write_text((OLD/'configs/mysql.cnf').read_text().replace('stroppy-tpcc-headtohead-20261028','stroppy-client-efficiency-20261029'))
(ROOT/'configs/bench-client-efficiency-mysql.service').write_text((OLD/'configs/bench-tpcc-headtohead-mysql.service').read_text().replace('stroppy-tpcc-headtohead-20261028','stroppy-client-efficiency-20261029').replace('TPC-C head-to-head campaign','client CPU efficiency test'))
for name in ['go-tpc-snapshot.json']:
    shutil.copy2(OLD/'remote/bm1/manifests'/name,ROOT/'manifests'/name)
shutil.copy2(OLD/'remote/bm1/restores/tpcc-headtohead-20261028-go-tpc-local-original-r1/mysql-config.txt',ROOT/'manifests/baseline-mysql-variables.txt')
shutil.copy2(OLD/'remote/bm1/restores/tpcc-headtohead-20261028-go-tpc-local-original-r1/schema.sql',ROOT/'manifests/baseline-schema.sql')
for origin,name in [(OLD/'artifacts/go-tpc-a9ca481/go-tpc','go-tpc'),(OLD/'artifacts/stroppy-5210a29/unpacked/stroppy','stroppy'),(FOLLOWUP/'artifacts/go-tpc-noreuse','go-tpc-noreuse')]:
    shutil.copy2(origin,ROOT/'artifacts'/name)
    (ROOT/'artifacts'/name).chmod(0o755)
for source,name in [(OLD/'summaries/results.json','earlier-headtohead-results.json'),(FOLLOWUP/'summaries/results.json','earlier-noreuse-results.json'),(FOLLOWUP/'artifacts/no-reuse.patch','no-reuse.patch'),(FOLLOWUP/'artifacts/buildinfo.json','no-reuse-buildinfo.json')]:
    shutil.copy2(source,ROOT/'artifacts'/name)
checks={name:hashlib.sha256((ROOT/'artifacts'/name).read_bytes()).hexdigest() for name in ['go-tpc','go-tpc-noreuse','stroppy']}
(ROOT/'manifests/binaries.json').write_text(json.dumps(checks,indent=2)+'\n')
order=[(1,'native_reuse'),(1,'native_no_reuse'),(1,'stroppy'),(2,'stroppy'),(2,'native_no_reuse'),(2,'native_reuse')]
for index,(cores,tool) in enumerate(order,1):
    spec={'id':f'efficiency-20261029-{tool}-{cores}core','tool':tool,'client_cores':cores,'client_cpuset':'24' if cores==1 else '24-25','database_cpuset':'0-23,32-55','database_cores':48,'observer_cpuset':'56-59','warmup_seconds':60,'measurement_seconds':120,'active_clients':32,'database':'gotpc_sf1000','statement_reuse':tool=='native_reuse','placement':'local_tcp','warehouses':1000,'go_max_procs':cores}
    (ROOT/'specs'/f'{index:02d}-{spec["id"]}.json').write_text(json.dumps(spec,indent=2)+'\n')
print(json.dumps({'cases':6,'binaries':checks}))
