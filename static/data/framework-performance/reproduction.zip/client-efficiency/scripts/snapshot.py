#!/usr/bin/env python3
"""Restore a new working datadir from the preserved, verified cold go-tpc template."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/opt/stroppy-client-efficiency-20261029')
WORK = Path('/storage1/stroppy-client-efficiency-20261029/mysql/work')
TEMPLATE = Path('/storage1/stroppy-tpcc-headtohead-20261028/mysql/template-go-tpc')
UNIT = 'bench-client-efficiency-mysql'


def digest(directory):
    records = []
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            with path.open('rb') as stream:
                value = hashlib.file_digest(stream, 'sha256').hexdigest()
            records.append({'path': str(path.relative_to(directory)), 'size': path.stat().st_size, 'sha256': value})
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['restore'])
    parser.add_argument('family', choices=['go-tpc'])
    parser.add_argument('record', type=Path)
    args = parser.parse_args()
    assert ROOT in args.record.resolve().parents
    args.record.mkdir(parents=True, exist_ok=False)
    assert shutil.disk_usage(WORK.parent).free >= 1024**4
    subprocess.run(['systemctl', 'stop', UNIT], check=True)
    assert subprocess.run(['systemctl', 'is-active', '--quiet', UNIT]).returncode != 0
    expected = json.loads((ROOT / 'manifests/go-tpc-snapshot.json').read_text())['files']
    assert digest(TEMPLATE) == expected, 'preserved template changed'
    assert not WORK.is_symlink() and WORK.resolve() == WORK
    subprocess.run(['rsync', '-aH', '--delete', '--numeric-ids', str(TEMPLATE)+'/', str(WORK)+'/'], check=True)
    subprocess.run(['chmod', '-R', 'u+w', str(WORK)], check=True)
    subprocess.run(['chown', '-R', 'mysql:mysql', str(WORK)], check=True)
    assert digest(WORK) == expected, 'working copy differs from template'
    (args.record / 'complete.json').write_text(json.dumps({'action': 'restore', 'family': 'go-tpc', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'template': str(TEMPLATE), 'destination': str(WORK), 'server_stopped': True, 'verified_files': len(expected)}, indent=2)+'\n')
    subprocess.run(['systemctl', 'start', UNIT], check=True)
    deadline = time.monotonic()+600
    while subprocess.run(['mysqladmin', '--socket='+str(ROOT/'mysql.sock'), 'ping'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode:
        assert time.monotonic() < deadline, 'restored MySQL did not become ready'
        time.sleep(2)


if __name__ == '__main__':
    main()
