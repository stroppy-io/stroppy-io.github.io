#!/usr/bin/env python3
"""Report per-core throughput and CPU cost without assuming an idle DB proves headroom."""
import argparse
import csv
import json
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('root',type=Path)
args=parser.parse_args()
root=args.root
rows=[json.loads(path.read_text()) for path in sorted((root/'remote/bm1/runs').glob('*/summary.json'))]
assert all(row['valid'] for row in rows)
output=root/'summaries'
output.mkdir(exist_ok=True)
by_key={(row['tool'],row['client_cores']):row for row in rows}
control=by_key.get(('native_reuse',8))
scaling=[]
for tool in ['native_reuse','native_no_reuse','stroppy']:
    one,two=by_key.get((tool,1)),by_key.get((tool,2))
    if not one or not two:
        continue
    gain=two['new_orders_per_second']/one['new_orders_per_second']
    saturated=min(one['client_core_utilization_fraction'],two['client_core_utilization_fraction'])>=0.90
    db_more=control is not None and control['new_orders_per_second']>=two['new_orders_per_second']*1.2
    scaling.append({'tool':tool,'one_to_two_core_throughput_ratio':gain,'parallel_scaling_efficiency':gain/2,'both_client_budgets_at_least_90_percent_utilized':saturated,'fresh_native_8core_db_headroom_ratio':control['new_orders_per_second']/two['new_orders_per_second'] if control else None,'client_bound_evidence_passed':saturated and gain>=1.3 and db_more,'criterion':'client process CPU >=90% of allocated physical cores at both budgets; throughput >=1.3x with two cores; fresh 8core control drives same DB >=1.2x faster; per-case sample/session/redo gates pass'})
report={'status':'complete' if len(rows)==7 else 'in_progress','completed_cases':len(rows),'planned_cases':7,'cases':rows,'scaling':scaling,'fresh_db_headroom_control':control,'limitations':['Single short invocation per tool/core budget; no confidence intervals.','60s warmup and 120s planned window; exact complete sample boundaries retained.','Local TCP only; no simulated latency.','CPU costs are client/database process CPU time, excluding separately charged host IRQ/kernel work and observers.','Expected rollback and all successful/failed workload work consume CPU; denominator is committed district-counter New-Orders.','Reusable statements are an end-to-end client-path advantage; native no-reuse provides closer transport comparison, not identical SDK internals.','Deadline errors remain classified separately; valid measurement is not a clean full run.']}
(output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Client hardware-utilization efficiency','',f"Status: {report['status']}; {len(rows)}/7 cases.",'','Higher New-Orders/s and orders/client CPU-second are better; lower CPU microseconds/order are better. All rows are fresh runs, not earlier controls.','', '| Tool | Client physical cores | New-Orders/s | Orders/s/allocated core | Client utilization | Orders/client CPU-second | Client CPU us/order | DB CPU cores used | DB CPU us/order |','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
labels={'native_reuse':'Native go-tpc, reusable statements','native_no_reuse':'Native go-tpc, no statement reuse','stroppy':'Stroppy go-tpc port'}
for cores in [1,2,8]:
    for tool in labels:
        row=by_key.get((tool,cores))
        if row:
            lines.append(f"| {labels[tool]} | {cores} | {row['new_orders_per_second']:,.1f} | {row['new_orders_per_allocated_client_core_second']:,.1f} | {100*row['client_core_utilization_fraction']:.1f}% | {row['new_orders_per_client_cpu_second']:,.1f} | {row['client_cpu_microseconds_per_new_order']:.1f} | {row['database_cpu_equivalent_cores']:.2f} / 48 | {row['database_cpu_microseconds_per_new_order']:.1f} |")
lines += ['', '## Client-limit evidence','']
for value in scaling:
    lines.append(f"- {labels[value['tool']]}: two/one-core throughput {value['one_to_two_core_throughput_ratio']:.3f}x; doubling efficiency {100*value['parallel_scaling_efficiency']:.1f}%; both client budgets >=90% utilized: {value['both_client_budgets_at_least_90_percent_utilized']}; fresh DB-headroom ratio: {value['fresh_native_8core_db_headroom_ratio']}; client-bound evidence passed: {value['client_bound_evidence_passed']}.")
lines += ['', 'The 8-core native-reuse row is a database-headroom control, not an additional same-budget competitor. A failed criterion is inconclusive, not permission to call the DB the bottleneck. No global maximum DB-throughput claim.']
if len(rows)==7:
    lines += ['', '## Interpretation', '', 'One-core client utilization is 99–100% for all three paths, while the fresh control drives the same database at 6,208 committed New-Orders/s. These observations support a client-CPU-constrained comparison at one core, not a database throughput ceiling.', '', 'Native go-tpc with reusable statements delivers about twice the committed orders per client CPU-second of either no-reuse path. Stroppy and native without reuse are close: Stroppy throughput is 0.9% lower at one core and 2.4% higher at two; its orders/client CPU-second are about 1% and 2% lower respectively. A small throughput advantage at two cores is not a CPU-efficiency win.', '', 'The predeclared strict cross-budget criterion did not pass for any tool: two-core client utilization is only 70–80%, despite throughput increasing 1.38–1.54x and the database-headroom control being 2.85–5.47x faster. Two-core runs have mixed limits; this experiment does not isolate scheduling, synchronization, I/O or other causes. Do not call both budgets fully CPU-bound.']
lines += ['', '## Deadline errors','']
for row in rows:
    c=row['completion_classification']
    lines.append(f"- {row['id']}: query cancellations={c.get('boundary_query_errors',c.get('boundary_failed_operations',0))}, connection checks={c.get('boundary_connection_errors',0)}, cleanup={c.get('boundary_terminal_cleanup_errors',0)}; raw status={row['raw_client_status']}.")
lines += ['', '## Limits','']+['- '+item for item in report['limitations']]
(output/'results.md').write_text('\n'.join(lines)+'\n')
if rows:
    with (output/'cases.csv').open('w') as stream:
        fields=list(dict.fromkeys(key for row in rows for key in row))
        writer=csv.DictWriter(stream,fields)
        writer.writeheader()
        writer.writerows(rows)
print(json.dumps({'status':report['status'],'completed_cases':len(rows),'rates':[{'tool':row['tool'],'cores':row['client_cores'],'new_orders_per_second':row['new_orders_per_second'],'client_utilization':row['client_core_utilization_fraction']} for row in rows]}))
