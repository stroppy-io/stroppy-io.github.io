#!/usr/bin/env python3
"""Measure committed progress and client/database CPU cost over identical sample boundaries."""
import argparse
import datetime
import json
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('run',type=Path)
args=parser.parse_args()
spec=json.loads((args.run/'spec.json').read_text())
meta=json.loads((args.run/'meta.json').read_text())
classification=json.loads((args.run/'completion-classification.json').read_text())
assert meta['exit_code']==0 and not meta.get('watchdog_expired')
assert classification.get('measurement_valid',classification.get('valid_completion',False))
records=[json.loads(line) for line in (args.run/'monitor/samples.jsonl').read_text().splitlines()]
assert not any('sample_error' in row for row in records)
end=spec['warmup_seconds']+spec['measurement_seconds']
measured=[row for row in records if spec['warmup_seconds'] <= datetime.datetime.fromisoformat(row['utc']).timestamp()-meta['started_epoch'] <= end and 'mysql' in row]
assert len(measured)>=spec['measurement_seconds']//5-2
assert all(sum(line.startswith('bench\t') for line in row['sessions'])==spec['active_clients'] for row in measured)
assert all(0<after['monotonic']-before['monotonic']<8 for before,after in zip(measured,measured[1:]))
first,last=measured[0],measured[-1]
seconds=last['monotonic']-first['monotonic']
assert seconds>=spec['measurement_seconds']-11
orders=last['new_orders']-first['new_orders']
assert orders>0
cost={}
for key in ('client.pid','mysql.pid'):
    assert all(row.get(key) for row in measured),key
    assert len({row[key]['pid'] for row in measured})==1,key
    ticks=lambda row: row[key]['utime_ticks']+row[key]['stime_ticks']
    cpu_seconds=(ticks(last)-ticks(first))/last['clock_ticks_per_second']
    assert cpu_seconds>0
    label='client' if key=='client.pid' else 'database'
    cost[label+'_cpu_seconds']=cpu_seconds
    cost[label+'_cpu_equivalent_cores']=cpu_seconds/seconds
    cost[label+'_cpu_microseconds_per_new_order']=cpu_seconds*1e6/orders
    cost[label+'_peak_rss_mib']=max(row[key]['rss_kib'] for row in measured)/1024
    assert all(row[key]['allowed_cpus']==spec['client_cpuset' if key=='client.pid' else 'database_cpuset'] for row in measured),(key,'unexpected affinity')
deltas={key:last['mysql'][key]-first['mysql'][key] for key in ('Com_stmt_prepare','Com_stmt_execute','Com_stmt_close','Com_stmt_reprepare','Com_commit','Com_rollback','Innodb_log_waits','Innodb_buffer_pool_wait_free','Innodb_row_lock_waits','Innodb_row_lock_time')}
assert deltas['Innodb_log_waits']==deltas['Innodb_buffer_pool_wait_free']==0
prepares=deltas['Com_stmt_prepare']-deltas['Com_stmt_reprepare']
if spec['tool']=='native_reuse':
    assert prepares==0 and deltas['Com_stmt_execute']>0 and deltas['Com_stmt_close']==0,deltas
else:
    assert prepares>0 and abs(prepares-deltas['Com_stmt_execute'])<=64 and abs(prepares-deltas['Com_stmt_close'])<=64,deltas
result={'id':spec['id'],'tool':spec['tool'],'client_cores':spec['client_cores'],'go_max_procs':spec['go_max_procs'],'valid':True,'actual_measurement_seconds':seconds,'first_utc':first['utc'],'last_utc':last['utc'],'committed_new_orders':orders,'new_orders_per_second':orders/seconds,'new_orders_per_allocated_client_core_second':orders/seconds/spec['client_cores'],'new_orders_per_client_cpu_second':orders/cost['client_cpu_seconds'],'client_core_utilization_fraction':cost['client_cpu_equivalent_cores']/spec['client_cores'],'database_core_utilization_fraction':cost['database_cpu_equivalent_cores']/spec['database_cores'],'sample_errors':0,'minimum_client_sessions':32,'minimum_available_gib':min(row['host']['mem_kib']['MemAvailable'] for row in measured)/1024**2,'client_prepares':prepares,'statement_counter_deltas':deltas,'completion_classification':classification,'raw_client_status':meta['status'],'clean_full_run':not (classification.get('boundary_query_errors',0) or classification.get('boundary_connection_errors',0) or classification.get('boundary_failed_operations',0) or classification.get('boundary_terminal_cleanup_errors',0)),**cost}
(args.run/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
