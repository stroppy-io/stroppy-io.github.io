#!/usr/bin/env python3
"""Execute one pinned local client with a fixed physical-core budget and raw observers."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/opt/stroppy-client-efficiency-20261029')


def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('spec', type=Path)
    args = parser.parse_args()
    spec = json.loads(args.spec.read_text())
    locks = []
    for path in [ROOT/'invocation.lock', Path('/opt/stroppy-article/invocation.lock'), Path('/opt/stroppy-tpcc-headtohead-20261028/invocation.lock'), Path('/opt/stroppy-gotpc-noreuse-20261028/invocation.lock')]:
        lock = path.open('a' if path.parent == ROOT else 'r')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        locks.append(lock)
    directory = ROOT/'runs'/spec['id']
    directory.mkdir()
    save(directory/'spec.json', spec)
    restore = ROOT/'restores'/spec['id']
    subprocess.run(['python3','-I',str(ROOT/'scripts/snapshot.py'),'restore','go-tpc',str(restore)], check=True)
    time.sleep(30)
    for name,command in [('mysql-config.txt',['mysql','--socket='+str(ROOT/'mysql.sock'),'-NBe','SHOW GLOBAL VARIABLES']),('schema.sql',['mysqldump','--socket='+str(ROOT/'mysql.sock'),'--no-data','--routines','--skip-comments','--set-gtid-purged=OFF',spec['database']])]:
        with (restore/name).open('w') as stream:
            subprocess.run(command,stdout=stream,check=True)
    authentication = subprocess.run(['mysql','-h','127.0.0.1','-P','3307','-ubench','--password=bench','--get-server-public-key','-NBe','SELECT @@version,@@transaction_isolation'], capture_output=True,text=True,timeout=15)
    (directory/'authentication.stdout').write_text(authentication.stdout)
    (directory/'authentication.stderr').write_text(authentication.stderr)
    assert authentication.returncode == 0
    duration = spec['warmup_seconds']+spec['measurement_seconds']
    binary = {'native_reuse':'go-tpc','native_no_reuse':'go-tpc-noreuse','stroppy':'stroppy'}[spec['tool']]
    command = [str(ROOT/'artifacts'/binary)]
    if spec['tool'] == 'stroppy':
        command += ['run','go-tpc-tpcc','-d','mysql','-D',f'url=bench:bench@tcp(127.0.0.1:3307)/{spec["database"]}?parseTime=true','-D','sql.maxOpenConns=33','-D','sql.maxIdleConns=33','--vus=32','--log-level=warn','--report-file='+str(directory/'report.json'),'--warehouses=1000','--weight=45,43,4,4,4','--wait=false','--isolation=2','--ignore-error=false','--count=0',f'--duration={duration}s','--seed=0','--conn-refresh-interval=0s']
    else:
        command += ['-d','mysql','-H','127.0.0.1','-P','3307','-U','bench','-p','bench','-D',spec['database'],'-T','32',f'--time={duration}s','--isolation=2','--count=0',f'--max-procs={spec["go_max_procs"]}','--interval=10s','tpcc','--warehouses=1000','run','--weight=45,43,4,4,4','--wait=false','--ignore-error=false']
    command = ['taskset','-c',spec['client_cpuset']]+command
    home = ROOT/'homes'/spec['id']
    home.mkdir()
    env = {**os.environ,'GOMAXPROCS':str(spec['go_max_procs']),'HOME':str(home)}
    monitor = directory/'monitor'
    monitor.mkdir()
    children = []
    outputs = []
    meta = {'id':spec['id'],'command':command,'cwd':str(directory),'environment':{'GOMAXPROCS':env['GOMAXPROCS'],'HOME':str(home)},'binary_sha256':hashlib.sha256((ROOT/'artifacts'/binary).read_bytes()).hexdigest(),'status':'preparing'}
    save(directory/'meta.json',meta)
    try:
        for name,arguments in [('sampler',['python3','-I',str(ROOT/'scripts/sampler.py'),str(monitor),'--database='+spec['database'],'--seconds='+str(duration+40)]),('iostat',['iostat','-x','-y','5']),('pidstat',['pidstat','-h','-r','-u','-w','-p','ALL','5'])]:
            stdout=(monitor/(name+'.stdout')).open('w')
            stderr=(monitor/(name+'.stderr')).open('w')
            outputs += [stdout,stderr]
            children.append(subprocess.Popen(['taskset','-c','56-59']+arguments,stdout=stdout,stderr=stderr))
        time.sleep(5)
        meta.update(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),started_epoch=time.time(),started_monotonic=time.monotonic())
        save(directory/'meta.json',meta)
        with (directory/'stdout.log').open('x') as stdout,(directory/'stderr.log').open('x') as stderr:
            client=subprocess.Popen(command,cwd=directory,env=env,stdout=stdout,stderr=stderr)
            (directory/'client.pid').write_text(str(client.pid))
            try:
                code=client.wait(timeout=duration+60)
            except subprocess.TimeoutExpired:
                client.terminate()
                try:
                    code=client.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    client.kill()
                    code=client.wait()
                meta['watchdog_expired']=True
        meta.update(status='completed' if code==0 else 'failed',exit_code=code,finished_epoch=time.time(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if (directory/'report.json').exists():
            report=json.loads((directory/'report.json').read_text())
            meta['raw_report_status']=report['status']
            meta['errors']=report.get('errors')
            if report.get('errors',{}).get('terminal_errors',0):
                meta['status']='completed_with_errors'
        save(directory/'meta.json',meta)
        time.sleep(1)
        classifier='classify-sdk-gotpc.py' if spec['tool']=='stroppy' else 'classify-gotpc.py'
        subprocess.run(['python3','-I',str(ROOT/'scripts'/classifier),str(directory)],check=True)
        assert code == 0 and not meta.get('watchdog_expired')
    finally:
        for child in children:
            child.terminate()
        for child in children:
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        for output in outputs:
            output.close()
    subprocess.run(['python3','-I',str(ROOT/'scripts/summarize.py'),str(directory)],check=True)


if __name__ == '__main__':
    main()
