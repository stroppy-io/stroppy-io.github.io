# Client hardware-utilization efficiency — 2026-10-29

Question: when the database has spare capacity and client CPU is constrained, which go-tpc execution path delivers more committed work per core and per CPU-second?

## Bounded test

Seven new invocations, all local TCP to the same MySQL instance:

1. One physical client core: native go-tpc with reusable prepared statements, native go-tpc without statement reuse, Stroppy go-tpc port.
2. Two physical client cores: the same tools in reverse order.
3. Eight-core native-with-reuse control to demonstrate database headroom under the same short-window conditions.

The ordinal list describes run order, not repetitions. There is one short invocation per tool/core setting, not a statistical sample. No extra matrix or profiling is included.

Each invocation: SF1000, 32 active unpaced workers, READ-COMMITTED, no added workload retries, 60-second warm-up plus 120-second planned measurement. Complete five-second sample intervals give an actual window of approximately115seconds, retained with timestamps. Original two-family/head-to-head and no-reuse campaign trees and archives remain frozen.

## Matched resources and workload

- Database host bm1:185.184.128.203/private10.88.0.2, dual EPYC9374F,64physical cores,128logical CPUs, approximately751GiB RAM.
- Client physical CPU24 for one core, CPUs24–25 for two,24–31 for the eight-core control; SMT siblings are not allocated. Go `GOMAXPROCS` equals the client core budget.
- Database remains on48physical cores `0-23,32-55`; observers56–59; NUMA memory interleaved across nodes0–1. Local TCP127.0.0.1:3307, not Unix socket.
- Same MySQL8.4.11,512GiB buffer pool,32GiB redo,O_DIRECT,doublewrite on,commit flushing1,binlog off and original family schema.
- Before each invocation a separate working datadir is restored from the preserved read-only SF1000 go-tpc template. All195file hashes verified with server stopped, followed by common30second idle settling. No reload or old datadir overwrite.
- Native source is pinned at a9ca4818625deef91ff80f6c395a575ccae22b7c. Native no-reuse binary uses the previously tested single-file statement-wrapper patch, not new SQL changes. Stroppy collection commit5210a29a839979904f102298701505b7d62f44ae,SDKv6.2.1. Exact binary hashes in `manifests/binaries.json`.

No-reuse means per-call parameterized `sql.Conn` execution, not text interpolation or no server prepares. MySQL client-prepare count is `Com_stmt_prepare - Com_stmt_reprepare`; server automatic reprepares are retained separately. Counters verify reusable/native versus one-use/native-and-SDK transport behavior in measured windows.

## Metrics and decision rule

All costs use the same first/last samples inside the measurement budget:

- Committed New-Orders/s: district-counter delta divided by monotonic time.
- Throughput per allocated client core: New-Orders/s divided by allocated physical cores.
- Orders per client CPU-second: committed orders divided by client process user+system CPU time.
- Client and MySQL CPU microseconds per committed New-Order.
- Process equivalent cores, RSS, SQL/counter errors, session count, memory, redo, lock and storage symptoms.

Client process CPU is charged from `/proc/<pid>/stat` across all its threads, with recorded SC_CLK_TCK. It is not whole-machine energy, instruction efficiency or a full system cost: IRQ/softirq and separately charged kernel/observer work are not attributed to the client. MySQL process CPU is reported separately. Expected rollbacks and other workload operations consume CPU; the denominator remains committed district-counter New-Orders.

Predeclared conservative evidence gate, evaluated separately per tool:

- Both one-core and two-core client CPU utilization at least90% of their allocated cores;
- Two-core throughput at least1.3times one-core throughput;
- Fresh eight-core native-reuse control drives the same DB at least1.2times faster than the tool's two-core case;
- All windows pass worker/session continuity, sample, completion and no-log/free-buffer-wait gates.

Passing supports a client-CPU-limited comparison at those budgets. Failure is **inconclusive**, not evidence that the DB is the bottleneck. A low DB CPU percentage by itself proves neither spare transactional capacity nor absence of a serial DB bottleneck. The control demonstrates a lower bound on DB capacity, not the global maximum.

These are short windows after matched cold restores, not steady-state production or TPC-compliance claims. CPU frequency/cache/NUMA effects and native prepared-handle differences remain part of observed end-to-end efficiency. No confidence intervals or universal SDK overhead decomposition.

## Evidence and restoration

`scripts/report.py` produces `summaries/results.md`,JSON andCSV from `remote/bm1/runs/*/summary.json`. Raw samples,stdout/stderr,exact commands,affinity and deadline-classification files remain per run. `remote/bm1/restores/` records template verification,effective variables and schema; original database-headroom results are retained as context, not substituted for the fresh control.

Dedicated root `/opt/stroppy-client-efficiency-20261029`; working datadir `/storage1/stroppy-client-efficiency-20261029/mysql/work`; service `bench-client-efficiency-mysql`. Original MySQL is temporarily stopped; PostgreSQL stays inactive. Controller restores original MySQL and AppArmor after all seven cases pass. Failures stop for diagnosis, not silent retries. No inter-host control key needed; laptop SSH key never leaves laptop.

Native query cancellations and SDK deadline operation/connection-close errors remain separate from valid steady windows. Raw SDK `completed_with_errors` is not rewritten. No public publication, repository commits, old evidence changes, dataset deletion or rental cancellation.
