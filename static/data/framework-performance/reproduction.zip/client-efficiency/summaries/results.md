# Client hardware-utilization efficiency

Status: complete; 7/7 cases.

Higher New-Orders/s and orders/client CPU-second are better; lower CPU microseconds/order are better. All rows are fresh runs, not earlier controls.

| Tool | Client physical cores | New-Orders/s | Orders/s/allocated core | Client utilization | Orders/client CPU-second | Client CPU us/order | DB CPU cores used | DB CPU us/order |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Native go-tpc, reusable statements | 1 | 1,574.7 | 1,574.7 | 99.3% | 1,585.3 | 630.8 | 6.78 / 48 | 4307.4 |
| Native go-tpc, no statement reuse | 1 | 760.6 | 760.6 | 99.9% | 761.2 | 1313.8 | 5.91 / 48 | 7769.1 |
| Stroppy go-tpc port | 1 | 753.4 | 753.4 | 99.9% | 754.0 | 1326.2 | 5.43 / 48 | 7204.6 |
| Native go-tpc, reusable statements | 2 | 2,180.6 | 1,090.3 | 70.1% | 1,555.0 | 643.1 | 8.61 / 48 | 3948.1 |
| Native go-tpc, no statement reuse | 2 | 1,134.0 | 567.0 | 76.3% | 742.8 | 1346.2 | 7.66 / 48 | 6755.2 |
| Stroppy go-tpc port | 2 | 1,161.2 | 580.6 | 79.7% | 728.4 | 1372.9 | 7.08 / 48 | 6098.2 |
| Native go-tpc, reusable statements | 8 | 6,208.1 | 776.0 | 73.1% | 1,061.7 | 941.9 | 20.75 / 48 | 3342.2 |

## Client-limit evidence

- Native go-tpc, reusable statements: two/one-core throughput 1.385x; doubling efficiency 69.2%; both client budgets >=90% utilized: False; fresh DB-headroom ratio: 2.846958030157408; client-bound evidence passed: False.
- Native go-tpc, no statement reuse: two/one-core throughput 1.491x; doubling efficiency 74.5%; both client budgets >=90% utilized: False; fresh DB-headroom ratio: 5.4745995547795685; client-bound evidence passed: False.
- Stroppy go-tpc port: two/one-core throughput 1.541x; doubling efficiency 77.1%; both client budgets >=90% utilized: False; fresh DB-headroom ratio: 5.346278892922109; client-bound evidence passed: False.

The 8-core native-reuse row is a database-headroom control, not an additional same-budget competitor. A failed criterion is inconclusive, not permission to call the DB the bottleneck. No global maximum DB-throughput claim.

## Interpretation

One-core client utilization is 99–100% for all three paths, while the fresh control drives the same database at 6,208 committed New-Orders/s. These observations support a client-CPU-constrained comparison at one core, not a database throughput ceiling.

Native go-tpc with reusable statements delivers about twice the committed orders per client CPU-second of either no-reuse path. Stroppy and native without reuse are close: Stroppy throughput is 0.9% lower at one core and 2.4% higher at two; its orders/client CPU-second are about 1% and 2% lower respectively. A small throughput advantage at two cores is not a CPU-efficiency win.

The predeclared strict cross-budget criterion did not pass for any tool: two-core client utilization is only 70–80%, despite throughput increasing 1.38–1.54x and the database-headroom control being 2.85–5.47x faster. Two-core runs have mixed limits; this experiment does not isolate scheduling, synchronization, I/O or other causes. Do not call both budgets fully CPU-bound.

## Deadline errors

- efficiency-20261029-native_no_reuse-1core: query cancellations=31, connection checks=1, cleanup=0; raw status=completed.
- efficiency-20261029-native_no_reuse-2core: query cancellations=31, connection checks=0, cleanup=0; raw status=completed.
- efficiency-20261029-native_reuse-1core: query cancellations=32, connection checks=0, cleanup=0; raw status=completed.
- efficiency-20261029-native_reuse-2core: query cancellations=31, connection checks=0, cleanup=0; raw status=completed.
- efficiency-20261029-native_reuse-8core: query cancellations=25, connection checks=1, cleanup=0; raw status=completed.
- efficiency-20261029-stroppy-1core: query cancellations=32, connection checks=0, cleanup=31; raw status=completed_with_errors.
- efficiency-20261029-stroppy-2core: query cancellations=32, connection checks=0, cleanup=29; raw status=completed_with_errors.

## Limits

- Single short invocation per tool/core budget; no confidence intervals.
- 60s warmup and 120s planned window; exact complete sample boundaries retained.
- Local TCP only; no simulated latency.
- CPU costs are client/database process CPU time, excluding separately charged host IRQ/kernel work and observers.
- Expected rollback and all successful/failed workload work consume CPU; denominator is committed district-counter New-Orders.
- Reusable statements are an end-to-end client-path advantage; native no-reuse provides closer transport comparison, not identical SDK internals.
- Deadline errors remain classified separately; valid measurement is not a clean full run.
