# Native go-tpc without statement reuse

Status: complete; 4/4 measured cases.

Rates are committed New-Orders per second, median of completed repetitions. Original reuse and Stroppy columns are earlier frozen measurements, not contemporaneous reruns.

| Placement | Native go-tpc, reusable statements (earlier) | Native go-tpc, no reuse (new) | Stroppy port (earlier) | Repetitions |
|---|---:|---:|---:|---:|
| local | 6,442.8 | 3,810.3 | 3,847.1 | 2 |
| private_lan | 5,691.0 | 3,266.9 | 3,455.7 | 2 |

New native no-reuse cases versus earlier frozen native-reuse and SDK cases; no contemporaneous controls. Native transaction SQL, algorithms, ping, transaction boundaries and driver defaults unchanged. No reusable statement handles; ordinary database/sql Conn query calls use MySQL per-call prepare/execute/close, confirmed by server counters. Timeout-boundary query and connection-check cancellations remain separate from steady-window validity; full runs are not error-free.

Server automatic reprepares increment both Com_stmt_prepare and Com_stmt_reprepare. Client prepares are their difference; all raw counts remain recorded. Client prepare/execute ratios in every case are approximately 1.0, consistent with one-use statement handles, not a text-protocol or interpolation test.

## Deadline errors

- local r1: 32 canceled transaction operations, 0 canceled connection checks; no in-window histogram or sampler errors.
- local r2: 29 canceled transaction operations, 0 canceled connection checks; no in-window histogram or sampler errors.
- private_lan r1: 29 canceled transaction operations, 2 canceled connection checks; no in-window histogram or sampler errors.
- private_lan r2: 32 canceled transaction operations, 0 canceled connection checks; no in-window histogram or sampler errors.

SF1000, 32 active clients, eight physical client cores, GOMAXPROCS8, 300s warm-up and 600s measurement; same original family cold template and MySQL settings. Local TCP and private-LAN placements; two repetitions each. Full logs, exact patch, source, binary/build metadata, counter proof, configs and restore records retained. No interpolation, workload, retry or metric-path changes. Earlier SDK deadline cleanup errors remain disclosed in baseline metadata.

## Interpretation

Disabling statement reuse removes native go-tpc's earlier throughput advantage. The no-reuse results match or fall below the earlier SDK port, strongly supporting statement reuse as the main explanation for the original gap in this setup. This does not isolate a universal SDK/scheduler cost: controls were measured earlier, and two repetitions provide spread evidence rather than confidence intervals.
