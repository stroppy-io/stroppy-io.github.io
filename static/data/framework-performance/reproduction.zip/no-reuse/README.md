# Native go-tpc without reusable prepared statements

Follow-up to the frozen 2026-10-28 SF1000 comparison. User requested native go-tpc with statement reuse disabled to test whether the prepared-handle difference explains the observed Stroppy gap. The original campaign and archive remain unchanged.

## Intervention

Pinned upstream commit: `a9ca4818625deef91ff80f6c395a575ccae22b7c`.

Only `tpcc/workload.go` changes. Worker maps retain lightweight SQL-text wrappers instead of reusable `*sql.Stmt` handles. Each wrapper calls the same worker's `*sql.Conn.ExecContext`, `QueryContext` or `QueryRowContext` with the original SQL and positional arguments. Closing a text wrapper is a no-op. No transaction SQL, random draws, mix, ping policy, transaction boundaries, histogram code, retries, pacing or connection parameters change. Patch: `artifacts/no-reuse.patch`; complete modified source: `source/` and `artifacts/source-noreuse.tar.gz`.

This is **no statement reuse**, not a claim that the MySQL protocol never prepares a statement. With upstream's default `interpolateParams=false`, ordinary parameterized `database/sql` calls fall back to a temporary server prepare, execute and close for each call. No parameter interpolation is enabled. A fixed-count smoke verifies equal positive client-prepare, execute and close deltas. MySQL increments `Com_stmt_prepare` for server automatic repreparation as well, so client prepares are `Com_stmt_prepare - Com_stmt_reprepare`; raw counters remain retained. Initial smoke gate stopped on this documented counter distinction, not a transaction failure: 3,200 transactions completed, with 39,817 client prepares/executions/closes and 8,110 server reprepares. Diagnosis and failed supervisor output are preserved. Measured cases require client-prepare/execute and close/client-prepare deltas to agree within in-flight worker bounds. Reference: https://dev.mysql.com/doc/refman/8.4/en/server-status-variables.html.

Frozen Linux amd64 binary SHA256: `e905b7f0b2c2a7dc0406e8e095b2b750472e948555084ba564e6a59c95a3c2fe`. Built with Go1.27.2, `GOEXPERIMENT=jsonv2`, `CGO_ENABLED=0`, `-trimpath`, same dependency pins as the earlier native binary. `artifacts/buildinfo.json` records provenance.

Upstream's module declares Go1.25 while importing `encoding/json/v2`; Go1.27 vet rejects that package API against the older language version. Tests run with a temporary Go1.27 modfile, without disabling vet or altering committed source/module pins. `artifacts/tests.log` retains passing tests; the binary builds from the unchanged original `go.mod`.

## Measurements

Four new native-no-reuse cases, in order: local r1, private-LAN r1, private-LAN r2, local r2. Same hosts, SF1000 original-loader population, 32 unpaced clients, eight physical client cores, GOMAXPROCS8, 48 physical DB cores, MySQL8.4.11, READ-COMMITTED, durable commit flushing1, binlog off, 512GiB buffer pool and32GiB redo. Each case restores a separate working copy from the earlier pristine cold template, verifies all195 file hashes, settles30s and uses300s warm-up plus600s planned measurement.

Local means TCP127.0.0.1:3307 on DB host bm1; private-LAN means client bm0 to10.88.0.2:3307. No artificial latency. Actual complete counter windows are retained; primary metric is committed district-counter New-Order progress per monotonic second, not full-run native tpmC.

Original reuse and Stroppy comparison values are copied from earlier frozen evidence under `baseline/`. They are **not contemporaneous controls**. All four new runs use no reuse; do not call the follow-up a freshly interleaved three-way experiment or attribute every remaining gap to one cause. Two repetitions establish repeat/spread, not statistical confidence.

## Evidence and safety

New remote root on both hosts: `/opt/stroppy-gotpc-noreuse-20261028`. New DB working directory: `/storage1/stroppy-gotpc-noreuse-20261028/mysql/work`. Earlier pristine template is read-only source; no old working copy, report, archive or catalog is a destination. Original MySQL is temporarily stopped during measurements and restored afterward; original PostgreSQL stays inactive. AppArmor grants are limited to new paths and original policy is restored. Restricted campaign-only transport key is removed after measurements; laptop SSH key never leaves laptop.

`remote/bm1/runs/` holds native logs, exact commands/environment, timing, completion classification, raw database/host samples, summaries and statement counters. `remote/bm0/` retains remote-client evidence. `remote/bm1/restores/` holds reset proof, variables and schema. `summaries/results.md`, `results.json`, `cases.csv` and offline runtime charts are derived evidence. Failed attempts remain retained.

Native deadline query cancellations are classified separately from steady-window validity with the same timestamp/worker/histogram checks as the earlier campaign. Never call those full runs error-free. No public result publication, repository commit/push, original dataset deletion or rental cancellation is authorized by this follow-up.
