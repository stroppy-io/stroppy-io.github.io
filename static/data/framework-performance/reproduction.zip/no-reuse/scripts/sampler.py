#!/usr/bin/env python3
"""Record monotonic SQL/host/process samples without changing database counters."""
import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path("/opt/stroppy-gotpc-noreuse-20261028")
SOCKET = ROOT / "mysql.sock"
STATUS = ["Com_stmt_prepare", "Com_stmt_execute", "Com_stmt_close", "Com_stmt_reprepare", "Prepared_stmt_count", "Com_commit", "Com_rollback", "Questions", "Threads_connected", "Threads_running", "Innodb_os_log_written", "Innodb_log_waits", "Innodb_buffer_pool_reads", "Innodb_buffer_pool_read_requests", "Innodb_buffer_pool_wait_free", "Innodb_buffer_pool_pages_dirty", "Innodb_rows_inserted", "Innodb_rows_updated", "Innodb_row_lock_waits", "Innodb_row_lock_time", "Innodb_deadlocks", "Innodb_lsn_current", "Innodb_lsn_last_checkpoint", "Innodb_lsn_flushed", "Innodb_redo_log_current_lsn", "Innodb_redo_log_checkpoint_lsn", "Innodb_redo_log_flushed_to_disk_lsn", "Innodb_redo_log_logical_size"]
STOP = False


def sql(query):
    result = subprocess.run(["mysql", "--socket=" + str(SOCKET), "-N", "-B", "--connect-timeout=5", "-e", query], text=True, capture_output=True, timeout=15)
    if result.returncode:
        raise RuntimeError(result.stderr.strip())
    return result.stdout.splitlines()


def process(pid):
    path = Path("/proc") / str(pid)
    try:
        text = (path / "stat").read_text()
        values = text[text.rfind(")") + 2:].split()
        status = dict(line.split(":", 1) for line in (path / "status").read_text().splitlines() if ":" in line)
        return {"pid": pid, "utime_ticks": int(values[11]), "stime_ticks": int(values[12]), "rss_kib": int(status.get("VmRSS", "0 kB").split()[0]), "threads": int(status.get("Threads", "0")), "allowed_cpus": status.get("Cpus_allowed_list", "").strip(), "voluntary_switches": int(status.get("voluntary_ctxt_switches", "0")), "involuntary_switches": int(status.get("nonvoluntary_ctxt_switches", "0"))}
    except (OSError, ValueError):
        return None


def host():
    memory = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        key, value = line.split(":", 1)
        if key in ("MemAvailable", "MemFree", "Dirty", "Writeback", "SwapFree"):
            memory[key] = int(value.split()[0])
    network = {}
    for line in Path("/proc/net/dev").read_text().splitlines()[2:]:
        name, rest = line.split(":")
        if name.strip() in ("bond1", "lo"):
            fields = rest.split()
            network[name.strip()] = {"receive_bytes": int(fields[0]), "send_bytes": int(fields[8]), "receive_errors": int(fields[2]), "send_errors": int(fields[10])}
    return {"mem_kib": memory, "load": os.getloadavg(), "cpu": Path("/proc/stat").read_text().splitlines()[0], "diskstats": [line for line in Path("/proc/diskstats").read_text().splitlines() if " md4 " in line], "network": network}


def stop(_signal, _frame):
    global STOP
    STOP = True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--database")
    parser.add_argument("--client-host", choices=["local", "remote"], default="local")
    parser.add_argument("--interval", type=float, default=5)
    parser.add_argument("--seconds", type=float, default=0)
    args = parser.parse_args()
    args.directory.mkdir(parents=True, exist_ok=True)
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    started = time.monotonic()
    target = started
    with (args.directory / "samples.jsonl").open("x", buffering=1) as output:
        while not STOP and (args.seconds <= 0 or time.monotonic() - started < args.seconds):
            sample = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "monotonic": time.monotonic(), "clock_ticks_per_second": os.sysconf('SC_CLK_TCK'), "host": host()}
            for name in ("mysql.pid", "client.pid"):
                try:
                    sample[name] = process(int((args.directory / name).read_text()))
                except (OSError, ValueError):
                    if name == "mysql.pid":
                        try:
                            sample[name] = process(int((ROOT / name).read_text()))
                        except (OSError, ValueError):
                            pass
            try:
                sample['client.pid'] = process(int((args.directory.parent / 'client.pid').read_text()))
            except (OSError, ValueError):
                pass
            if args.database:
                try:
                    before = time.monotonic()
                    sample["new_orders"] = int(sql(f"SELECT SUM(d_next_o_id) FROM `{args.database}`.district")[0])
                    rows = sql("SHOW GLOBAL STATUS WHERE Variable_name IN (" + ",".join("'" + name + "'" for name in STATUS) + ")")
                    sample["mysql"] = {line.split("\t")[0]: int(line.split("\t")[1]) for line in rows}
                    sample["sessions"] = sql(f"SELECT USER,HOST,COMMAND,TIME,STATE FROM information_schema.processlist WHERE DB='{args.database}'")
                    sample['innodb_metrics'] = sql("SELECT NAME,COUNT FROM information_schema.innodb_metrics WHERE NAME IN ('trx_rseg_history_len','log_lsn_current','log_lsn_last_checkpoint','log_lsn_checkpoint_age','log_max_modified_age_async','lock_deadlocks')")
                    sample["query_seconds"] = time.monotonic() - before
                    if not sample.get('mysql.pid'):
                        sample['mysql.pid'] = process(int((ROOT / 'mysql.pid').read_text()))
                    if not sample.get('client.pid'):
                        try:
                            sample['client.pid'] = process(int((args.directory.parent / 'client.pid').read_text()))
                        except (OSError, ValueError):
                            pass
                    if not sample.get('mysql.pid'):
                        sample['process_warning'] = 'database process not visible'
                except Exception as error:
                    sample["sample_error"] = str(error)
            output.write(json.dumps(sample) + "\n")
            target += args.interval
            remaining = target - time.monotonic()
            if remaining > 0:
                time.sleep(remaining)
            else:
                target = time.monotonic()


if __name__ == "__main__":
    main()
