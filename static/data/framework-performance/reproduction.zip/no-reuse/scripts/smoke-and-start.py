#!/usr/bin/env python3
"""Verify per-call prepare/execute/close before starting measured no-reuse cases."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/opt/stroppy-gotpc-noreuse-20261028')
while subprocess.run(['systemctl', 'is-active', '--quiet', 'bench-noreuse-initial-restore']).returncode == 0:
    time.sleep(10)
assert subprocess.run(['systemctl', 'show', 'bench-noreuse-initial-restore', '-p', 'ExecMainStatus', '--value'], capture_output=True, text=True, check=True).stdout.strip() == '0'
subprocess.run(['mysqladmin', '--socket='+str(ROOT/'mysql.sock'), 'ping'], check=True)
directory = ROOT/'runs/smoke-fixed-count'
directory.mkdir()


def counters():
    result = subprocess.run(['mysql', '--socket='+str(ROOT/'mysql.sock'), '-NBe', "SHOW GLOBAL STATUS WHERE Variable_name IN ('Com_stmt_prepare','Com_stmt_execute','Com_stmt_close','Com_stmt_reprepare')"], capture_output=True, text=True, check=True)
    return {line.split('\t')[0]: int(line.split('\t')[1]) for line in result.stdout.splitlines()}


subprocess.run(['mysql', '-h', '127.0.0.1', '-P', '3307', '-ubench', '--password=bench', '--get-server-public-key', '-e', 'SELECT @@version'], check=True)
command = ['taskset', '-c', '24-31', str(ROOT/'artifacts/go-tpc-noreuse'), '-d', 'mysql', '-H', '127.0.0.1', '-P', '3307', '-U', 'bench', '-p', 'bench', '-D', 'gotpc_sf1000', '-T', '32', '--time=120s', '--isolation=2', '--count=3200', '--max-procs=8', '--interval=10s', 'tpcc', '--warehouses=1000', 'run', '--weight=45,43,4,4,4', '--wait=false', '--ignore-error=false']
before = counters()
with (directory/'stdout.log').open('x') as out, (directory/'stderr.log').open('x') as err:
    result = subprocess.run(command, env={**os.environ, 'GOMAXPROCS':'8'}, stdout=out, stderr=err, timeout=180)
after = counters()
deltas = {key:after[key]-value for key,value in before.items()}
text = (directory/'stdout.log').read_text()
assert result.returncode == 0
assert '_ERR' not in text and 'stopped due to timeout' not in text and 'execute run failed' not in text, 'fixed-count smoke reported workload failure'
client_prepares = deltas['Com_stmt_prepare'] - deltas['Com_stmt_reprepare']
assert client_prepares == deltas['Com_stmt_execute'] == deltas['Com_stmt_close'] and client_prepares > 0, deltas
(directory/'counters.json').write_text(json.dumps({'before':before, 'after':after, 'deltas':deltas, 'client_prepares':client_prepares}, indent=2)+'\n')
(directory/'complete.json').write_text(json.dumps({'status':'passed', 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command':command, 'exit_code':result.returncode, 'deltas':deltas, 'sql_transaction_sources_unchanged':True}, indent=2)+'\n')
print(json.dumps({'smoke':'passed','deltas':deltas}), flush=True)
subprocess.run(['python3','-I',str(ROOT/'scripts/controller.py')],check=True)
