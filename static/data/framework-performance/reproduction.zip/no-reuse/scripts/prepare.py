#!/usr/bin/env python3
"""Prepare an isolated native go-tpc statement-reuse follow-up."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent.parent
OLD = ROOT.with_name('stroppy-tpcc-headtohead-20261028')
REMOTE = '/opt/stroppy-gotpc-noreuse-20261028'
PREVIOUS = '/opt/stroppy-tpcc-headtohead-20261028'

for name in ('client.py', 'run-case.py', 'sampler.py', 'summarize.py', 'classify-gotpc.py', 'transport.py', 'charts.py'):
    text = (OLD / 'scripts' / name).read_text().replace(PREVIOUS, REMOTE)
    text = text.replace('tpcc-headtohead-20261028-', 'gotpc-noreuse-20261028-').replace('bench-h2h-', 'bench-noreuse-')
    if name == 'sampler.py':
        text = text.replace('STATUS = [', 'STATUS = ["Com_stmt_prepare", "Com_stmt_execute", "Com_stmt_close", "Com_stmt_reprepare", "Prepared_stmt_count", ')
    if name == 'run-case.py':
        text = text.replace("    historical = Path('/opt/stroppy-article/invocation.lock').open('r')", "    prior = Path('/opt/stroppy-tpcc-headtohead-20261028/invocation.lock').open('r')\n    fcntl.flock(prior, fcntl.LOCK_EX | fcntl.LOCK_NB)\n    historical = Path('/opt/stroppy-article/invocation.lock').open('r')")
    (ROOT / 'scripts' / name).write_text(text)

(ROOT / 'configs').mkdir()
(ROOT / 'manifests').mkdir()
(ROOT / 'configs/mysql.cnf').write_text((OLD / 'configs/mysql.cnf').read_text().replace('stroppy-tpcc-headtohead-20261028', 'stroppy-gotpc-noreuse-20261028'))
(ROOT / 'configs/bench-gotpc-noreuse-mysql.service').write_text((OLD / 'configs/bench-tpcc-headtohead-mysql.service').read_text().replace(PREVIOUS, REMOTE).replace('TPC-C head-to-head campaign', 'native go-tpc statement reuse follow-up'))
shutil.copy2(OLD / 'remote/bm1/manifests/go-tpc-snapshot.json', ROOT / 'manifests/go-tpc-snapshot.json')
shutil.copy2(OLD / 'summaries/results.json', ROOT / 'artifacts/baseline-results.json')
for name in ('original', 'stroppy'):
    for placement in ('local', 'private_lan'):
        for repetition in (1, 2):
            source = OLD / 'runs/bm1' / f'tpcc-headtohead-20261028-go-tpc-{placement}-{name}-r{repetition}'
            destination = ROOT / 'baseline' / source.name
            destination.mkdir(parents=True)
            for file in ('summary.json', 'meta.json', 'completion-classification.json'):
                shutil.copy2(source / file, destination / file)
for number, (placement, repetition) in enumerate([('local', 1), ('private_lan', 1), ('private_lan', 2), ('local', 2)], 1):
    original = OLD / 'specs/matrix-proposed' / ('09-tpcc-headtohead-20261028-go-tpc-local-original-r1.json')
    candidates = [json.loads(path.read_text()) for path in (OLD / 'specs/matrix-proposed').glob('*.json')]
    spec = next(value for value in candidates if value['family']['name'] == 'go-tpc' and value['engine'] == 'original' and value['placement']['name'] == placement and value['repetition'] == repetition)
    spec['id'] = f'gotpc-noreuse-20261028-go-tpc-{placement}-original-r{repetition}'
    spec['statement_reuse'] = False
    spec['comparison_scope'] = 'native no-reuse follow-up versus frozen native reuse and Stroppy results; not contemporaneous controls'
    (ROOT / 'specs' / f'{number:02d}-{spec["id"]}.json').write_text(json.dumps(spec, indent=2) + '\n')
result = subprocess.run(['go', 'version', '-m', '-json', str(ROOT / 'artifacts/go-tpc-noreuse')], capture_output=True, text=True, check=True)
(ROOT / 'artifacts/buildinfo.json').write_text(result.stdout)
checks = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in (ROOT / 'artifacts/go-tpc-noreuse', ROOT / 'artifacts/no-reuse.patch')}
(ROOT / 'artifacts/checksums.json').write_text(json.dumps(checks, indent=2) + '\n')
print(json.dumps({'specifications': 4, 'checksums': checks}))
