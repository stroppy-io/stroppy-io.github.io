#!/usr/bin/env python3
"""Stage confined MySQL paths and preserve pre-follow-up service and policy state."""
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/opt/stroppy-gotpc-noreuse-20261028')
DATA = Path('/storage1/stroppy-gotpc-noreuse-20261028/mysql')

assert subprocess.run(['systemctl', 'is-active', '--quiet', 'bench-mysql']).returncode == 0
for unit in ('bench-postgres', 'bench-tpcc-headtohead-mysql', 'bench-gotpc-noreuse-mysql'):
    assert subprocess.run(['systemctl', 'is-active', '--quiet', unit]).returncode != 0
sessions = subprocess.run(['mysql', '--socket=/run/mysqld/bench.sock', '-NBe', "SELECT COUNT(*) FROM information_schema.processlist WHERE ID <> CONNECTION_ID() AND USER <> 'event_scheduler'"], capture_output=True, text=True, check=True)
assert sessions.stdout.strip() == '0', 'original MySQL has active external sessions'
assert shutil.disk_usage('/storage1').free >= 1024**4
assert not DATA.exists()
DATA.mkdir(parents=True)
(DATA/'work').mkdir()
for name in ('logs', 'runs', 'restores', 'homes'):
    (ROOT/name).mkdir(exist_ok=True)
subprocess.run(['chown', 'root:mysql', str(ROOT)], check=True)
ROOT.chmod(0o775)
subprocess.run(['chown', 'mysql:mysql', str(ROOT/'logs')], check=True)
policy = Path('/etc/apparmor.d/local/usr.sbin.mysqld')
original = policy.read_bytes()
assert b'stroppy-gotpc-noreuse-20261028' not in original
(ROOT/'inventory/apparmor-original').write_bytes(original)
updated = original + b'\n/opt/stroppy-gotpc-noreuse-20261028/** rwk,\n/storage1/stroppy-gotpc-noreuse-20261028/** rwk,\n'
(ROOT/'inventory/apparmor-during').write_bytes(updated)
for args, name in [(['systemctl', 'show', 'bench-mysql', 'bench-postgres', 'bench-tpcc-headtohead-mysql', '-p', 'Id', '-p', 'ActiveState'], 'original-services.txt'), (['nft', 'list', 'ruleset'], 'original-nft.txt'), (['lscpu'], 'lscpu.txt')]:
    result = subprocess.run(args, capture_output=True, text=True, check=True)
    (ROOT/'inventory'/name).write_text(result.stdout)
unit = Path('/etc/systemd/system/bench-gotpc-noreuse-mysql.service')
assert not unit.exists()
shutil.copy2(ROOT/'configs/bench-gotpc-noreuse-mysql.service', unit)
policy.write_bytes(updated)
subprocess.run(['apparmor_parser', '-r', '/etc/apparmor.d/usr.sbin.mysqld'], check=True)
subprocess.run(['systemctl', 'daemon-reload'], check=True)
subprocess.run(['systemctl', 'stop', 'bench-mysql'], check=True)
assert subprocess.run(['systemctl', 'is-active', '--quiet', 'bench-mysql']).returncode != 0
print(json.dumps({'status': 'isolated_followup_staged', 'working_datadir': str(DATA/'work'), 'old_template_read_only': True, 'original_mysql_temporarily_stopped': True}))
