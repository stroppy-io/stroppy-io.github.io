#!/usr/bin/env python3
"""Build an offline runtime chart from retained samples, never synthetic results."""
import argparse
import datetime
import json
from pathlib import Path

HTML = r'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TPC-C runtime evidence</title>
<style>:root{--surface:#fcfcfb;--ink:#0b0b0b;--muted:#52514e;--grid:#e5e4df;--original:#2a78d6;--stroppy:#eb6834;color-scheme:light}html[data-theme=dark]{--surface:#1a1a19;--ink:#f0efec;--muted:#c3c2b7;--grid:#383835;--original:#3987e5;--stroppy:#d95926;color-scheme:dark}body{background:var(--surface);color:var(--ink);font:15px system-ui,sans-serif;margin:0;padding:32px;max-width:1400px}h1{font-size:30px;margin-bottom:6px}.muted{color:var(--muted)}.controls{display:flex;flex-wrap:wrap;gap:18px;align-items:center;margin:24px 0}select,button{font:inherit;padding:7px}.legend{display:flex;gap:24px}.key{display:inline-block;width:24px;height:2px;vertical-align:middle;margin-right:8px}section{margin:28px 0;border-top:1px solid var(--grid);padding-top:16px}svg{width:100%;height:auto;overflow:visible}.grid{stroke:var(--grid);stroke-width:1}.series{fill:none;stroke-width:2;stroke-linejoin:round;stroke-linecap:round}.label{fill:var(--muted);font:12px system-ui}.endpoint{fill:var(--ink);font:12px system-ui}.tip{position:fixed;pointer-events:none;background:var(--surface);border:1px solid var(--grid);padding:12px;white-space:pre-line;box-shadow:0 3px 18px #0002;display:none;max-width:420px}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}td,th{padding:8px;border-bottom:1px solid var(--grid);text-align:left}details{margin:20px 0}.dash .series[data-engine=stroppy]{stroke-dasharray:8 5}@media(forced-colors:active){.series[data-engine=stroppy]{stroke-dasharray:8 5}}</style>
<h1>Native go-tpc without statement reuse</h1><p class="muted">New no-reuse runs only. Earlier reusable-statement and Stroppy results are separate historical controls, not plotted here. Warm-up and deadline samples remain visible.</p>
<div class="controls"><label>Family <select id="family"></select></label><label>Placement <select id="placement"></select></label><label>Repetition <select id="repetition"></select></label><button id="theme">Dark / light</button><label><input id="texture" type="checkbox">Distinct line patterns</label></div>
<div class="legend"><span><i class="key" style="background:var(--original)"></i>Native go-tpc, no statement reuse</span></div><p id="state" class="muted"></p><main id="charts"></main><div id="tip" class="tip" role="status"></div>
<script>const runs=__DATA__;const NS='http://www.w3.org/2000/svg';const metrics=[['new_orders_per_second','Committed New-Orders / second'],['transactions_per_second','MySQL commits + rollbacks / second'],['client_cpu_percent','Client CPU (% of one core)'],['db_cpu_percent','MySQL CPU (% of one core)'],['redo_bytes_per_second','Redo bytes / second'],['db_rss_gib','MySQL RSS (GiB)'],['client_rss_mib','Client RSS (MiB)'],['disk_mib_per_second','DB RAID read + write (MiB / second)'],['network_mib_per_second','DB private-link receive + send (MiB / second)'],['checkpoint_age_gib','Redo checkpoint age (GiB)']];function el(n,a={},text){let e=document.createElementNS(NS,n);for(let[k,v]of Object.entries(a))e.setAttribute(k,v);if(text!==undefined)e.textContent=text;return e}function options(id,values){const s=document.getElementById(id);for(let value of [...new Set(values)].sort()){let o=document.createElement('option');o.value=value;o.textContent=value;s.append(o)}s.onchange=draw}options('family',runs.map(r=>r.family));options('placement',runs.map(r=>r.placement));options('repetition',runs.map(r=>String(r.repetition)));if(runs.some(r=>r.repetition===1))document.getElementById('repetition').value='1';const params=new URLSearchParams(location.search);for(const id of ['family','placement','repetition']){const select=document.getElementById(id);if([...select.options].some(o=>o.value===params.get(id)))select.value=params.get(id)}if(params.get('theme')==='dark')document.documentElement.dataset.theme='dark';document.getElementById('theme').onclick=()=>{document.documentElement.dataset.theme=document.documentElement.dataset.theme==='dark'?'light':'dark';draw()};document.getElementById('texture').onchange=e=>document.body.classList.toggle('dash',e.target.checked);
function draw(){const selected=runs.filter(r=>r.family===document.getElementById('family').value&&r.placement===document.getElementById('placement').value&&String(r.repetition)===document.getElementById('repetition').value);const main=document.getElementById('charts');main.replaceChildren();document.getElementById('state').textContent=selected.map(r=>r.id+' — '+r.status).join(' | ');if(!selected.length){document.getElementById('state').textContent='No recorded case for this selection.';return}for(let[key,title]of metrics){let section=document.createElement('section'),h=document.createElement('h2');h.textContent=title;section.append(h);let svg=el('svg',{viewBox:'0 0 1100 310',tabindex:0,role:'img','aria-label':title});section.append(svg);let points=selected.flatMap(r=>r.points).filter(p=>Number.isFinite(p[key]));if(!points.length){let p=document.createElement('p');p.textContent='No samples recorded yet.';section.append(p);main.append(section);continue}const W=840,H=230,L=85,T=20,xmax=Math.max(...points.map(p=>p.elapsed),1),ymax=Math.max(...points.map(p=>p[key]),1)*1.08;let x=v=>L+v/xmax*W,y=v=>T+H-v/ymax*H;for(let i=0;i<=4;i++){let value=ymax*i/4;svg.append(el('line',{x1:L,x2:L+W,y1:y(value),y2:y(value),class:'grid'}),el('text',{x:L-10,y:y(value)+4,'text-anchor':'end',class:'label'},new Intl.NumberFormat(undefined,{notation:'compact',maximumFractionDigits:1}).format(value)));let sec=xmax*i/4;svg.append(el('text',{x:x(sec),y:T+H+24,'text-anchor':'middle',class:'label'},Math.round(sec)+'s'))}let warmup=selected[0].warmup;svg.append(el('line',{x1:x(warmup),x2:x(warmup),y1:T,y2:T+H,class:'grid'}),el('text',{x:x(warmup)+5,y:T+12,class:'label'},'measurement starts'));let end=warmup+selected[0].measurement;if(end<=xmax)svg.append(el('line',{x1:x(end),x2:x(end),y1:T,y2:T+H,class:'grid','stroke-dasharray':'4 4'}),el('text',{x:x(end)-5,y:T+12,class:'label','text-anchor':'end'},'budget ends'));selected.forEach((r,i)=>{let valid=r.points.filter(p=>Number.isFinite(p[key]));if(!valid.length)return;let color='var(--'+r.engine+')';svg.append(el('path',{d:valid.map((p,j)=>(j?'L':'M')+x(p.elapsed)+','+y(p[key])).join(' '),class:'series',stroke:color,'data-engine':r.engine}));let last=valid.at(-1);svg.append(el('circle',{cx:x(last.elapsed),cy:y(last[key]),r:4,fill:color,stroke:'var(--surface)','stroke-width':2}),el('text',{x:L+W+12,y:T+24+i*22,class:'endpoint'},'no reuse'+(r.status==='invalid'?' invalid':''))) });let cross=el('line',{y1:T,y2:T+H,stroke:'var(--muted)','stroke-width':1,visibility:'hidden'});svg.append(cross);const tip=document.getElementById('tip');function show(clientX,clientY){let rect=svg.getBoundingClientRect(),px=(clientX-rect.left)/rect.width*1100,sec=Math.max(0,Math.min(xmax,(px-L)/W*xmax));cross.setAttribute('x1',x(sec));cross.setAttribute('x2',x(sec));cross.setAttribute('visibility','visible');tip.textContent=Math.round(sec)+'s\n'+selected.map(r=>{let p=r.points.filter(p=>Number.isFinite(p[key])).reduce((a,p)=>!a||Math.abs(p.elapsed-sec)<Math.abs(a.elapsed-sec)?p:a,null);return r.engine+': '+(p?p[key].toLocaleString(undefined,{maximumFractionDigits:2}):'no sample')}).join('\n');tip.style.left=Math.min(clientX+12,innerWidth-300)+'px';tip.style.top=clientY+12+'px';tip.style.display='block'}svg.onpointermove=e=>show(e.clientX,e.clientY);svg.onpointerleave=()=>{tip.style.display='none';cross.setAttribute('visibility','hidden')};svg.onfocus=()=>{let r=svg.getBoundingClientRect();show(r.left+r.width/2,r.top+30)};svg.onblur=()=>{tip.style.display='none'};let details=document.createElement('details'),summary=document.createElement('summary');summary.textContent='Accessible sample table';details.append(summary);let table=document.createElement('table');let header=document.createElement('tr');for(let text of ['Client','Elapsed seconds',title]){let th=document.createElement('th');th.textContent=text;header.append(th)}table.append(header);for(let r of selected)for(let p of r.points){let tr=document.createElement('tr');for(let v of [r.engine,p.elapsed.toFixed(1),p[key]?.toFixed(3)??'']){let td=document.createElement('td');td.textContent=v;tr.append(td)}table.append(tr)}details.append(table);section.append(details);main.append(section)}}draw();</script></html>'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    runs = []
    for path in sorted(args.root.rglob('meta.json')):
        try:
            meta = json.loads(path.read_text())
            spec = json.loads((path.parent / 'spec.json').read_text())
            sample_path = path.parent / 'monitor/samples.jsonl'
            start = meta['started_epoch']
            samples = [json.loads(line) for line in sample_path.read_text().splitlines()]
            good = [row for row in samples if 'new_orders' in row and 'mysql' in row]
            points = []
            for previous, current in zip(good, good[1:]):
                seconds = current['monotonic'] - previous['monotonic']
                if seconds <= 0 or datetime.datetime.fromisoformat(current['utc']).timestamp() < start:
                    continue
                point = {'elapsed': datetime.datetime.fromisoformat(current['utc']).timestamp()-start, 'new_orders_per_second': (current['new_orders']-previous['new_orders'])/seconds, 'transactions_per_second': sum(current['mysql'].get(key,0)-previous['mysql'].get(key,0) for key in ('Com_commit','Com_rollback'))/seconds, 'redo_bytes_per_second': (current['mysql'].get('Innodb_os_log_written',0)-previous['mysql'].get('Innodb_os_log_written',0))/seconds}
                if current.get('mysql.pid'):
                    point['db_rss_gib'] = current['mysql.pid']['rss_kib']/1024**2
                disks = [row['host'].get('diskstats', []) for row in (previous, current)]
                if all(disks):
                    sectors = [sum(int(line.split()[5])+int(line.split()[9]) for line in rows) for rows in disks]
                    point['disk_mib_per_second'] = (sectors[1]-sectors[0])/2048/seconds
                network = [row['host'].get('network', {}).get('bond1') for row in (previous, current)]
                if all(network):
                    transferred = [row['receive_bytes']+row['send_bytes'] for row in network]
                    point['network_mib_per_second'] = (transferred[1]-transferred[0])/1024**2/seconds
                if all(key in current['mysql'] for key in ('Innodb_redo_log_current_lsn', 'Innodb_redo_log_checkpoint_lsn')):
                    point['checkpoint_age_gib'] = (current['mysql']['Innodb_redo_log_current_lsn']-current['mysql']['Innodb_redo_log_checkpoint_lsn'])/1024**3
                points.append(point)
            client_path = path.parent / 'client-monitor/samples.jsonl'
            client_samples = [json.loads(line) for line in client_path.read_text().splitlines()] if client_path.exists() else samples
            for process_key, metric, records in [('mysql.pid','db_cpu_percent',samples),('client.pid','client_cpu_percent',client_samples)]:
                process_rows = [row for row in records if row.get(process_key)]
                for before, after in zip(process_rows, process_rows[1:]):
                    seconds = after['monotonic'] - before['monotonic']
                    if seconds <= 0 or after[process_key]['pid'] != before[process_key]['pid']:
                        continue
                    elapsed = datetime.datetime.fromisoformat(after['utc']).timestamp() - start
                    if not points:
                        continue
                    target = min(points, key=lambda point: abs(point['elapsed']-elapsed))
                    if abs(target['elapsed']-elapsed) < 6:
                        ticks = sum(after[process_key][key]-before[process_key][key] for key in ('utime_ticks','stime_ticks'))
                        target[metric] = ticks * 100 / after.get('clock_ticks_per_second', 100) / seconds
                        target[metric + '_clock_ticks'] = after.get('clock_ticks_per_second', 100)
                        if process_key == 'client.pid':
                            target['client_rss_mib'] = after[process_key]['rss_kib']/1024
            classification = meta.get('completion_classification', {})
            boundary_operations = classification.get('boundary_failed_operations', classification.get('boundary_query_errors', 0))
            boundary_cleanup = classification.get('boundary_terminal_cleanup_errors', 0)
            status = meta['status']
            boundary_connection = classification.get('boundary_connection_errors', 0)
            if boundary_operations or boundary_cleanup or boundary_connection:
                status += f'; deadline queries={boundary_operations}, connection checks={boundary_connection}, cleanup={boundary_cleanup}'
            runs.append({'id':spec['id'],'family':spec['family']['name'],'placement':spec['placement']['name'],'engine':spec['engine'],'repetition':spec['repetition'],'warmup':spec['warmup_seconds'],'measurement':spec['measurement_seconds'],'status':status,'points':points})
        except (OSError,KeyError,ValueError):
            continue
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(HTML.replace('__DATA__',json.dumps(runs).replace('<','\\u003c')))
    print(f'{len(runs)} recorded invocations rendered')


if __name__ == '__main__':
    main()
