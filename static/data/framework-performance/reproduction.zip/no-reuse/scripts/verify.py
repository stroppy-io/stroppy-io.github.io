#!/usr/bin/env python3
"""Check follow-up results against raw samples, baseline settings and the isolated patch."""
import argparse
import datetime
import hashlib
import json
import math
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('root', type=Path)
args = parser.parse_args()
root = args.root
baseline = root/'baseline/provenance'
load = lambda path: json.loads(path.read_text())
results = load(root/'summaries/results.json')
assert results['status'] == 'complete' and results['completed_cases'] == 4
reference_variables = (baseline/'mysql-config.txt').read_text()
reference_schema = (baseline/'schema.sql').read_bytes()
expected_files = load(baseline/'go-tpc-snapshot.json')['files']
assert load(root/'manifests/go-tpc-snapshot.json')['files'] == expected_files
windows = []
cases = []
for path in sorted((root/'specs').glob('[0-9][0-9]-*.json')):
    spec = load(path)
    directory = root/'remote/bm1/runs'/spec['id']
    meta = load(directory/'meta.json')
    summary = load(directory/'summary.json')
    resolved = load(directory/'spec.json')
    assert resolved['statement_reuse'] is False and summary['valid'] and meta['exit_code'] == 0
    assert meta['status'] == 'completed'
    for key in ('id','engine','family','placement','active_clients','repetition','warmup_seconds','measurement_seconds'):
        assert resolved[key] == spec[key]
    original = load(root/'baseline'/f"tpcc-headtohead-20261028-go-tpc-{summary['placement']}-original-r{summary['repetition']}"/'meta.json')
    assert meta['command'][1:] == original['command'][1:], 'CLI parameters changed'
    assert meta['environment']['GOMAXPROCS'] == original['environment']['GOMAXPROCS'] == '8'
    classification = meta['completion_classification']
    assert classification['valid_completion'] and classification['deadline_workers'] == 32
    assert classification['in_window_histogram_errors'] == 0
    records = [json.loads(line) for line in (directory/'monitor/samples.jsonl').read_text().splitlines()]
    assert not any('sample_error' in row for row in records)
    measured = [row for row in records if 'mysql' in row and 300 <= datetime.datetime.fromisoformat(row['utc']).timestamp()-meta['started_epoch'] <= 900]
    assert len(measured) >= 118
    assert all(sum(line.startswith('bench\t') for line in row.get('sessions',[])) == 32 for row in measured)
    assert all(0 < after['monotonic']-before['monotonic'] < 12 for before,after in zip(measured,measured[1:]))
    first,last = measured[0],measured[-1]
    seconds = last['monotonic']-first['monotonic']
    assert seconds >= 588
    orders = last['new_orders']-first['new_orders']
    assert orders == summary['committed_new_orders'] and math.isclose(orders/seconds,summary['new_orders_per_second'],rel_tol=1e-12)
    counter = load(directory/'statement-counters.json')
    deltas = {key:last['mysql'][key]-first['mysql'][key] for key in counter['deltas']}
    assert deltas == counter['deltas']
    prepares = deltas['Com_stmt_prepare']-deltas['Com_stmt_reprepare']
    assert abs(prepares-deltas['Com_stmt_execute']) <= 64 and abs(prepares-deltas['Com_stmt_close']) <= 64
    assert math.isclose(prepares/deltas['Com_stmt_execute'],counter['prepare_per_execute'],rel_tol=1e-12)
    assert all(last['mysql'][key] == first['mysql'][key] for key in ('Innodb_log_waits','Innodb_buffer_pool_wait_free'))
    restore = root/'remote/bm1/restores'/spec['id']
    reset = load(restore/'complete.json')
    assert reset['server_stopped'] and reset['verified_files'] == len(expected_files)
    assert reset['template'] == '/storage1/stroppy-tpcc-headtohead-20261028/mysql/template-go-tpc'
    variables = (restore/'mysql-config.txt').read_text().replace('stroppy-gotpc-noreuse-20261028','stroppy-tpcc-headtohead-20261028')
    assert variables == reference_variables, 'effective settings differ beyond isolated filesystem paths'
    assert (restore/'schema.sql').read_bytes() == reference_schema
    row = next(row for row in results['cases'] if row['placement'] == spec['placement']['name'] and row['repetition'] == spec['repetition'])
    assert math.isclose(row['native_no_reuse_nops'],orders/seconds,rel_tol=1e-12)
    windows.append((meta['started_epoch'],meta['finished_epoch']))
    cases.append({'id':spec['id'],'new_orders_per_second':orders/seconds,'seconds':seconds,'client_prepares':prepares,'executions':deltas['Com_stmt_execute'],'closes':deltas['Com_stmt_close'],'server_reprepares':deltas['Com_stmt_reprepare'],'boundary_query_errors':classification['boundary_query_errors'],'boundary_connection_errors':classification.get('boundary_connection_errors',0),'session_count':32,'sample_errors':0})
windows.sort()
assert all(a[1] <= b[0] for a,b in zip(windows,windows[1:]))
assert load(root/'remote/bm1/cleanup/complete.json')['status'] == 'all_four_steady_windows_complete_original_services_restored'
checks = load(root/'artifacts/checksums.json')
for name,expected in checks.items():
    with (root/name).open('rb') as stream:
        assert hashlib.file_digest(stream,'sha256').hexdigest() == expected
receipt = {'status':'verified','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':cases,'effective_variables_match_baseline_except_campaign_paths':True,'schema_matches_baseline':True,'same_pristine_template':True,'no_client_overlap':True,'historical_controls_not_contemporaneous':True}
(root/'summaries/verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'verified','cases':len(cases)}))
