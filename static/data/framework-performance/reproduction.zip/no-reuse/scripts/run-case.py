#!/usr/bin/env python3
"""Restore one matched dataset, run one supervised client, and retain runtime evidence."""
import argparse
import base64
import tarfile
import datetime
import fcntl
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/opt/stroppy-gotpc-noreuse-20261028')
REMOTE = '10.88.0.1'
SSH = ['ssh', '-i', str(ROOT / 'client_ed25519'), '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'UserKnownHostsFile=' + str(ROOT / 'configs/transport-known-hosts'), 'root@' + REMOTE]


def remote(action, value, **kwargs):
    return subprocess.run(SSH + [action + ' ' + value], check=True, **kwargs)


def command(args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('spec', type=Path)
    args = parser.parse_args()
    spec = json.loads(args.spec.read_text())
    name = spec['id']
    directory = ROOT / 'runs' / name
    if directory.exists():
        raise FileExistsError(directory)
    family = spec['family']['name']
    database = 'hammer_sf1000' if family == 'hammerdb' else 'gotpc_sf1000'
    spec['database'] = database
    lock = (ROOT / 'invocation.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    old = subprocess.run(['pgrep', '-f', '/opt/stroppy-article/(bin|scripts)/'], capture_output=True, text=True)
    if old.returncode == 0:
        raise RuntimeError('historical campaign process active: ' + old.stdout)
    prior = Path('/opt/stroppy-tpcc-headtohead-20261028/invocation.lock').open('r')
    fcntl.flock(prior, fcntl.LOCK_EX | fcntl.LOCK_NB)
    historical = Path('/opt/stroppy-article/invocation.lock').open('r')
    fcntl.flock(historical, fcntl.LOCK_EX | fcntl.LOCK_NB)
    restore = ROOT / 'restores' / name
    command(['python3', '-I', str(ROOT / 'scripts/snapshot.py'), 'restore', family, str(restore)])
    # Give recovery, asynchronous startup and device queues a common idle interval.
    time.sleep(30)
    spec['start_epoch'] = time.time() + 20
    with (restore / 'mysql-config.txt').open('w') as output:
        command(['mysql', '--socket=' + str(ROOT / 'mysql.sock'), '-N', '-B', '-e', 'SHOW GLOBAL VARIABLES'], stdout=output)
    with (restore / 'schema.sql').open('w') as output:
        command(['mysqldump', '--socket=' + str(ROOT / 'mysql.sock'), '--no-data', '--routines', '--skip-comments', '--set-gtid-purged=OFF', database], stdout=output)
    prepared = ROOT / 'specs' / (name + '.resolved.json')
    prepared.write_text(json.dumps(spec, indent=2) + '\n')
    local = spec['placement']['client'] == 'bm1'
    client_unit = 'bench-noreuse-' + name.replace('gotpc-noreuse-20261028-', '')
    remote_path = str(prepared)
    invocation = ['systemd-run', '--unit=' + client_unit, '--property=AllowedCPUs=24-31', '--property=NUMAPolicy=interleave', '--property=NUMAMask=0-1', '--property=LimitNOFILE=1048576', '--setenv=HOME=/root', '/usr/bin/python3', '-I', str(ROOT / 'scripts/client.py'), remote_path]
    if local:
        command(invocation)
    else:
        remote('put', base64.b64encode(prepared.read_bytes()).decode())
        remote('start', name)
    ready_deadline = time.monotonic() + 15
    while local and not directory.exists():
        if time.monotonic() > ready_deadline:
            raise TimeoutError('client directory not created')
        time.sleep(0.2)
    if not local:
        directory.mkdir()
        (directory / 'spec.json').write_text(json.dumps(spec, indent=2) + '\n')
    monitor_dir = directory / 'monitor'
    monitor_dir.mkdir()
    monitor = subprocess.Popen(['taskset', '-c', '56-59', 'python3', '-I', str(ROOT / 'scripts/sampler.py'), str(monitor_dir), '--database=' + database, '--seconds=' + str(spec['warmup_seconds'] + spec['measurement_seconds'] + 110)], stdout=(monitor_dir / 'sampler.stdout').open('w'), stderr=(monitor_dir / 'sampler.stderr').open('w'))
    io = subprocess.Popen(['taskset', '-c', '56-59', 'iostat', '-x', '-y', '5'], stdout=(monitor_dir / 'iostat.log').open('w'), stderr=subprocess.DEVNULL)
    process = subprocess.Popen(['taskset', '-c', '56-59', 'pidstat', '-h', '-r', '-u', '-w', '-p', 'ALL', '5'], stdout=(monitor_dir / 'pidstat.log').open('w'), stderr=subprocess.DEVNULL)
    deadline = spec['start_epoch'] + spec['warmup_seconds'] + spec['measurement_seconds'] + 240
    try:
        while time.time() < deadline:
            if local:
                result = subprocess.run(['systemctl', 'show', client_unit, '-p', 'ActiveState', '--value'], capture_output=True, text=True)
            else:
                result = remote('status', name, capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip() not in ('active', 'activating'):
                break
            time.sleep(5)
        else:
            raise TimeoutError('client supervision timed out')
        if not local:
            archive = directory / 'client-evidence.tar.gz'
            with archive.open('xb') as output:
                remote('archive', name, stdout=output)
            client_directory = directory / 'client-evidence'
            client_directory.mkdir()
            with tarfile.open(archive) as source:
                source.extractall(client_directory, filter='data')
            for file in client_directory.iterdir():
                if file.name != 'client-evidence.tar.gz':
                    destination = directory / file.name
                    if destination.exists():
                        destination = directory / ('client-' + file.name)
                    file.rename(destination)
            client_directory.rmdir()
            archive.unlink()
        meta = json.loads((directory / 'meta.json').read_text())
        command(['python3', '-I', str(ROOT / 'scripts/classify-gotpc.py'), str(directory)])
        classification = json.loads((directory / 'completion-classification.json').read_text())
        (directory / 'meta-before-server-classification.json').write_text((directory / 'meta.json').read_text())
        meta['completion_classification'] = classification
        meta['status'] = 'completed'
        (directory / 'meta.json').write_text(json.dumps(meta, indent=2) + '\n')
        (directory / 'controller.json').write_text(json.dumps({'ended': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': meta['status'], 'restore': str(restore)}, indent=2) + '\n')
        result_status = 'completed_with_boundary_errors' if classification['boundary_query_errors'] or classification.get('boundary_connection_errors') else 'completed'
        (directory / 'measurement-status.txt').write_text(result_status + '\n')
        if not (directory / 'meta.json').exists():
            raise RuntimeError('missing retained metadata')
        if meta.get('exit_code') != 0:
            raise RuntimeError('nonzero client exit is not accepted')
        if not (directory / 'spec.json').exists():
            raise RuntimeError('missing retained specification')
        print('Client execution finalized:', result_status)
    finally:
        for child in (monitor, io, process):
            child.terminate()
        for child in (monitor, io, process):
            try:
                child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()


if __name__ == '__main__':
    main()
