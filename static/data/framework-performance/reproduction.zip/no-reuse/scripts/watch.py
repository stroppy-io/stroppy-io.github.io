#!/usr/bin/env python3
"""Copy follow-up evidence when measurements finish or the supervisor terminates."""
import argparse
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
REMOTE = '/opt/stroppy-gotpc-noreuse-20261028'
SSH = ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','-i','/Users/ariel/.ssh/ssh-key-postgres-august']
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--until-cases', type=int, default=0)
args = parser.parse_args()
seen = set()
for attempt in range(180):
    try:
        result = subprocess.run(SSH+['root@185.184.128.203',f"find {REMOTE}/runs -maxdepth 2 -name statement-counters.json -printf '%h\\n'; systemctl show bench-noreuse-resume -p ActiveState; test ! -f {REMOTE}/cleanup/complete.json || printf 'RESTORED\\n'"],capture_output=True,text=True,timeout=60)
        if result.returncode:
            raise RuntimeError(result.stderr)
        lines=result.stdout.splitlines()
        completed={line for line in lines if line.startswith(REMOTE+'/runs/')}
        terminal='ActiveState=failed' in lines or 'RESTORED' in lines
        if completed-seen or terminal or attempt==0:
            for name,host in [('bm0','185.184.128.61'),('bm1','185.184.128.203')]:
                destination=ROOT/'remote'/name
                destination.mkdir(parents=True,exist_ok=True)
                subprocess.run(['rsync','-az','--exclude=client_ed25519','--exclude=authorized_keys-before','--exclude=artifacts/','--exclude=homes/','--exclude=mysql.sock','--exclude=mysql.sock.lock','--exclude=mysql.pid','-e','ssh -i /Users/ariel/.ssh/ssh-key-postgres-august',f'root@{host}:{REMOTE}/',str(destination)+'/'],check=True,timeout=180)
            subprocess.run(['python3','-I',str(ROOT/'scripts/report.py'),str(ROOT)],check=True)
            seen|=completed
            print(json.dumps({'completed_cases':len(completed),'states':[line for line in lines if not line.startswith('/')]}),flush=True)
        if 'ActiveState=failed' in lines:
            raise SystemExit('Supervisor failed; diagnose preserved logs before retrying')
        if 'RESTORED' in lines or args.until_cases and len(completed) >= args.until_cases:
            break
    except (RuntimeError,subprocess.TimeoutExpired,subprocess.CalledProcessError) as error:
        print('Evidence observation failed; remote processes not restarted: '+str(error),flush=True)
    time.sleep(120)
else:
    raise SystemExit('Local observation deadline reached; remote work not canceled')
