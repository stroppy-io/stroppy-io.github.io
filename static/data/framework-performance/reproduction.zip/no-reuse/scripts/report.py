#!/usr/bin/env python3
"""Report native no-reuse measurements beside separately frozen reuse and SDK results."""
import argparse
import csv
import json
from pathlib import Path
import statistics

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('root', type=Path)
args = parser.parse_args()
root = args.root
rows = []
for path in sorted((root/'remote/bm1/runs').glob('gotpc-noreuse-*/summary.json')):
    summary = json.loads(path.read_text())
    if not summary['valid']:
        continue
    name = f"tpcc-headtohead-20261028-go-tpc-{summary['placement']}-{{engine}}-r{summary['repetition']}"
    baseline = {engine: json.loads((root/'baseline'/name.format(engine=engine)/'summary.json').read_text()) for engine in ('original', 'stroppy')}
    counters = json.loads((path.parent/'statement-counters.json').read_text())
    rows.append({'placement': summary['placement'], 'repetition': summary['repetition'], 'native_reuse_earlier_nops': baseline['original']['new_orders_per_second'], 'native_no_reuse_nops': summary['new_orders_per_second'], 'stroppy_earlier_nops': baseline['stroppy']['new_orders_per_second'], 'no_reuse_over_earlier_reuse': summary['new_orders_per_second']/baseline['original']['new_orders_per_second'], 'earlier_stroppy_over_no_reuse': baseline['stroppy']['new_orders_per_second']/summary['new_orders_per_second'], 'prepare_per_execute': counters['prepare_per_execute'], 'boundary_query_errors': summary['boundary_operation_errors'], 'boundary_connection_errors': json.loads((path.parent/'meta.json').read_text()).get('completion_classification', {}).get('boundary_connection_errors', 0), 'sample_errors': summary['sample_errors']})
output = root/'summaries'
output.mkdir(exist_ok=True)
groups = []
for placement in ('local','private_lan'):
    selected = [row for row in rows if row['placement'] == placement]
    if selected:
        groups.append({'placement': placement, 'repetitions': len(selected), **{key: statistics.median(row[key] for row in selected) for key in ('native_reuse_earlier_nops', 'native_no_reuse_nops', 'stroppy_earlier_nops', 'no_reuse_over_earlier_reuse', 'earlier_stroppy_over_no_reuse')}})
report = {'status': 'complete' if len(rows)==4 else 'in_progress', 'completed_cases':len(rows), 'planned_cases':4, 'groups':groups, 'cases':rows, 'scope':'New native no-reuse cases versus earlier frozen native-reuse and SDK cases; no contemporaneous controls. Native transaction SQL, algorithms, ping, transaction boundaries and driver defaults unchanged. No reusable statement handles; ordinary database/sql Conn query calls use MySQL per-call prepare/execute/close, confirmed by server counters. Timeout-boundary query and connection-check cancellations remain separate from steady-window validity; full runs are not error-free.'}
(output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Native go-tpc without statement reuse','',f"Status: {report['status']}; {len(rows)}/4 measured cases.",'','Rates are committed New-Orders per second, median of completed repetitions. Original reuse and Stroppy columns are earlier frozen measurements, not contemporaneous reruns.','', '| Placement | Native go-tpc, reusable statements (earlier) | Native go-tpc, no reuse (new) | Stroppy port (earlier) | Repetitions |','|---|---:|---:|---:|---:|']
for group in groups:
    lines.append(f"| {group['placement']} | {group['native_reuse_earlier_nops']:,.1f} | {group['native_no_reuse_nops']:,.1f} | {group['stroppy_earlier_nops']:,.1f} | {group['repetitions']} |")
lines += ['', report['scope'], '', 'Server automatic reprepares increment both Com_stmt_prepare and Com_stmt_reprepare. Client prepares are their difference; all raw counts remain recorded. Client prepare/execute ratios in every case are approximately 1.0, consistent with one-use statement handles, not a text-protocol or interpolation test.', '', '## Deadline errors', '']
for row in rows:
    lines.append(f"- {row['placement']} r{row['repetition']}: {row['boundary_query_errors']} canceled transaction operations, {row['boundary_connection_errors']} canceled connection checks; no in-window histogram or sampler errors.")
lines += ['', 'SF1000, 32 active clients, eight physical client cores, GOMAXPROCS8, 300s warm-up and 600s measurement; same original family cold template and MySQL settings. Local TCP and private-LAN placements; two repetitions each. Full logs, exact patch, source, binary/build metadata, counter proof, configs and restore records retained. No interpolation, workload, retry or metric-path changes. Earlier SDK deadline cleanup errors remain disclosed in baseline metadata.']
if len(rows) == 4:
    lines += ['', '## Interpretation', '', 'Disabling statement reuse removes native go-tpc\'s earlier throughput advantage. The no-reuse results match or fall below the earlier SDK port, strongly supporting statement reuse as the main explanation for the original gap in this setup. This does not isolate a universal SDK/scheduler cost: controls were measured earlier, and two repetitions provide spread evidence rather than confidence intervals.']
(output/'results.md').write_text('\n'.join(lines)+'\n')
if rows:
    with (output/'cases.csv').open('w') as stream:
        writer=csv.DictWriter(stream,list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
print(json.dumps({'status':report['status'],'completed_cases':len(rows),'groups':groups}))
