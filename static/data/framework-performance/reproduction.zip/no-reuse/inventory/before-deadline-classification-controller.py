#!/usr/bin/env python3
"""Run bounded native no-reuse cases and restore the original service state."""
import datetime
import json
from pathlib import Path
import subprocess

ROOT = Path('/opt/stroppy-gotpc-noreuse-20261028')


def main():
    for path in sorted((ROOT/'specs').glob('[0-9][0-9]-*.json')):
        spec = json.loads(path.read_text())
        directory = ROOT/'runs'/spec['id']
        assert not directory.exists(), 'existing invocation requires diagnosis'
        subprocess.run(['python3', '-I', str(ROOT/'scripts/run-case.py'), str(path)], check=True)
        subprocess.run(['python3', '-I', str(ROOT/'scripts/summarize.py'), str(directory)], check=True)
        rows = [json.loads(line) for line in (directory/'monitor/samples.jsonl').read_text().splitlines()]
        meta = json.loads((directory/'meta.json').read_text())
        measured = [row for row in rows if spec['warmup_seconds'] <= datetime.datetime.fromisoformat(row['utc']).timestamp()-meta['started_epoch'] <= spec['warmup_seconds']+spec['measurement_seconds'] and 'mysql' in row]
        first, last = measured[0], measured[-1]
        deltas = {key: last['mysql'][key]-first['mysql'][key] for key in ('Com_stmt_prepare', 'Com_stmt_execute', 'Com_stmt_close', 'Com_stmt_reprepare')}
        assert deltas['Com_stmt_prepare'] > 0 and deltas['Com_stmt_execute'] > 0
        client_prepares = deltas['Com_stmt_prepare'] - deltas['Com_stmt_reprepare']
        assert abs(client_prepares-deltas['Com_stmt_execute']) <= 64, deltas
        assert abs(deltas['Com_stmt_close']-client_prepares) <= 64, deltas
        for key in ('Innodb_log_waits', 'Innodb_buffer_pool_wait_free'):
            assert last['mysql'][key] == first['mysql'][key], key
        (directory/'statement-counters.json').write_text(json.dumps({'deltas': deltas, 'prepare_per_execute': client_prepares/deltas['Com_stmt_execute'], 'raw_prepare_per_execute': deltas['Com_stmt_prepare']/deltas['Com_stmt_execute'], 'scope': 'complete external samples; client prepares = Com_stmt_prepare minus Com_stmt_reprepare; server automatic reprepare is retained separately'}, indent=2)+'\n')
        subprocess.run(['python3', '-I', str(ROOT/'scripts/charts.py'), str(ROOT/'runs'), str(ROOT/'summaries/runtime.html')], check=True)
        complete = [json.loads(path.read_text()) for path in (ROOT/'runs').glob('*/summary.json')]
        (ROOT/'STATUS-RUNTIME.json').write_text(json.dumps({'completed_cases': len(complete), 'last_completed': spec['id'], 'target_cases': 4}, indent=2)+'\n')
    subprocess.run(['systemctl', 'stop', 'bench-gotpc-noreuse-mysql'], check=True)
    policy = Path('/etc/apparmor.d/local/usr.sbin.mysqld')
    assert policy.read_bytes() == (ROOT/'inventory/apparmor-during').read_bytes()
    policy.write_bytes((ROOT/'inventory/apparmor-original').read_bytes())
    subprocess.run(['apparmor_parser', '-r', '/etc/apparmor.d/usr.sbin.mysqld'], check=True)
    subprocess.run(['systemctl', 'start', 'bench-mysql'], check=True)
    subprocess.run(['mysqladmin', '--socket=/run/mysqld/bench.sock', '--wait=180', 'ping'], check=True)
    assert subprocess.run(['systemctl', 'is-active', '--quiet', 'bench-postgres']).returncode != 0
    (ROOT/'cleanup').mkdir()
    (ROOT/'cleanup/complete.json').write_text(json.dumps({'status': 'all_four_steady_windows_complete_original_services_restored', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2)+'\n')


if __name__ == '__main__':
    main()
