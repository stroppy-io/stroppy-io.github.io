# Stroppy / HammerDB / go-tpc reproduction files

All 27 measured invocations from three completed campaigns. This is evidence, not a database backup. No binaries or private SSH keys are included.

- `headtohead/`: 16 original/SDK cases, SF1000, local TCP and private LAN, two reversed-order repetitions, 5m warm-up + 10m planned measurement.
- `no-reuse/`: four additional native go-tpc cases without reusable statement handles. Earlier original/SDK rows are historical controls, not interleaved reruns.
- `client-efficiency/`: seven fresh low-core/control cases, 1/2 client cores plus one 8-core native control, 60s + 120s.

Each campaign contains exact specifications, effective MySQL settings, schema/routines, per-case command/environment/timing, stdout/stderr, raw samples, unchanged SDK reports where available, reset manifests, deadline classifiers, result CSV/JSON and verification receipts. Selected failed smokes/classification backups remain. Large pidstat/iostat logs, extracted dependency trees and executables are excluded; the original verified full-archive receipts identify them.

`recompute.py` reads raw samples and checks all 27 committed New-Order rates and the CPU costs in the seven efficiency cases. Run `python3 -I recompute.py` from this directory. It does not connect to a database or write to the original evidence.

To repeat the experiment, start on independent hosts and empty isolated paths. Use the pinned source/artifact identities in the article, `configs/mysql.cnf`, the exact CLI commands in each `meta.json`, the recorded physical-core allocations and each original tool's loader. Validate each original family population, make a complete stopped-server datadir template, and restore it before every invocation. The main suite used 16 loader workers and no full expensive go-tpc correlated SF1000 checks; exact counts and bounded per-district invariants are recorded. Use the recorded warm-up/measurement/order; do not compare native full-run tpmC with the external post-warm-up counter rate.

WARNING: included remote scripts are historical run records with absolute paths, service transitions, benchmark-only `bench` credentials and destructive working-copy restoration. Do not run them unchanged on existing infrastructure. Review destinations, preserve original service/config state, confine writes to new paths, and keep database accounts private. Do not rerun provisioning or loaders against preserved databases. Database files stay on the benchmark servers, not in this bundle.

No claim of audited TPC-C compliance. Unpaced 32-client/SF1000 runs omit strict terminal requirements. Deadline cancellations and SDK connection-close errors remain retained; valid measured windows are not error-free full runs. One low-core invocation per setting and two main repetitions do not establish statistical significance.

Licenses: upstream go-tpc and Stroppy are Apache-2.0; the HammerDB-derived module/procedure source is GPL-3.0. Original notices accompany included source where applicable. See project source links in the article before redistributing binaries.
