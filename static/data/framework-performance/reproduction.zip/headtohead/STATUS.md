# TPC-C head-to-head campaign

Status 2026-10-28 13:25 UTC: measurement and cleanup complete. All 16 steady-window measurements and eight pairs copied to laptop and verified against raw counters, session continuity, cold-restore records and identical effective MySQL settings. Both families have two repetitions per placement. Original MySQL restored; PostgreSQL and campaign MySQL stopped; original AppArmor policy restored. Temporary campaign access removed on both hosts. go-tpc deadline errors remain disclosed; valid steady windows are not clean full runs. Final archive checksum and transfer verification are recorded separately in the sibling archive receipt.

## Hosts and isolated paths

- bm0: 185.184.128.61 / 10.88.0.1, client.
- bm1: 185.184.128.203 / 10.88.0.2, database and local client.
- SSH key stays on laptop: `/Users/ariel/.ssh/ssh-key-postgres-august`.
- Remote evidence root on both: `/opt/stroppy-tpcc-headtohead-20261028`.
- Dedicated DB: `/storage1/stroppy-tpcc-headtohead-20261028/mysql/work`.
- Dedicated unit: `bench-tpcc-headtohead-mysql.service`, TCP3307.
- Original `bench-mysql` restored active at 13:13 UTC. Original PostgreSQL remains
  inactive; dedicated campaign MySQL is stopped.
- Original datadirs/config untouched. Original AppArmor local policy restored
  byte-for-byte and reloaded after dedicated MySQL stopped. Restoration and
  service-state records are under `remote/bm1/cleanup/`.

## Current evidence and failures

- Official HammerDB runtime starts. Missing `libmysqlclient.so.24` was diagnosed;
  exact distro libmysqlclient24 package downloaded and extracted privately under
  artifacts/mysql-client-lib on both hosts. No apt installation or system library replacement.
- Original HammerDB one-warehouse load succeeded after library staging.
- Original go-tpc one-warehouse load succeeded.
- Both SDK ports ran 100 one-client transactions with zero reported errors on the
  original-tool smoke datasets. Remote go-tpc SDK connectivity also passed.
- Native HammerDB fractional-minute smoke was invalid: keepalive accepts whole
  minutes. It was retained as smoke-hammer-run, not a measurement.
- Native HammerDB control semantics verified from actual runtime: `vuset vu N`
  configures N active clients and adds the monitor, creating N+1 threads. Campaign
  uses vuset vu 32, not 33; total created is 33. Raw count verification retained.
- Native HammerDB immediate simultaneous logins (delay=0) crashed in
  libmysqlclient.so.24.0.11 before useful work. Retained as smoke-hammer-run-02.
  Original default 500ms staggering passed a complete one-minute window as
  smoke-hammer-run-03, both monitor and client FINISHED SUCCESS. Keep 500ms
  staggering for native HammerDB. Its login time fits inside five-minute warm-up.
- HammerDB SF1000 original load completed 05:53:32–06:13:30 UTC with 16 workers.
  Exact validation passed: 1000 warehouses, 10000 districts, 100M stock, 30M
  customers/history/orders each, 9M pending orders, 299,998,465 order lines;
  order-line total equals SUM(o_ol_cnt), per-district customer/order counts valid.
- Complete cold template `/storage1/stroppy-tpcc-headtohead-20261028/mysql/template-hammerdb` verified against stopped source, 195 file hashes saved; template is non-writable. Every restore verifies full file hashes before startup.
- Calibration01 failed all logins after cold restore cleared MySQL caching_sha2_password auth cache. Retained, zero accepted results. Added identical private/loopback `mysql --get-server-public-key` preflight for every engine after restore, before timing.
- Calibration02 passed 32-client SF1000 native HammerDB window, 33 sessions throughout, no sampler errors, no log/free-buffer waits, ample memory. Approx 9800 committed New-Orders/s over 55s complete sample intervals; diagnostic, not main comparison.
- MySQL config frozen at 512GiB buffer pool, 32GiB redo, durable flush=1; no evidence-backed extra knob change needed.
- Measured HammerDB series supervised by `bench-h2h-hammer-measurements`; first invocation started 06:43:11 UTC. Series stops at first invalid case. `bench-h2h-next-family` waits for all eight valid HammerDB cases before dropping only its working schema (template preserved), loading/validating/snapshotting go-tpc SF1000. It does not start go-tpc measurements without calibration review.
- Temporary campaign-only SSH access removed at 13:17 UTC: exact restricted
  authorized-key line removed on bm0, other access line preserved; private key
  deleted on bm1. Public identity and cleanup receipts retained. Laptop key was
  never copied; no private keys exist in the evidence bundle.

## Data preservation

Both original SF1000 populations loaded, validated and preserved as independent
cold templates on bm1. Laptop evidence contains manifests, not database files.
All 16 measured cases plus smoke/load/calibration failures copied to laptop.
Offline charts in `summaries/runtime.html` include all 16 measurements and
calibrations, with warm-up/deadline boundaries and actual resource samples.
Light/dark previews visually checked. `README.md` maps evidence and reproduction
materials. `summaries/verification.json` records raw-counter and reset checks.

Original servers, datadirs, templates and rentals remain intact. No public result
publication, old frozen-tree changes or repository edits performed. Do not rerun
historical controllers against preserved data. Final archive/catalog must remain
separate from the old 20261026 evidence.

Runtime observability: first local/original and first SDK cases carry CPU/RSS, SQL, disk and redo-bytes samples. MySQL 8.4 exposes checkpoint LSNs as Innodb_redo_log_* names, not older Innodb_lsn_* names; supported LSN columns added for subsequent invocations. Missing older-name values are not interpreted as real zero checkpoint age.

First matched local pair: HammerDB original 10,197.09 vs SDK 9,956.12 committed New-Orders/s; SDK/original 0.9764, n=1 each. Both 595s complete external sample windows, 33 sessions, zero sample errors. This is preliminary, not a final ranking. First private-LAN SDK case restoration active as of 07:22 UTC.

At 07:27 UTC: first private-LAN SDK invocation active, exact 32 workers plus monitor present; no in-window configuration changes. Restricted inter-host transport starts original/SKD client services without laptop key copying and collects client samples after each run. `bench-h2h-gotpc-gate` waits for second-family load/template, performs a bounded native calibration, then starts the approved eight-case go-tpc matrix only if validity/stall gates pass.

At 07:31 UTC: local first pair preserved and valid; private-LAN SDK r1 in 10-minute measurement with 33 sessions. Supported checkpoint counters show ~6.85GiB age within 32GiB redo, no log/free-buffer waits. Pending next-family sequence is supervised; final go-tpc gate restores original services only after all approved measured summaries validate. No public blog/result publication.

At 07:40 UTC: 3/16 measured cases valid. Private-LAN SDK r1 completed 9574.72 committed New-Orders/s over 595s, 33 sessions, zero sample errors. Local SDK r1 was 9956.12/s. Native private-LAN r1 restoring/running next; no cross-family ranking. `watch-local.py` background watchers copy completed invocations; controlled units run independently of laptop SSH.

At 07:47 UTC: native HammerDB/private-LAN r1 active (started 07:44:45); 33 DB sessions and matched CPU/binary checks confirmed. 3/16 main cases valid and copied. Remaining HammerDB series supervised automatically; next-family load/calibration/measurement stages gated. Laptop watchers sync after terminal summaries; final original-service restore script staged. Transport-key removal remains explicit final cleanup.

At 08:00 UTC: first repetition all four HammerDB cases valid and on laptop. Local original/SDK 10197.09/9956.12 committed New-Orders/s (ratio0.9764); private-LAN original/SDK 9746.77/9574.72 (ratio0.98235). All 595s complete sample windows, 33 sessions, zero sampler/client errors. Four reversed-order HammerDB repeats now follow. go-tpc preparation waits until eight valid summaries.

At 08:21 UTC: 5/16 valid. HammerDB SDK local r2 10122.04 committed New-Orders/s, zero sample errors and 33 sessions; local r1 SDK9956.12. Original local r2 follows restored template. Native original-vs-SDK pair conclusion unchanged until original r2 finishes.

At 09:02 UTC: 7/16 valid. Original private-LAN r2 9773.37 committed New-Orders/s (r1 9746.77); final HammerDB SDK/private-LAN r2 follows. Local medians original10141.37/SDK10039.08 (~SDK-1.0%), n=2 and order reversal changes sign of tiny difference. Next-family gate remains waiting for all eight HammerDB summaries.

At 09:22 UTC: HammerDB family 8/8 measured cases valid, zero reported client/sample errors. Local medians original10141.37 vs SDK10039.08/s (~-1.0%); private-LAN original9760.07 vs SDK9588.40/s (~-1.8%). Native original and SDK differ only within their own pair, not across family. Original go-tpc SF1000 load started 09:22:18 UTC with16workers; HammerDB pristine template retained, only working hammer_sf1000 schema dropped. Next-stage validation/snapshot/calibration gated.

At 09:38 UTC: original go-tpc SF1000 load completed09:33:40 (11m22s); population valid incl300021243orderlines. Full cold template saved/hash-verified. Native go-tpc calibration now restoring. HammerDB full results already laptop-preserved.

At 09:51 UTC: native go-tpc calibration initially rejected by naive _ERR detector. Diagnosed all28_ERR counts exactly match28 final query cancellations among32 workers at120s deadline; no interval/current errors. `classify-gotpc.py` now records exact deadline/worker/histogram reconciliation, not blanket ignoring errors. Original invalid metadata preserved as meta-before-completion-classification.json; accepted classified calibration6150.98/s over55s. Measured controller resumed as bench-h2h-gotpc-measurements, same frozen config, no client binary changes. Watcher uses new controller and continues incremental laptop copies.

At 11:20 UTC: first SDK go-tpc measured run paused the controller with raw completed_with_errors: 32 failed operations and 27 connection-cleanup errors, zero failed SDK queries/retries. Source and logs show deadline connection release returning `sql: connection is already closed`; warning timestamp is 0.028s after the 900s deadline. `classify-sdk-gotpc.py` requires full session continuity, no early warnings, bounded worker/error counts, exact executor budget and deadline-only warning signature. Original metadata/report retained. Only the steady-window summary is accepted; full run remains errorful. Supervisor is now bench-h2h-gotpc-boundary-resume; no client binary changes.

At 11:48 UTC: 12/16 steady windows valid and laptop-preserved. First go-tpc pairs: local original6382.82/SDK3859.97 committed New-Orders/s (-39.5%); private-LAN original5739.80/SDK3458.24 (-39.7%). Native deadline failed-operation counts32/31; SDK counts32/30 plus cleanup27/22. Counts are separate and may overlap. Runtime charts show actual warm-up/deadline/resource samples and raw statuses. All completed measured effective MySQL variable files have identical SHA256. No measured log/free-buffer waits, no memory pressure. Prepared-statement transport gap is documented, not proven the sole cause.

At 12:09 UTC: SDK go-tpc/local r2 steady window accepted (13/16). Remaining native local r2 and both private-LAN r2 cases continue. Original services have not yet been restored; final archive and temporary control-key removal remain pending.

Final checkpoint: all 16 steady windows valid, eight paired comparisons, two repetitions per placement. HammerDB medians original/SDK: local 10141.37/10039.08 committed New-Orders/s (median paired SDK -1.0%); private-LAN 9760.07/9588.40 (-1.8%). go-tpc medians: local 6442.79/3847.06 (-40.3%); private-LAN 5690.98/3455.69 (-39.3%). No cross-family ranking. All measured complete counter windows approximately 595s; zero sampler errors; all 32 workers plus HammerDB's monitor present. Effective MySQL variable files identical, schema/routines identical within each family, every restore verified 195 files, no client overlap. No measured log/free-buffer waits; minimum available memory626.64GiB; maximum recorded checkpoint age12.41GiB within32GiB redo.

Original services restored13:13UTC; campaign control authorization/private key removed13:17UTC; cleanup verified13:21UTC. Original authorized_keys content and AppArmor local policy restored byte-for-byte. No running campaign units. Both SF1000 templates preserved, old databases/rentals unchanged. All eight go-tpc cases retain deadline cancellation/cleanup errors; raw SDK reports still completed_with_errors. No client binary changes during measurements. Final charts rendered and visually checked in light/dark mode. Portable archive and SHA256 receipt remain outside the evidence root to avoid self-referencing catalogs.
