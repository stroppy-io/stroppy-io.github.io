
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `c_id` int NOT NULL,
  `c_d_id` int NOT NULL,
  `c_w_id` int NOT NULL,
  `c_first` varchar(16) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_middle` char(2) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_last` varchar(16) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_street_1` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_street_2` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_city` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_state` char(2) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_zip` char(9) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_phone` char(16) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_since` datetime DEFAULT NULL,
  `c_credit` char(2) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `c_credit_lim` decimal(12,2) DEFAULT NULL,
  `c_discount` decimal(4,4) DEFAULT NULL,
  `c_balance` decimal(12,2) DEFAULT NULL,
  `c_ytd_payment` decimal(12,2) DEFAULT NULL,
  `c_payment_cnt` int DEFAULT NULL,
  `c_delivery_cnt` int DEFAULT NULL,
  `c_data` varchar(500) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`c_w_id`,`c_d_id`,`c_id`),
  KEY `c_w_id` (`c_w_id`,`c_d_id`,`c_last`,`c_first`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `district` (
  `d_id` int NOT NULL,
  `d_w_id` int NOT NULL,
  `d_ytd` decimal(12,2) DEFAULT NULL,
  `d_tax` decimal(4,4) DEFAULT NULL,
  `d_next_o_id` int DEFAULT NULL,
  `d_name` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `d_street_1` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `d_street_2` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `d_city` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `d_state` char(2) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `d_zip` char(9) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`d_w_id`,`d_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history` (
  `h_c_id` int DEFAULT NULL,
  `h_c_d_id` int DEFAULT NULL,
  `h_c_w_id` int DEFAULT NULL,
  `h_d_id` int DEFAULT NULL,
  `h_w_id` int DEFAULT NULL,
  `h_date` datetime DEFAULT NULL,
  `h_amount` decimal(6,2) DEFAULT NULL,
  `h_data` varchar(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item` (
  `i_id` int NOT NULL,
  `i_im_id` int DEFAULT NULL,
  `i_name` varchar(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `i_price` decimal(5,2) DEFAULT NULL,
  `i_data` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`i_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `new_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `new_order` (
  `no_w_id` int NOT NULL,
  `no_d_id` int NOT NULL,
  `no_o_id` int NOT NULL,
  PRIMARY KEY (`no_w_id`,`no_d_id`,`no_o_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `order_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_line` (
  `ol_w_id` int NOT NULL,
  `ol_d_id` int NOT NULL,
  `ol_o_id` int NOT NULL,
  `ol_number` int NOT NULL,
  `ol_i_id` int DEFAULT NULL,
  `ol_delivery_d` datetime DEFAULT NULL,
  `ol_amount` int DEFAULT NULL,
  `ol_supply_w_id` int DEFAULT NULL,
  `ol_quantity` int DEFAULT NULL,
  `ol_dist_info` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`ol_w_id`,`ol_d_id`,`ol_o_id`,`ol_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `o_id` int NOT NULL,
  `o_w_id` int NOT NULL,
  `o_d_id` int NOT NULL,
  `o_c_id` int DEFAULT NULL,
  `o_carrier_id` int DEFAULT NULL,
  `o_ol_cnt` int DEFAULT NULL,
  `o_all_local` int DEFAULT NULL,
  `o_entry_d` datetime DEFAULT NULL,
  PRIMARY KEY (`o_w_id`,`o_d_id`,`o_id`),
  KEY `o_w_id` (`o_w_id`,`o_d_id`,`o_c_id`,`o_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock` (
  `s_i_id` int NOT NULL,
  `s_w_id` int NOT NULL,
  `s_quantity` int DEFAULT NULL,
  `s_dist_01` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_dist_02` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_dist_03` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_dist_04` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_dist_05` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_dist_06` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_dist_07` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_dist_08` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_dist_09` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_dist_10` char(24) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `s_ytd` bigint DEFAULT NULL,
  `s_order_cnt` int DEFAULT NULL,
  `s_remote_cnt` int DEFAULT NULL,
  `s_data` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`s_w_id`,`s_i_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse` (
  `w_id` int NOT NULL,
  `w_ytd` decimal(12,2) DEFAULT NULL,
  `w_tax` decimal(4,4) DEFAULT NULL,
  `w_name` varchar(10) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `w_street_1` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `w_street_2` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `w_city` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `w_state` char(2) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `w_zip` char(9) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`w_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 DROP PROCEDURE IF EXISTS `DELIVERY` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`bench`@`127.0.0.1` PROCEDURE `DELIVERY`(
        d_w_id			INTEGER,
        d_o_carrier_id  	INTEGER,
        IN timestamp 		DATETIME
        )
BEGIN
        DECLARE d_no_o_id	INTEGER;
        DECLARE current_rowid 	INTEGER;
        DECLARE d_d_id	    	INTEGER;
        DECLARE d_c_id        	INTEGER;
        DECLARE d_ol_total	INTEGER;
        DECLARE deliv_data	VARCHAR(100);
        DECLARE loop_counter  	INT;
        DECLARE `Constraint Violation` CONDITION FOR SQLSTATE '23000';
        DECLARE EXIT HANDLER FOR `Constraint Violation` ROLLBACK;
        SET loop_counter = 1;
        START TRANSACTION;
        WHILE loop_counter <= 10 DO
        SET d_d_id = loop_counter;
        SELECT no_o_id INTO d_no_o_id FROM new_order WHERE no_w_id = d_w_id AND no_d_id = d_d_id LIMIT 1;
        DELETE FROM new_order WHERE no_w_id = d_w_id AND no_d_id = d_d_id AND no_o_id = d_no_o_id;
        SELECT o_c_id INTO d_c_id FROM orders
        WHERE o_id = d_no_o_id AND o_d_id = d_d_id AND
        o_w_id = d_w_id;
        UPDATE orders SET o_carrier_id = d_o_carrier_id
        WHERE o_id = d_no_o_id AND o_d_id = d_d_id AND
        o_w_id = d_w_id;
        UPDATE order_line SET ol_delivery_d = timestamp
        WHERE ol_o_id = d_no_o_id AND ol_d_id = d_d_id AND
        ol_w_id = d_w_id;
        SELECT SUM(ol_amount) INTO d_ol_total
        FROM order_line
        WHERE ol_o_id = d_no_o_id AND ol_d_id = d_d_id
        AND ol_w_id = d_w_id;
        UPDATE customer SET c_balance = c_balance + d_ol_total
        WHERE c_id = d_c_id AND c_d_id = d_d_id AND
        c_w_id = d_w_id;
        SET deliv_data = CONCAT(d_d_id,' ',d_no_o_id,' ',timestamp);
        set loop_counter = loop_counter + 1;
        END WHILE;
        COMMIT;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `NEWORD` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`bench`@`127.0.0.1` PROCEDURE `NEWORD`(
        no_w_id		INTEGER,
        no_max_w_id		INTEGER,
        no_d_id		INTEGER,
        no_c_id		INTEGER,
        no_o_ol_cnt		INTEGER,
        OUT no_c_discount 	DECIMAL(4,4),
        OUT no_c_last 		VARCHAR(16),
        OUT no_c_credit 		VARCHAR(2),
        OUT no_d_tax 		DECIMAL(4,4),
        OUT no_w_tax 		DECIMAL(4,4),
        INOUT no_d_next_o_id 	INTEGER,
        IN timestamp 		DATETIME
        )
BEGIN
        DECLARE no_ol_supply_w_id	INTEGER;
        DECLARE no_ol_i_id		INTEGER;
        DECLARE no_ol_quantity 		INTEGER;
        DECLARE no_o_all_local 		INTEGER;
        DECLARE o_id 			INTEGER;
        DECLARE no_i_name		VARCHAR(24);
        DECLARE no_i_price		DECIMAL(5,2);
        DECLARE no_i_data		VARCHAR(50);
        DECLARE no_s_quantity		DECIMAL(6);
        DECLARE no_ol_amount		DECIMAL(6,2);
        DECLARE no_s_dist_01		CHAR(24);
        DECLARE no_s_dist_02		CHAR(24);
        DECLARE no_s_dist_03		CHAR(24);
        DECLARE no_s_dist_04		CHAR(24);
        DECLARE no_s_dist_05		CHAR(24);
        DECLARE no_s_dist_06		CHAR(24);
        DECLARE no_s_dist_07		CHAR(24);
        DECLARE no_s_dist_08		CHAR(24);
        DECLARE no_s_dist_09		CHAR(24);
        DECLARE no_s_dist_10		CHAR(24);
        DECLARE no_ol_dist_info 	CHAR(24);
        DECLARE no_s_data	   	VARCHAR(50);
        DECLARE x		        INTEGER;
        DECLARE rbk		       	INTEGER;
        DECLARE loop_counter    	INT;
        DECLARE `Constraint Violation` CONDITION FOR SQLSTATE '23000';
        DECLARE EXIT HANDLER FOR `Constraint Violation` ROLLBACK;
        DECLARE EXIT HANDLER FOR NOT FOUND ROLLBACK;
        SET no_o_all_local = 1;
        SELECT c_discount, c_last, c_credit, w_tax
        INTO no_c_discount, no_c_last, no_c_credit, no_w_tax
        FROM customer, warehouse
        WHERE warehouse.w_id = no_w_id AND customer.c_w_id = no_w_id AND
        customer.c_d_id = no_d_id AND customer.c_id = no_c_id;
        START TRANSACTION;
        SELECT d_next_o_id, d_tax INTO no_d_next_o_id, no_d_tax
        FROM district
        WHERE d_id = no_d_id AND d_w_id = no_w_id FOR UPDATE;
        UPDATE district SET d_next_o_id = d_next_o_id + 1 WHERE d_id = no_d_id AND d_w_id = no_w_id;
        SET o_id = no_d_next_o_id;
        SET rbk = FLOOR(1 + (RAND() * 99));
        SET loop_counter = 1;
        WHILE loop_counter <= no_o_ol_cnt DO
        IF ((loop_counter = no_o_ol_cnt) AND (rbk = 1))
        THEN
        SET no_ol_i_id = 100001;
        ELSE
        SET no_ol_i_id = FLOOR(1 + (RAND() * 100000));
        END IF;
        SET x = FLOOR(1 + (RAND() * 100));
        IF ( x > 1 )
        THEN
        SET no_ol_supply_w_id = no_w_id;
        ELSE
        SET no_ol_supply_w_id = no_w_id;
        SET no_o_all_local = 0;
        WHILE ((no_ol_supply_w_id = no_w_id) AND (no_max_w_id != 1)) DO
        SET no_ol_supply_w_id = FLOOR(1 + (RAND() * no_max_w_id));
        END WHILE;
        END IF;
        SET no_ol_quantity = FLOOR(1 + (RAND() * 10));
        SELECT i_price, i_name, i_data INTO no_i_price, no_i_name, no_i_data
        FROM item WHERE i_id = no_ol_i_id;
        SELECT s_quantity, s_data, s_dist_01, s_dist_02, s_dist_03, s_dist_04, s_dist_05, s_dist_06, s_dist_07, s_dist_08, s_dist_09, s_dist_10
        INTO no_s_quantity, no_s_data, no_s_dist_01, no_s_dist_02, no_s_dist_03, no_s_dist_04, no_s_dist_05, no_s_dist_06, no_s_dist_07, no_s_dist_08, no_s_dist_09, no_s_dist_10
        FROM stock WHERE s_i_id = no_ol_i_id AND s_w_id = no_ol_supply_w_id;
        IF ( no_s_quantity > no_ol_quantity )
        THEN
        SET no_s_quantity = ( no_s_quantity - no_ol_quantity );
        ELSE
        SET no_s_quantity = ( no_s_quantity - no_ol_quantity + 91 );
        END IF;
        UPDATE stock SET s_quantity = no_s_quantity
        WHERE s_i_id = no_ol_i_id
        AND s_w_id = no_ol_supply_w_id;
        SET no_ol_amount = (  no_ol_quantity * no_i_price * ( 1 + no_w_tax + no_d_tax ) * ( 1 - no_c_discount ) );
        CASE no_d_id
        WHEN 1 THEN
        SET no_ol_dist_info = no_s_dist_01;
        WHEN 2 THEN
        SET no_ol_dist_info = no_s_dist_02;
        WHEN 3 THEN
        SET no_ol_dist_info = no_s_dist_03;
        WHEN 4 THEN
        SET no_ol_dist_info = no_s_dist_04;
        WHEN 5 THEN
        SET no_ol_dist_info = no_s_dist_05;
        WHEN 6 THEN
        SET no_ol_dist_info = no_s_dist_06;
        WHEN 7 THEN
        SET no_ol_dist_info = no_s_dist_07;
        WHEN 8 THEN
        SET no_ol_dist_info = no_s_dist_08;
        WHEN 9 THEN
        SET no_ol_dist_info = no_s_dist_09;
        WHEN 10 THEN
        SET no_ol_dist_info = no_s_dist_10;
        END CASE;
        INSERT INTO order_line (ol_o_id, ol_d_id, ol_w_id, ol_number, ol_i_id, ol_supply_w_id, ol_quantity, ol_amount, ol_dist_info)
        VALUES (o_id, no_d_id, no_w_id, loop_counter, no_ol_i_id, no_ol_supply_w_id, no_ol_quantity, no_ol_amount, no_ol_dist_info);
        set loop_counter = loop_counter + 1;
        END WHILE;
        INSERT INTO orders (o_id, o_d_id, o_w_id, o_c_id, o_entry_d, o_ol_cnt, o_all_local) VALUES (o_id, no_d_id, no_w_id, no_c_id, timestamp, no_o_ol_cnt, no_o_all_local);
        INSERT INTO new_order (no_o_id, no_d_id, no_w_id) VALUES (o_id, no_d_id, no_w_id);
        COMMIT;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `OSTAT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`bench`@`127.0.0.1` PROCEDURE `OSTAT`(
        os_w_id                 INTEGER,
        os_d_id                 INTEGER,
        INOUT os_c_id           INTEGER,
        byname                  INTEGER,
        INOUT os_c_last         VARCHAR(16),
        OUT os_c_first          VARCHAR(16),
        OUT os_c_middle         CHAR(2),
        OUT os_c_balance        DECIMAL(12,2),
        OUT os_o_id             INTEGER,
        OUT os_entdate          DATETIME,
        OUT os_o_carrier_id     INTEGER
        )
BEGIN 
        DECLARE  os_ol_i_id 	INTEGER;
        DECLARE  os_ol_supply_w_id INTEGER;
        DECLARE  os_ol_quantity INTEGER;
        DECLARE  os_ol_amount 	INTEGER;
        DECLARE  os_ol_delivery_d 	DATETIME;
        DECLARE done            INT DEFAULT 0;
        DECLARE namecnt         INTEGER;
        DECLARE i               INTEGER;
        DECLARE loop_counter    INT;
        DECLARE no_order_status VARCHAR(100);
        DECLARE os_ol_i_id_array VARCHAR(200);
        DECLARE os_ol_supply_w_id_array VARCHAR(200);
        DECLARE os_ol_quantity_array VARCHAR(200);
        DECLARE os_ol_amount_array VARCHAR(200);
        DECLARE os_ol_delivery_d_array VARCHAR(420);
        DECLARE `Constraint Violation` CONDITION FOR SQLSTATE '23000';
        DECLARE c_name CURSOR FOR
        SELECT c_balance, c_first, c_middle, c_id
        FROM customer
        WHERE c_last = os_c_last AND c_d_id = os_d_id AND c_w_id = os_w_id
        ORDER BY c_first;
        DECLARE c_line CURSOR FOR
        SELECT ol_i_id, ol_supply_w_id, ol_quantity,
        ol_amount, ol_delivery_d
        FROM order_line
        WHERE ol_o_id = os_o_id AND ol_d_id = os_d_id AND ol_w_id = os_w_id;
        DECLARE EXIT HANDLER FOR `Constraint Violation` ROLLBACK;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
        set no_order_status = '';
        set os_ol_i_id_array = 'CSV,';
        set os_ol_supply_w_id_array = 'CSV,';
        set os_ol_quantity_array = 'CSV,';
        set os_ol_amount_array = 'CSV,';
        set os_ol_delivery_d_array = 'CSV,';
        START TRANSACTION;
        IF ( byname = 1 )
        THEN
        SELECT count(c_id) INTO namecnt
        FROM customer
        WHERE c_last = os_c_last AND c_d_id = os_d_id AND c_w_id = os_w_id;
        IF ( MOD (namecnt, 2) = 1 )
        THEN
        SET namecnt = (namecnt + 1);
        END IF;
        OPEN c_name;
        SET loop_counter = 0;
        WHILE loop_counter <= (namecnt/2) DO
        FETCH c_name
        INTO os_c_balance, os_c_first, os_c_middle, os_c_id;
        set loop_counter = loop_counter + 1;
        END WHILE;
        close c_name;
        ELSE
        SELECT c_balance, c_first, c_middle, c_last
        INTO os_c_balance, os_c_first, os_c_middle, os_c_last
        FROM customer
        WHERE c_id = os_c_id AND c_d_id = os_d_id AND c_w_id = os_w_id;
        END IF;
        set done = 0;
        SELECT o_id, o_carrier_id, o_entry_d
        INTO os_o_id, os_o_carrier_id, os_entdate
        FROM
        (SELECT o_id, o_carrier_id, o_entry_d
        FROM orders where o_d_id = os_d_id AND o_w_id = os_w_id and o_c_id = os_c_id
        ORDER BY o_id DESC) AS sb LIMIT 1;
        IF done THEN
        set no_order_status = 'No orders for customer';
        END IF;
        set done = 0;
        set i = 0;
        OPEN c_line;
        REPEAT
        FETCH c_line INTO os_ol_i_id, os_ol_supply_w_id, os_ol_quantity, os_ol_amount, os_ol_delivery_d;
        IF NOT done THEN
        set os_ol_i_id_array = CONCAT(os_ol_i_id_array,',',CAST(i AS CHAR),',',CAST(os_ol_i_id AS CHAR));
        set os_ol_supply_w_id_array = CONCAT(os_ol_supply_w_id_array,',',CAST(i AS CHAR),',',CAST(os_ol_supply_w_id AS CHAR));
        set os_ol_quantity_array = CONCAT(os_ol_quantity_array,',',CAST(i AS CHAR),',',CAST(os_ol_quantity AS CHAR));
        set os_ol_amount_array = CONCAT(os_ol_amount_array,',',CAST(i AS CHAR),',',CAST(os_ol_amount AS CHAR));
        set os_ol_delivery_d_array = CONCAT(os_ol_delivery_d_array,',',CAST(i AS CHAR),',',CAST(os_ol_delivery_d AS CHAR));
        set i = i+1;
        END IF;
        UNTIL done END REPEAT;
        CLOSE c_line;
        COMMIT;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PAYMENT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`bench`@`127.0.0.1` PROCEDURE `PAYMENT`(
        p_w_id			INTEGER,
        p_d_id			INTEGER,
        p_c_w_id		INTEGER,
        p_c_d_id		INTEGER,
        INOUT p_c_id		INTEGER,
        byname			INTEGER,
        p_h_amount		DECIMAL(6,2),
        INOUT p_c_last	  	VARCHAR(16),
        OUT p_w_street_1  	VARCHAR(20),
        OUT p_w_street_2  	VARCHAR(20),
        OUT p_w_city		VARCHAR(20),
        OUT p_w_state		CHAR(2),
        OUT p_w_zip		CHAR(9),
        OUT p_d_street_1	VARCHAR(20),
        OUT p_d_street_2	VARCHAR(20),
        OUT p_d_city		VARCHAR(20),
        OUT p_d_state		CHAR(2),
        OUT p_d_zip		CHAR(9),
        OUT p_c_first		VARCHAR(16),
        OUT p_c_middle		CHAR(2),
        OUT p_c_street_1	VARCHAR(20),
        OUT p_c_street_2	VARCHAR(20),
        OUT p_c_city		VARCHAR(20),
        OUT p_c_state		CHAR(2),
        OUT p_c_zip		CHAR(9),
        OUT p_c_phone		CHAR(16),
        OUT p_c_since		DATETIME,
        INOUT p_c_credit	CHAR(2),
        OUT p_c_credit_lim 	DECIMAL(12,2),
        OUT p_c_discount	DECIMAL(4,4),
        INOUT p_c_balance 	DECIMAL(12,2),
        OUT p_c_data		VARCHAR(500),
        IN timestamp		DATETIME
        )
BEGIN
        DECLARE done      	INT DEFAULT 0;
        DECLARE	namecnt		INTEGER;
        DECLARE p_d_name	VARCHAR(11);
        DECLARE p_w_name	VARCHAR(11);
        DECLARE p_c_new_data	VARCHAR(500);
        DECLARE h_data		VARCHAR(30);
        DECLARE loop_counter  	INT;
        DECLARE `Constraint Violation` CONDITION FOR SQLSTATE '23000';
        DECLARE c_byname CURSOR FOR
        SELECT c_first, c_middle, c_id, c_street_1, c_street_2, c_city, c_state, c_zip, c_phone, c_credit, c_credit_lim, c_discount, c_balance, c_since
        FROM customer
        WHERE c_w_id = p_c_w_id AND c_d_id = p_c_d_id AND c_last = p_c_last
        ORDER BY c_first;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
        DECLARE EXIT HANDLER FOR `Constraint Violation` ROLLBACK;
        START TRANSACTION;
        UPDATE warehouse SET w_ytd = w_ytd + p_h_amount
        WHERE w_id = p_w_id;
        SELECT w_street_1, w_street_2, w_city, w_state, w_zip, w_name
        INTO p_w_street_1, p_w_street_2, p_w_city, p_w_state, p_w_zip, p_w_name
        FROM warehouse
        WHERE w_id = p_w_id;
        UPDATE district SET d_ytd = d_ytd + p_h_amount
        WHERE d_w_id = p_w_id AND d_id = p_d_id;
        SELECT d_street_1, d_street_2, d_city, d_state, d_zip, d_name
        INTO p_d_street_1, p_d_street_2, p_d_city, p_d_state, p_d_zip, p_d_name
        FROM district
        WHERE d_w_id = p_w_id AND d_id = p_d_id;
        IF (byname = 1)
        THEN
        SELECT count(c_id) INTO namecnt
        FROM customer
        WHERE c_last = p_c_last AND c_d_id = p_c_d_id AND c_w_id = p_c_w_id;
        OPEN c_byname;
        IF ( MOD (namecnt, 2) = 1 )
        THEN
        SET namecnt = (namecnt + 1);
        END IF;
        SET loop_counter = 0;
        WHILE loop_counter <= (namecnt/2) DO
        FETCH c_byname
        INTO p_c_first, p_c_middle, p_c_id, p_c_street_1, p_c_street_2, p_c_city,
        p_c_state, p_c_zip, p_c_phone, p_c_credit, p_c_credit_lim, p_c_discount, p_c_balance, p_c_since;
        set loop_counter = loop_counter + 1;
        END WHILE;
        CLOSE c_byname;
        ELSE
        SELECT c_first, c_middle, c_last,
        c_street_1, c_street_2, c_city, c_state, c_zip,
        c_phone, c_credit, c_credit_lim,
        c_discount, c_balance, c_since
        INTO p_c_first, p_c_middle, p_c_last,
        p_c_street_1, p_c_street_2, p_c_city, p_c_state, p_c_zip,
        p_c_phone, p_c_credit, p_c_credit_lim,
        p_c_discount, p_c_balance, p_c_since
        FROM customer
        WHERE c_w_id = p_c_w_id AND c_d_id = p_c_d_id AND c_id = p_c_id;
        END IF;
        SET p_c_balance = ( p_c_balance + p_h_amount );
        IF p_c_credit = 'BC'
        THEN
        SELECT c_data INTO p_c_data
        FROM customer
        WHERE c_w_id = p_c_w_id AND c_d_id = p_c_d_id AND c_id = p_c_id;
        SET h_data = CONCAT(p_w_name,' ',p_d_name);
        SET p_c_new_data = CONCAT(CAST(p_c_id AS CHAR),' ',CAST(p_c_d_id AS CHAR),' ',CAST(p_c_w_id AS CHAR),' ',CAST(p_d_id AS CHAR),' ',CAST(p_w_id AS CHAR),' ',CAST(FORMAT(p_h_amount,2) AS CHAR),CAST(timestamp AS CHAR),h_data);
        SET p_c_new_data = SUBSTR(CONCAT(p_c_new_data,p_c_data),1,500-(LENGTH(p_c_new_data)));
        UPDATE customer
        SET c_balance = p_c_balance, c_data = p_c_new_data
        WHERE c_w_id = p_c_w_id AND c_d_id = p_c_d_id AND
        c_id = p_c_id;
        ELSE
        UPDATE customer SET c_balance = p_c_balance
        WHERE c_w_id = p_c_w_id AND c_d_id = p_c_d_id AND
        c_id = p_c_id;
        END IF;
        SET h_data = CONCAT(p_w_name,' ',p_d_name);
        INSERT INTO history (h_c_d_id, h_c_w_id, h_c_id, h_d_id, h_w_id, h_date, h_amount, h_data)
        VALUES (p_c_d_id, p_c_w_id, p_c_id, p_d_id, p_w_id, timestamp, p_h_amount, h_data);
        COMMIT;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SLEV` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`bench`@`127.0.0.1` PROCEDURE `SLEV`(
        st_w_id                 INTEGER,
        st_d_id                 INTEGER,
        threshold               INTEGER,
        OUT stock_count		INTEGER
        )
BEGIN 
        DECLARE st_o_id         INTEGER;
        DECLARE `Constraint Violation` CONDITION FOR SQLSTATE '23000';
        DECLARE EXIT HANDLER FOR `Constraint Violation` ROLLBACK;
        DECLARE EXIT HANDLER FOR NOT FOUND ROLLBACK;
        START TRANSACTION;
        SELECT d_next_o_id INTO st_o_id
        FROM district
        WHERE d_w_id=st_w_id AND d_id=st_d_id;
        SELECT COUNT(DISTINCT (s_i_id)) INTO stock_count
        FROM order_line, stock
        WHERE ol_w_id = st_w_id AND
        ol_d_id = st_d_id AND (ol_o_id < st_o_id) AND
        ol_o_id >= (st_o_id - 20) AND s_w_id = st_w_id AND
        s_i_id = ol_i_id AND s_quantity < threshold;
        COMMIT;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

