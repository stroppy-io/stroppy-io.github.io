#!/usr/bin/env python3
"""Expand the proposed, approval-gated paired campaign into immutable run specifications."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("campaign", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    campaign = json.loads(args.campaign.read_text())
    args.output.mkdir(exist_ok=False)
    sequence = 0
    for family in campaign["families"]:
        for repetition in range(1, campaign["repetitions"] + 1):
            for placement in campaign["placements"]:
                engines = ["original", "stroppy"]
                if (repetition == 1 and placement["name"] == "private_lan") or (
                    repetition == 2 and placement["name"] == "local"
                ):
                    engines.reverse()
                for engine in engines:
                    sequence += 1
                    name = f'{campaign["id"]}-{family["name"]}-{placement["name"]}-{engine}-r{repetition}'
                    spec = {
                        "id": name,
                        "sequence": sequence,
                        "status": "proposed_not_started",
                        "family": family,
                        "engine": engine,
                        "placement": placement,
                        "repetition": repetition,
                        "warehouses": campaign["warehouses"],
                        "active_clients": campaign["active_clients"],
                        "warmup_seconds": campaign["warmup_seconds"],
                        "measurement_seconds": campaign["measurement_seconds"],
                        "resources": campaign["resources"],
                        "reset_policy": campaign["reset_policy"],
                        "artifact": campaign["stroppy"] if engine == "stroppy" else family,
                    }
                    (args.output / f"{sequence:02d}-{name}.json").write_text(json.dumps(spec, indent=2) + "\n")
    if sequence != campaign["measured_invocations"]:
        raise ValueError(f"expanded {sequence}, expected {campaign['measured_invocations']}")
    print(f"Prepared {sequence} proposed run specifications; no remote action executed.")


if __name__ == "__main__":
    main()
