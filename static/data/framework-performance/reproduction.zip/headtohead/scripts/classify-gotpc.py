#!/usr/bin/env python3
"""Separate verified end-of-budget cancellation from workload errors; retain raw logs."""
import argparse
import datetime
import json
from pathlib import Path
import re
from zoneinfo import ZoneInfo


def classify(meta, spec, stdout):
    duration = spec['warmup_seconds'] + spec['measurement_seconds']
    deadline = meta['started_epoch'] + duration
    workers = {}
    errors = 0
    reasons = []
    for match in re.finditer(r'^\[([^\]]+)\] run worker (\d+) stopped due to timeout(?P<detail>.*)$', stdout, re.M):
        stamp = datetime.datetime.strptime(match[1], '%Y-%m-%d %H:%M:%S').replace(tzinfo=ZoneInfo('Europe/Moscow')).timestamp()
        if abs(stamp - deadline) > 2:
            reasons.append('worker timeout occurred outside budget boundary')
        worker = int(match[2])
        if worker in workers:
            reasons.append('duplicate timeout completion for one worker')
        workers[worker] = stamp
        if match['detail'].startswith(':'):
            errors += 1
    summaries = {match[1]: int(match[2]) for match in re.finditer(r'^\[Summary\] (\w+_ERR) - .*?Count: (\d+),', stdout, re.M)}
    interval_errors = sum(int(match[1]) for match in re.finditer(r'^\[Current\] \w+_ERR - .*?Count: (\d+),', stdout, re.M))
    if interval_errors:
        reasons.append('in-window error histogram entries')
    if sum(summaries.values()) != errors:
        reasons.append('final error histograms not accounted for by timeout records')
    if set(workers) != set(range(spec['active_clients'])):
        reasons.append('not every configured worker reached the deadline')
    for marker in ('execute run failed', 'panic', 'connection refresh failed'):
        if marker in stdout:
            reasons.append(marker)
    if meta.get('exit_code') != 0:
        reasons.append('nonzero client exit')
    if meta.get('finished_epoch', 0) < deadline - 1:
        reasons.append('client finished before its time budget')
    return {'valid_completion': not reasons, 'classification': 'budget_boundary_cancellation' if not reasons else 'invalid', 'boundary_query_errors': errors, 'final_error_histograms': summaries, 'deadline_workers': len(workers), 'in_window_histogram_errors': interval_errors, 'reasons': reasons, 'rule': 'all workers finish at planned deadline; final error counts exactly match those boundary stops; no in-window error histogram or worker failure'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    args = parser.parse_args()
    meta = json.loads((args.run / 'meta.json').read_text())
    spec = json.loads((args.run / 'spec.json').read_text())
    result = classify(meta, spec, (args.run / 'stdout.log').read_text())
    (args.run / 'completion-classification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    if not result['valid_completion']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
