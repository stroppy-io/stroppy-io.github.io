#!/usr/bin/env python3
"""Calibrate the second loaded family and execute only the approved valid matrix."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')
ready = ROOT / 'configs/ready-for-gotpc-calibration'
while not ready.exists():
    state = subprocess.check_output(['systemctl', 'show', 'bench-h2h-next-family', '-p', 'ActiveState', '--value'], text=True).strip()
    if state not in ('active', 'activating'):
        raise SystemExit('second-family preparation stopped; inspect before resuming')
    time.sleep(30)
source = next(path for path in sorted((ROOT / 'specs/matrix-proposed').glob('*.json')) if json.loads(path.read_text())['family']['name'] == 'go-tpc')
spec = json.loads(source.read_text())
spec.update(id='tpcc-headtohead-20261028-gotpc-local-original-calibration01', warmup_seconds=60, measurement_seconds=60, repetition=0)
path = ROOT / 'specs/gotpc-calibration01.json'
if path.exists():
    raise SystemExit('existing second-family calibration needs explicit review')
path.write_text(json.dumps(spec, indent=2) + '\n')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/run-case.py'), str(path)], check=True)
directory = ROOT / 'runs' / spec['id']
subprocess.run(['python3', '-I', str(ROOT / 'scripts/summarize.py'), str(directory)], check=True)
rows = [json.loads(line) for line in (directory / 'monitor/samples.jsonl').read_text().splitlines()]
rows = [row for row in rows if 'mysql' in row]
if len(rows) < 10:
    raise SystemExit('insufficient go-tpc calibration evidence')
for name in ('Innodb_log_waits', 'Innodb_buffer_pool_wait_free'):
    if rows[-1]['mysql'].get(name, 0) != rows[0]['mysql'].get(name, 0):
        raise SystemExit('go-tpc resource stall: ' + name)
freeze = {'status': 'same_config_as_hammerdb', 'calibration': str(directory), 'buffer_pool_gib': 512, 'redo_gib': 32, 'changes_after_calibration': []}
(ROOT / 'configs/frozen-go-tpc.json').write_text(json.dumps(freeze, indent=2) + '\n')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/campaign.py'), 'go-tpc'], check=True)
(ROOT / 'configs/all-measurements-completed').write_text('Both approved matrices completed with valid summaries.\n')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/charts.py'), str(ROOT / 'runs'), str(ROOT / 'summaries/runtime.html')], check=True)
subprocess.run(['bash', str(ROOT / 'scripts/restore-original.sh')], check=True)
