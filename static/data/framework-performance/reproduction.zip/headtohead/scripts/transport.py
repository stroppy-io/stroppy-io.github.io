#!/usr/bin/env python3
"""Narrow SSH receiver for campaign-only specifications, client units, and evidence."""
import base64
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import time

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')
parts = shlex.split(os.environ.get('SSH_ORIGINAL_COMMAND', ''))
if len(parts) != 2 or parts[0] not in ('put', 'start', 'status', 'archive'):
    raise SystemExit('unsupported campaign transport operation')
action, value = parts
if action == 'put':
    data = base64.b64decode(value, validate=True)
    spec = json.loads(data)
    name = spec['id']
    if not re.fullmatch(r'tpcc-headtohead-20261028-[a-zA-Z0-9_-]+', name):
        raise SystemExit('invalid campaign id')
    path = ROOT / 'specs' / (name + '.resolved.json')
    with path.open('xb') as output:
        output.write(data)
    print(name)
else:
    name = value
    if not re.fullmatch(r'tpcc-headtohead-20261028-[a-zA-Z0-9_-]+', name):
        raise SystemExit('invalid campaign id')
    unit = 'bench-h2h-' + name.replace('tpcc-headtohead-20261028-', '')
    if action == 'start':
        subprocess.run(['systemd-run', '--unit=' + unit, '--property=AllowedCPUs=24-31', '--property=NUMAPolicy=interleave', '--property=NUMAMask=0-1', '--property=LimitNOFILE=1048576', '/usr/bin/python3', '-I', str(ROOT / 'scripts/client.py'), str(ROOT / 'specs' / (name + '.resolved.json'))], check=True)
        deadline = time.monotonic() + 10
        while not (ROOT / 'runs' / name / 'meta.json').exists():
            if time.monotonic() > deadline:
                raise TimeoutError('client did not prepare run directory')
            time.sleep(0.1)
        subprocess.run(['systemd-run', '--unit=' + unit + '-samples', '--property=AllowedCPUs=56-59', '/usr/bin/python3', '-I', str(ROOT / 'scripts/sampler.py'), str(ROOT / 'runs' / name / 'client-monitor'), '--seconds=1100'], check=True)
    elif action == 'status':
        subprocess.run(['systemctl', 'show', unit, '-p', 'ActiveState', '--value'], check=True)
    elif action == 'archive':
        directory = ROOT / 'runs' / name
        subprocess.run(['systemctl', 'stop', unit + '-samples'], check=True)
        if not (directory / 'meta.json').exists():
            raise SystemExit('client metadata missing')
        subprocess.run(['tar', '-C', str(directory), '-czf', '-', '.'], check=True)
