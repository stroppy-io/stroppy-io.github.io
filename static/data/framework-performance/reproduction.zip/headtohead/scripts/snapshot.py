#!/usr/bin/env python3
"""Create and restore complete cold campaign datadirs, refusing external paths."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')
DATA = Path('/storage1/stroppy-tpcc-headtohead-20261028/mysql')
WORK = DATA / 'work'
UNIT = 'bench-tpcc-headtohead-mysql'
SOCKET = ROOT / 'mysql.sock'


def command(args):
    subprocess.run(args, check=True)


def sql(statement):
    command(['mysql', '--socket=' + str(SOCKET), '-e', statement])


def stopped():
    if subprocess.run(['systemctl', 'is-active', '--quiet', UNIT]).returncode == 0:
        raise RuntimeError('campaign MySQL is still active')


def digest(directory):
    result = []
    for path in sorted(directory.rglob('*')):
        if not path.is_file():
            continue
        value = hashlib.sha256()
        with path.open('rb') as stream:
            while block := stream.read(16 * 1024 * 1024):
                value.update(block)
        result.append({'path': str(path.relative_to(directory)), 'size': path.stat().st_size, 'sha256': value.hexdigest()})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['save', 'restore'])
    parser.add_argument('family', choices=['hammerdb', 'go-tpc'])
    parser.add_argument('record', type=Path)
    args = parser.parse_args()
    if ROOT not in args.record.resolve().parents:
        raise RuntimeError('record must stay in campaign root')
    args.record.mkdir(exist_ok=False, parents=True)
    template = DATA / ('template-' + args.family)
    manifest = ROOT / 'manifests' / (args.family + '-snapshot.json')
    if shutil.disk_usage(DATA).free < 1024 ** 4:
        raise RuntimeError('less than 1 TiB free')
    if args.action == 'save':
        if template.exists() or manifest.exists():
            raise RuntimeError('pristine template already exists')
        sql('SET GLOBAL innodb_fast_shutdown=0')
        command(['systemctl', 'stop', UNIT])
        stopped()
        template.mkdir()
        command(['rsync', '-aH', '--numeric-ids', str(WORK) + '/', str(template) + '/'])
        records = digest(template)
        if digest(WORK) != records:
            raise RuntimeError('snapshot copy differs from stopped source')
        manifest.write_text(json.dumps({'family': args.family, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'files': records}, indent=2) + '\n')
        shutil.copy2(ROOT / 'configs/mysql.cnf', args.record / 'mysql.cnf')
        subprocess.run(['chmod', '-R', 'a-w', str(template)], check=True)
    else:
        if not template.is_dir() or not manifest.exists():
            raise RuntimeError('no verified template')
        command(['systemctl', 'stop', UNIT])
        stopped()
        expected = json.loads(manifest.read_text())['files']
        if digest(template) != expected:
            raise RuntimeError('pristine snapshot changed')
        if WORK.is_symlink() or WORK.resolve() != DATA / 'work':
            raise RuntimeError('working datadir confinement failed')
        command(['rsync', '-aH', '--delete', '--numeric-ids', str(template) + '/', str(WORK) + '/'])
        command(['chmod', '-R', 'u+w', str(WORK)])
        command(['chown', '-R', 'mysql:mysql', str(WORK)])
        expected_names = {entry['path'] for entry in expected}
        actual_names = {str(path.relative_to(WORK)) for path in WORK.rglob('*') if path.is_file()}
        if expected_names != actual_names:
            raise RuntimeError('restored datadir file set differs')
        os_record = args.record / 'restore-command.json'
        os_record.write_text(json.dumps({'source': str(template), 'destination': str(WORK), 'server_stopped': True}, indent=2) + '\n')
        if digest(WORK) != expected:
            raise RuntimeError('restored datadir differs from template')
    (args.record / 'complete.json').write_text(json.dumps({'action': args.action, 'family': args.family, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'template': str(template), 'verified_files': len(json.loads(manifest.read_text())['files'])}, indent=2) + '\n')
    command(['systemctl', 'start', UNIT])
    deadline = time.monotonic() + 600
    while subprocess.run(['mysqladmin', '--socket=' + str(SOCKET), 'ping'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0:
        if time.monotonic() > deadline:
            raise TimeoutError('restored MySQL not ready')
        time.sleep(2)


if __name__ == '__main__':
    main()
