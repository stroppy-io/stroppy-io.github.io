#!/usr/bin/env bash
set -euo pipefail
root=/opt/stroppy-tpcc-headtohead-20261028
[[ -f "$root/configs/all-measurements-completed" ]] || { printf 'matrix not complete; refuse restoration\n' >&2; exit 1; }
mkdir "$root/cleanup"
mysql --socket="$root/mysql.sock" -NBe 'SHOW GLOBAL VARIABLES' > "$root/cleanup/final-variables.txt"
cp "$root/logs/mysql-error.log" "$root/cleanup/mysql-error.log"
systemctl stop bench-tpcc-headtohead-mysql
if systemctl is-active --quiet bench-tpcc-headtohead-mysql; then exit 1; fi
lockfile="$root/invocation.lock"
exec 9>"$lockfile"
flock -n 9
printf 'campaign client invocation lock acquired after measurements\n' > "$root/cleanup/lock-check.txt"
cp -p /etc/apparmor.d/local/usr.sbin.mysqld "$root/cleanup/apparmor-before-restore"
cp -p "$root/inventory/apparmor-local-original" /etc/apparmor.d/local/usr.sbin.mysqld
apparmor_parser -r /etc/apparmor.d/usr.sbin.mysqld
systemctl start bench-mysql
for _ in $(seq 1 180); do
  if mysqladmin --socket=/run/mysqld/bench.sock ping >/dev/null 2>&1; then break; fi
  sleep 2
done
mysqladmin --socket=/run/mysqld/bench.sock ping
systemctl show bench-mysql bench-postgres bench-tpcc-headtohead-mysql -p Id -p ActiveState > "$root/cleanup/restored-services.txt"
if ! systemctl is-active --quiet bench-mysql; then exit 1; fi
if systemctl is-active --quiet bench-postgres; then exit 1; fi
public=$(awk '{print $2}' "$root/client_ed25519.pub")
printf '%s\n' "$public" > "$root/cleanup/campaign-control-public-key.txt"
printf 'Remove only this authorized-key line on bm0 using laptop administration, then delete private client_ed25519 on bm1.\n' > "$root/cleanup/transport-key-removal-pending.txt"
printf '{"status":"original_services_restored","utc":"%s"}\n' "$(date -u +%FT%TZ)" > "$root/cleanup/complete.json"
