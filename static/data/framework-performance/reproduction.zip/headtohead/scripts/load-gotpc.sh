#!/usr/bin/env bash
set -euo pipefail
root=/opt/stroppy-tpcc-headtohead-20261028
run="$root/runs/load-gotpc-sf1000"
mkdir "$run"
exec 9>"$root/invocation.lock"
flock -n 9
mysql --socket="$root/mysql.sock" -e 'CREATE DATABASE gotpc_sf1000'
printf '{"id":"load-gotpc-sf1000","status":"running","started":"%s","warehouses":1000,"workers":16}\n' "$(date -u +%FT%TZ)" > "$run/meta.json"
export GOMAXPROCS=8
set +e
"$root/artifacts/go-tpc" -d mysql -H 127.0.0.1 -P 3307 -U bench -p bench -D gotpc_sf1000 -T 16 --max-procs=8 tpcc --warehouses=1000 prepare --no-check --retry-count=0 > "$run/stdout.log" 2>&1
code=$?
set -e
status=failed
if [[ "$code" == 0 ]] && grep -q '^Finished' "$run/stdout.log" && ! grep -Eqi 'panic|fatal|exec statement error|prepare failed' "$run/stdout.log"; then status=completed; fi
jq --arg status "$status" --arg finished "$(date -u +%FT%TZ)" --argjson code "$code" '. + {status:$status,finished:$finished,exit_code:$code}' "$run/meta.json" > "$run/meta.tmp"
mv "$run/meta.tmp" "$run/meta.json"
[[ "$status" == completed ]]
