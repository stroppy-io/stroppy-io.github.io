#!/usr/bin/env python3
"""Resume after diagnosing the first calibration's end-of-budget cancellation."""
import datetime
import json
from pathlib import Path
import subprocess

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')
directory = ROOT / 'runs/tpcc-headtohead-20261028-gotpc-local-original-calibration01'
subprocess.run(['python3', '-I', str(ROOT / 'scripts/classify-gotpc.py'), str(directory)], check=True)
meta = json.loads((directory / 'meta.json').read_text())
(directory / 'meta-before-completion-classification.json').write_text(json.dumps(meta, indent=2) + '\n')
meta.update(status='completed', completion_classification=json.loads((directory / 'completion-classification.json').read_text()), reclassified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(directory / 'meta.json').write_text(json.dumps(meta, indent=2) + '\n')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/summarize.py'), str(directory)], check=True)
rows = [json.loads(line) for line in (directory / 'monitor/samples.jsonl').read_text().splitlines()]
rows = [row for row in rows if 'mysql' in row]
for name in ('Innodb_log_waits', 'Innodb_buffer_pool_wait_free'):
    if rows[-1]['mysql'].get(name, 0) != rows[0]['mysql'].get(name, 0):
        raise SystemExit('calibration resource stall: ' + name)
(ROOT / 'configs/frozen-go-tpc.json').write_text(json.dumps({'status': 'same_config_as_hammerdb', 'calibration': str(directory), 'completion_classification': str(directory / 'completion-classification.json'), 'buffer_pool_gib': 512, 'redo_gib': 32, 'changes_after_calibration': []}, indent=2) + '\n')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/campaign.py'), 'go-tpc'], check=True)
(ROOT / 'configs/all-measurements-completed').write_text('Both approved matrices completed with valid summaries.\n')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/charts.py'), str(ROOT / 'runs'), str(ROOT / 'summaries/runtime.html')], check=True)
subprocess.run(['bash', str(ROOT / 'scripts/restore-original.sh')], check=True)
