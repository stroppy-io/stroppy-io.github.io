#!/usr/bin/env python3
"""Watch external supervised state and copy evidence only between completed invocations."""
import argparse
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
KEY = '/Users/ariel/.ssh/ssh-key-postgres-august'
HOST = 'root@185.184.128.203'
REMOTE = '/opt/stroppy-tpcc-headtohead-20261028'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--completed', type=int, default=2)
    parser.add_argument('--seconds', type=int, default=3600)
    args = parser.parse_args()
    seen = set()
    started = time.monotonic()
    while time.monotonic() - started < args.seconds:
        result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', '-i', KEY, HOST, f"find {REMOTE}/runs -maxdepth 2 -name summary.json -printf '%h\\n'; systemctl show bench-h2h-hammer-measurements -p ActiveState -p ExecMainStatus"], capture_output=True, text=True, timeout=60)
        if result.returncode:
            print('SSH observation failed; retrying without relaunching work', flush=True)
            time.sleep(60)
            continue
        lines = result.stdout.splitlines()
        paths = {line for line in lines if line.startswith(REMOTE + '/runs/') and 'calibration' not in line}
        if paths - seen:
            subprocess.run(['bash', str(ROOT / 'scripts/sync.sh')], check=True)
            seen |= paths
            print(json.dumps({'completed_summaries': len(paths), 'new': sorted(paths), 'state': [line for line in lines if not line.startswith('/')] }), flush=True)
        if len(paths) >= args.completed:
            return
        if 'ActiveState=failed' in lines or 'ActiveState=inactive' in lines:
            subprocess.run(['bash', str(ROOT / 'scripts/sync.sh')], check=True)
            raise SystemExit('supervised campaign stopped before requested completion count')
        time.sleep(60)
    raise SystemExit('watch timeout; remote work not canceled')


if __name__ == '__main__':
    main()
