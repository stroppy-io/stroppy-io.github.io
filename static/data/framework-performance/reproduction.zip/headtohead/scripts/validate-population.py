#!/usr/bin/env python3
"""Validate SF1000 table totals and district population without correlated full checks."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')
SOCKET = ROOT / 'mysql.sock'


def query(sql):
    result = subprocess.run(['mysql', '--socket=' + str(SOCKET), '-N', '-B', '-e', sql], capture_output=True, text=True, check=True)
    return result.stdout.strip().splitlines()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('database', choices=['hammer_sf1000', 'gotpc_sf1000'])
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    expected = {'warehouse': 1000, 'district': 10000, 'stock': 100000000, 'item': 100000, 'customer': 30000000, 'history': 30000000, 'orders': 30000000, 'new_order': 9000000}
    result = {'database': args.database, 'started': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'tables': {}, 'valid': False}
    for table in (*expected, 'order_line'):
        started = time.monotonic()
        count = int(query(f'SELECT COUNT(*) FROM `{args.database}`.`{table}`')[0])
        result['tables'][table] = {'rows': count, 'elapsed_seconds': time.monotonic() - started}
        args.output.write_text(json.dumps(result, indent=2) + '\n')
        if table in expected and count != expected[table]:
            raise RuntimeError(f'{table}: {count}, expected {expected[table]}')
    checks = {
        'warehouse_keys': f'SELECT MIN(w_id),MAX(w_id),COUNT(DISTINCT w_id) FROM `{args.database}`.warehouse',
        'district_keys': f'SELECT MIN(d_id),MAX(d_id),MIN(d_next_o_id),MAX(d_next_o_id),SUM(d_next_o_id) FROM `{args.database}`.district',
        'order_lines_expected': f'SELECT SUM(o_ol_cnt) FROM `{args.database}`.orders',
        'customer_district_errors': f'SELECT COUNT(*) FROM (SELECT c_w_id,c_d_id,COUNT(*) n FROM `{args.database}`.customer GROUP BY c_w_id,c_d_id HAVING n<>3000) t',
        'order_district_errors': f'SELECT COUNT(*) FROM (SELECT o_w_id,o_d_id,COUNT(*) n FROM `{args.database}`.orders GROUP BY o_w_id,o_d_id HAVING n<>3000) t',
    }
    result['checks'] = {name: query(sql) for name, sql in checks.items()}
    if int(result['checks']['order_lines_expected'][0]) != result['tables']['order_line']['rows']:
        raise RuntimeError('order-line total differs from orders.ol_cnt')
    if result['checks']['district_keys'][0] != '1\t10\t3001\t3001\t30010000':
        raise RuntimeError('district key or next-order state differs')
    for name in ('customer_district_errors', 'order_district_errors'):
        if result['checks'][name] != ['0']:
            raise RuntimeError(name)
    result['valid'] = True
    result['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    args.output.write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
