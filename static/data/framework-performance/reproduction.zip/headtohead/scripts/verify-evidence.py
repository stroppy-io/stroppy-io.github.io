#!/usr/bin/env python3
"""Verify paired results against raw counters, frozen settings and restore records."""
import argparse
import datetime
import hashlib
import json
import math
from pathlib import Path


def load(path):
    return json.loads(path.read_text())


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    args = parser.parse_args()
    root = args.root
    specifications = [load(path) for path in sorted((root / 'specs/matrix-proposed').glob('*.json'))]
    assert len(specifications) == 16, 'expected exactly 16 approved specifications'
    results = load(root / 'summaries/results.json')
    assert results['status'] == 'complete' and results['valid_cases'] == 16 and results['completed_pairs'] == 8
    cases = []
    configurations = set()
    schemas = {}
    windows = []
    for spec in specifications:
        directory = root / 'runs/bm1' / spec['id']
        summary = load(directory / 'summary.json')
        meta = load(directory / 'meta.json')
        actual_spec = load(directory / 'spec.json')
        for key in ('id', 'family', 'engine', 'placement', 'repetition', 'active_clients', 'warmup_seconds', 'measurement_seconds'):
            assert actual_spec[key] == spec[key], (spec['id'], 'specification changed', key)
        assert summary['valid'] and meta['exit_code'] == 0
        classification = meta.get('completion_classification', {})
        if spec['family']['name'] == 'go-tpc':
            if spec['engine'] == 'original':
                assert classification['valid_completion'] and classification['deadline_workers'] == 32
                assert classification['in_window_histogram_errors'] == 0
            else:
                report = load(directory / 'report.json')
                assert report.get('errors') == meta.get('errors')
                if meta['status'] == 'completed_with_errors':
                    assert meta['measurement_valid_boundary_only'] and classification['measurement_valid']
                    assert classification['failed_queries'] == 0
        else:
            assert meta['status'] == 'completed'
        if spec['engine'] == 'stroppy':
            report = load(directory / 'report.json')
            assert report.get('errors') == meta.get('errors')
            assert not report.get('errors', {}).get('failed_queries', 0)
            assert not report.get('errors', {}).get('retry_attempts', 0)
        records = [json.loads(line) for line in (directory / 'monitor/samples.jsonl').read_text().splitlines()]
        assert not any('sample_error' in row for row in records)
        end = spec['warmup_seconds'] + spec['measurement_seconds']
        measured = [row for row in records if spec['warmup_seconds'] <= datetime.datetime.fromisoformat(row['utc']).timestamp() - meta['started_epoch'] <= end and 'new_orders' in row and 'mysql' in row]
        assert len(measured) >= 118
        expected_sessions = spec['active_clients'] + (spec['family']['name'] == 'hammerdb')
        assert all(sum(line.startswith('bench\t') for line in row.get('sessions', [])) == expected_sessions for row in measured)
        intervals = [after['monotonic'] - before['monotonic'] for before, after in zip(measured, measured[1:])]
        assert all(0 < seconds < 12 for seconds in intervals)
        first, last = measured[0], measured[-1]
        seconds = last['monotonic'] - first['monotonic']
        orders = last['new_orders'] - first['new_orders']
        assert seconds >= spec['measurement_seconds'] - 12
        assert orders == summary['committed_new_orders']
        assert math.isclose(orders / seconds, summary['new_orders_per_second'], rel_tol=1e-12)
        assert math.isclose(seconds, summary['actual_measurement_seconds'], rel_tol=1e-12)
        assert first['utc'] == summary['first_utc'] and last['utc'] == summary['last_utc']
        paired = next(pair for pair in results['pairs'] if pair['family'] == spec['family']['name'] and pair['placement'] == spec['placement']['name'] and pair['repetition'] == spec['repetition'])
        key = 'original_new_orders_per_second' if spec['engine'] == 'original' else 'sdk_new_orders_per_second'
        assert math.isclose(paired[key], orders / seconds, rel_tol=1e-12)
        assert math.isclose(paired['sdk_over_original'], paired['sdk_new_orders_per_second'] / paired['original_new_orders_per_second'], rel_tol=1e-12)
        for counter, total in (('Com_commit', 'commits'), ('Com_rollback', 'rollbacks')):
            assert last['mysql'][counter] - first['mysql'][counter] == summary[total]
        waits = {key: last['mysql'][key] - first['mysql'][key] for key in ('Innodb_log_waits', 'Innodb_buffer_pool_wait_free')}
        assert all(value == 0 for value in waits.values()), (spec['id'], waits)
        restore = root / 'remote/bm1/restores' / spec['id']
        reset = load(restore / 'complete.json')
        assert reset['family'] == spec['family']['name'] and reset['action'] == 'restore' and reset['verified_files'] > 0
        manifest = load(root / 'remote/bm1/manifests' / (spec['family']['name'] + '-snapshot.json'))
        assert reset['verified_files'] == len(manifest['files'])
        configurations.add(sha256(restore / 'mysql-config.txt'))
        schemas.setdefault(spec['family']['name'], set()).add(sha256(restore / 'schema.sql'))
        windows.append((meta['started_epoch'], meta['finished_epoch'], spec['id']))
        cases.append({'id': spec['id'], 'new_orders_per_second': orders / seconds, 'measurement_seconds': seconds, 'sessions': expected_sessions, 'sample_errors': 0, 'maximum_interval_seconds': max(intervals), 'boundary_operation_errors': classification.get('boundary_failed_operations', classification.get('boundary_query_errors', 0)), 'boundary_cleanup_errors': classification.get('boundary_terminal_cleanup_errors', 0), 'wait_deltas': waits})
    assert len(configurations) == 1, 'effective MySQL settings differ'
    assert all(len(values) == 1 for values in schemas.values()), 'family schema/routine definitions differ'
    windows.sort()
    assert all(previous[1] <= current[0] for previous, current in zip(windows, windows[1:])), 'client invocations overlap'
    cleanup = load(root / 'remote/bm1/cleanup/complete.json')
    assert cleanup['status'] == 'original_services_restored'
    receipt = {'status': 'verified', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'measured_cases': len(cases), 'pairs': results['completed_pairs'], 'effective_mysql_variables_sha256': sorted(configurations), 'schema_sha256': {key: sorted(values) for key, values in schemas.items()}, 'no_client_overlap': True, 'original_services_restore_record': cleanup, 'cases': cases}
    (root / 'summaries/verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'status': receipt['status'], 'measured_cases': len(cases), 'pairs': results['completed_pairs']}))


if __name__ == '__main__':
    main()
