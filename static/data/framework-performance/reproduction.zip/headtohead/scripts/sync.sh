#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
key=/Users/ariel/.ssh/ssh-key-postgres-august
remote=/opt/stroppy-tpcc-headtohead-20261028
mkdir -p "$root/remote/bm0" "$root/remote/bm1" "$root/runs/bm0" "$root/runs/bm1"
for pair in 'bm0 185.184.128.61' 'bm1 185.184.128.203'; do
  read -r name host <<< "$pair"
  rsync -az --exclude 'mysql.sock' --exclude 'mysql.sock.lock' --exclude 'mysql.pid' --exclude 'client_ed25519' --exclude 'authorized_keys-before' --exclude 'transport-authorized-key' --exclude 'artifacts/' --exclude 'homes/' \
    -e "ssh -i $key" "root@$host:$remote/" "$root/remote/$name/"
  rsync -a "$root/remote/$name/runs/" "$root/runs/$name/"
done
python3 -I "$root/scripts/charts.py" "$root/runs/bm1" "$root/summaries/runtime.html"
python3 -I "$root/scripts/report.py" "$root"
