set root $::env(CAMPAIGN_ROOT)
set db $::env(BENCH_DATABASE)
set warehouses $::env(BENCH_WAREHOUSES)
set workers $::env(BENCH_LOAD_WORKERS)
dbset db mysql
dbset bm TPC-C
diset connection mysql_host 127.0.0.1
diset connection mysql_port 3307
diset connection mysql_socket null
diset tpcc mysql_user bench
diset tpcc mysql_pass bench
diset tpcc mysql_dbase $db
diset tpcc mysql_count_ware $warehouses
diset tpcc mysql_num_vu $workers
diset tpcc mysql_storage_engine innodb
diset tpcc mysql_partition false
diset tpcc mysql_history_pk false
diset tpcc mysql_no_stored_procs false
print dict
puts "CAMPAIGN_LOAD_START [clock seconds]"
buildschema
puts "CAMPAIGN_LOAD_END [clock seconds]"
exit
