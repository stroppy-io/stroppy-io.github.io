#!/usr/bin/env python3
"""Continue only after successful calibration, then execute approved HammerDB cases."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')
CALIBRATION = ROOT / 'runs/tpcc-headtohead-20261028-hammerdb-local-original-calibration02'
while subprocess.run(['systemctl', 'is-active', '--quiet', 'bench-h2h-calibration-hammer02']).returncode == 0:
    time.sleep(10)
status = subprocess.check_output(['systemctl', 'show', 'bench-h2h-calibration-hammer02', '-p', 'ExecMainStatus', '--value'], text=True).strip()
if status != '0':
    raise SystemExit('calibration controller failed; inspect evidence')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/summarize.py'), str(CALIBRATION)], check=True)
samples = [json.loads(line) for line in (CALIBRATION / 'monitor/samples.jsonl').read_text().splitlines()]
valid = [row for row in samples if 'mysql' in row]
if len(valid) < 10:
    raise SystemExit('insufficient calibration samples')
first, last = valid[0], valid[-1]
for metric in ('Innodb_log_waits', 'Innodb_buffer_pool_wait_free'):
    if last['mysql'].get(metric, 0) != first['mysql'].get(metric, 0):
        raise SystemExit('calibration resource stall: ' + metric)
if min(row['host']['mem_kib']['MemAvailable'] for row in valid) < 64 * 1024**2:
    raise SystemExit('calibration memory headroom insufficient')
freeze = {'status': 'frozen_after_clean_calibration', 'configuration': str(ROOT / 'configs/mysql.cnf'), 'buffer_pool_gib': 512, 'redo_gib': 32, 'flush_at_commit': 1, 'io_capacity': 10000, 'io_capacity_max': 20000, 'calibration': str(CALIBRATION), 'changes_after_calibration': []}
(ROOT / 'configs/frozen-hammerdb.json').write_text(json.dumps(freeze, indent=2) + '\n')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/charts.py'), str(ROOT / 'runs'), str(ROOT / 'summaries/runtime.html')], check=True)
(ROOT / 'configs/ready-for-hammerdb-measurements.json').write_text(json.dumps(freeze, indent=2) + '\n')
print('Calibration passed; configuration frozen and ready for measured runs.')
