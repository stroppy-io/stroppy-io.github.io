#!/usr/bin/env bash
set -euo pipefail
root=/opt/stroppy-tpcc-headtohead-20261028
run="$root/runs/load-hammer-sf1000"
mkdir "$run"
exec 9>"$root/invocation.lock"
flock -n 9
printf '{"id":"load-hammer-sf1000","status":"running","started":"%s","warehouses":1000,"workers":16}\n' "$(date -u +%FT%TZ)" > "$run/meta.json"
export CAMPAIGN_ROOT="$root" BENCH_DATABASE=hammer_sf1000 BENCH_WAREHOUSES=1000 BENCH_LOAD_WORKERS=16
export LD_LIBRARY_PATH="$root/artifacts/mysql-client-lib/extracted/usr/lib/x86_64-linux-gnu"
cd "$root/artifacts/HammerDB-6.1"
set +e
./hammerdbcli auto "$root/scripts/hammerdb-build.tcl" > "$run/stdout.log" 2>&1
code=$?
set -e
status=failed
if [[ "$code" == 0 ]] && grep -q 'SCHEMA COMPLETE' "$run/stdout.log" && ! grep -Eq 'FINISHED FAILED|Error in Virtual User' "$run/stdout.log"; then status=completed; fi
jq --arg status "$status" --arg finished "$(date -u +%FT%TZ)" --argjson code "$code" '. + {status:$status,finished:$finished,exit_code:$code}' "$run/meta.json" > "$run/meta.tmp"
mv "$run/meta.tmp" "$run/meta.json"
[[ "$status" == completed ]]
