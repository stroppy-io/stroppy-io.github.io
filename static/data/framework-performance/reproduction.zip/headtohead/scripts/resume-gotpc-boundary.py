#!/usr/bin/env python3
"""Resume after verifying SDK connection cleanup errors occurred only at deadline."""
import datetime
import json
from pathlib import Path
import subprocess

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')
directory = ROOT / 'runs/tpcc-headtohead-20261028-go-tpc-local-stroppy-r1'
subprocess.run(['python3', '-I', str(ROOT / 'scripts/classify-sdk-gotpc.py'), str(directory)], check=True)
meta = json.loads((directory / 'meta.json').read_text())
backup = directory / 'meta-before-boundary-classification.json'
if backup.exists():
    raise SystemExit('already classified; review before invoking resume again')
backup.write_text(json.dumps(meta, indent=2) + '\n')
meta.update(measurement_valid_boundary_only=True, completion_classification=json.loads((directory / 'completion-classification.json').read_text()), classified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(directory / 'meta.json').write_text(json.dumps(meta, indent=2) + '\n')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/summarize.py'), str(directory)], check=True)
subprocess.run(['python3', '-I', str(ROOT / 'scripts/campaign.py'), 'go-tpc'], check=True)
(ROOT / 'configs/all-measurements-completed').write_text('Both approved matrices completed; timeout-boundary errors remain classified in raw evidence.\n')
subprocess.run(['python3', '-I', str(ROOT / 'scripts/charts.py'), str(ROOT / 'runs'), str(ROOT / 'summaries/runtime.html')], check=True)
subprocess.run(['bash', str(ROOT / 'scripts/restore-original.sh')], check=True)
