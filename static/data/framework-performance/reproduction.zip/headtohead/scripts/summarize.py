#!/usr/bin/env python3
"""Derive comparable external-window rates and retain every raw interval."""
import argparse
import csv
import datetime
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    args = parser.parse_args()
    spec = json.loads((args.run / 'spec.json').read_text())
    meta = json.loads((args.run / 'meta.json').read_text())
    start = meta['started_epoch']
    warmup = spec['warmup_seconds']
    end = warmup + spec['measurement_seconds']
    samples = []
    for line in (args.run / 'monitor/samples.jsonl').read_text().splitlines():
        row = json.loads(line)
        row['elapsed'] = datetime.datetime.fromisoformat(row['utc']).timestamp() - start
        if 'new_orders' in row and 'mysql' in row:
            samples.append(row)
    points = []
    for previous, current in zip(samples, samples[1:]):
        seconds = current['monotonic'] - previous['monotonic']
        if seconds <= 0:
            continue
        values = {name: current['mysql'].get(name, 0) - previous['mysql'].get(name, 0) for name in ('Com_commit', 'Com_rollback', 'Innodb_os_log_written', 'Innodb_buffer_pool_reads', 'Innodb_buffer_pool_read_requests', 'Innodb_row_lock_waits', 'Innodb_row_lock_time')}
        points.append({'elapsed': current['elapsed'], 'seconds': seconds, 'new_orders_per_second': (current['new_orders'] - previous['new_orders']) / seconds, 'commits_per_second': values['Com_commit'] / seconds, 'rollbacks_per_second': values['Com_rollback'] / seconds, 'transactions_per_second': (values['Com_commit'] + values['Com_rollback']) / seconds, 'redo_bytes_per_second': values['Innodb_os_log_written'] / seconds, 'physical_reads_per_second': values['Innodb_buffer_pool_reads'] / seconds, 'row_lock_waits_per_second': values['Innodb_row_lock_waits'] / seconds, 'client_sessions': sum(1 for session in current.get('sessions', []) if session.startswith('bench\t')), 'db_rss_kib': (current.get('mysql.pid') or {}).get('rss_kib'), 'available_kib': current['host']['mem_kib']['MemAvailable']})
    with (args.run / 'runtime.csv').open('w') as output:
        fields = list(points[0]) if points else ['elapsed']
        writer = csv.DictWriter(output, fields)
        writer.writeheader()
        writer.writerows(points)
    measured = [row for row in samples if warmup <= row['elapsed'] <= end]
    result = {'id': spec['id'], 'family': spec['family']['name'], 'engine': spec['engine'], 'placement': spec['placement']['name'], 'repetition': spec['repetition'], 'client_status': meta['status'], 'valid': False, 'warmup_seconds': warmup, 'planned_measurement_seconds': spec['measurement_seconds'], 'sample_errors': sum('sample_error' in json.loads(line) for line in (args.run / 'monitor/samples.jsonl').read_text().splitlines())}
    if len(measured) >= 2:
        first, last = measured[0], measured[-1]
        seconds = last['monotonic'] - first['monotonic']
        committed_orders = last['new_orders'] - first['new_orders']
        commits = last['mysql']['Com_commit'] - first['mysql']['Com_commit']
        rollbacks = last['mysql']['Com_rollback'] - first['mysql']['Com_rollback']
        runtime_points = [row for row in points if warmup <= row['elapsed'] <= end]
        minimum_sessions = min((row['client_sessions'] for row in runtime_points), default=0)
        result.update(actual_measurement_seconds=seconds, first_utc=first['utc'], last_utc=last['utc'], committed_new_orders=committed_orders, commits=commits, rollbacks=rollbacks, new_orders_per_second=committed_orders / seconds, nopm=60 * committed_orders / seconds, transactions_per_second=(commits + rollbacks) / seconds, tpm=60 * (commits + rollbacks) / seconds, minimum_client_sessions=minimum_sessions)
        expected_sessions = spec['active_clients'] + (1 if spec['family']['name'] == 'hammerdb' else 0)
        result['expected_client_sessions'] = expected_sessions
        completion_ok = meta['status'] == 'completed' or meta.get('measurement_valid_boundary_only', False)
        result['valid'] = completion_ok and seconds >= spec['measurement_seconds'] - 12 and minimum_sessions >= expected_sessions and committed_orders > 0 and result['sample_errors'] == 0 and len(runtime_points) >= spec['measurement_seconds'] // 5 - 3 and max(row['seconds'] for row in runtime_points) < 12
        if not result['valid']:
            result['validation_note'] = 'Review client/session count, interval gaps, sample errors, and measured duration; do not silently retry.'
        if 'errors' in meta and meta['errors'] and meta['errors'].get('terminal_errors', 0):
            if not meta.get('measurement_valid_boundary_only'):
                result['valid'] = False
                result['validation_note'] = 'Client reported terminal errors.'
            else:
                result['boundary_error_classification'] = meta['completion_classification']
                result['validation_note'] = 'Steady measurement valid; raw client report retains deadline operation/cleanup errors.'
        if meta.get('measurement_valid_boundary_only'):
            result['clean_full_run'] = False
        else:
            result['clean_full_run'] = meta['status'] == 'completed'
        if meta.get('completion_classification', {}).get('boundary_query_errors', 0):
            result['clean_full_run'] = False
            result['native_completion_classification'] = meta['completion_classification']
        result['boundary_operation_errors'] = meta.get('completion_classification', {}).get('boundary_failed_operations', meta.get('completion_classification', {}).get('boundary_query_errors', 0))
        result['boundary_cleanup_errors'] = meta.get('completion_classification', {}).get('boundary_terminal_cleanup_errors', 0)
        result['unexpected_in_window_errors_verified'] = not result.get('native_errors') and meta['status'] == 'completed'
        if meta.get('measurement_valid_boundary_only'):
            result['unexpected_in_window_errors_verified'] = True
        result['native_errors'] = meta.get('errors')
        if not completion_ok:
            result['valid'] = False
        if result.get('boundary_error_classification') and not result['boundary_error_classification'].get('measurement_valid'):
            result['valid'] = False
            result['validation_note'] = 'Boundary classifier did not verify steady measurement.'
        result['completion_scope'] = 'steady window and full-run completion classified separately'
        result['sample_intervals'] = len(runtime_points)
        result['maximum_sample_interval_seconds'] = max(row['seconds'] for row in runtime_points) if runtime_points else None
        result['new_order_metric_scope'] = 'committed district counter progress; native logical success may include expected rollback'
        result['mysql_tpm_scope'] = 'global Com_commit+Com_rollback deltas, including identical observers'
        result['window_alignment'] = 'complete sample intervals after client process warmup; actual timestamps retained'
    (args.run / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    if not result['valid']:
        raise SystemExit('measurement does not satisfy the agreed validity gates')


if __name__ == '__main__':
    main()
