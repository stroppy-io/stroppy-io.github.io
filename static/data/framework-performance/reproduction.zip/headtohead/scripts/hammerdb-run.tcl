set root $::env(CAMPAIGN_ROOT)
set db $::env(BENCH_DATABASE)
set host $::env(BENCH_HOST)
set clients $::env(BENCH_CLIENTS)
set rampup $::env(BENCH_RAMPUP_MINUTES)
set duration $::env(BENCH_DURATION_MINUTES)
dbset db mysql
dbset bm TPC-C
diset connection mysql_host $host
diset connection mysql_port 3307
diset connection mysql_socket null
diset tpcc mysql_user bench
diset tpcc mysql_pass bench
diset tpcc mysql_dbase $db
diset tpcc mysql_driver timed
diset tpcc mysql_rampup $rampup
diset tpcc mysql_duration $duration
diset tpcc mysql_total_iterations 2147483647
diset tpcc mysql_raiseerror true
diset tpcc mysql_prepared false
diset tpcc mysql_keyandthink false
diset tpcc mysql_allwarehouse false
diset tpcc mysql_timeprofile false
diset tpcc mysql_async_scale false
diset tpcc mysql_connect_pool false
diset tpcc mysql_no_stored_procs false
loadscript
savescript $::env(BENCH_RUN_DIR)/driver.tcl
vuset vu $clients
vuset delay 500
vuset repeat 0
vuset timestamps 1
print vuconf
print dict
vucreate
puts "CAMPAIGN_CLIENT_START [clock seconds]"
set jobid [vurun]
puts "CAMPAIGN_CLIENT_END [clock seconds] JOB=$jobid"
print vustatus
vudestroy
exit
