#!/usr/bin/env python3
"""Summarize completed paired measurements without treating missing cases as success."""
import argparse
import csv
import json
from pathlib import Path
import statistics


def write_csv(path, rows):
    if not rows:
        return
    with path.open('w') as output:
        fields = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(output, fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    args = parser.parse_args()
    output = args.root / 'summaries'
    output.mkdir(exist_ok=True)
    cases = []
    for path in sorted((args.root / 'runs/bm1').glob('*/summary.json')):
        row = json.loads(path.read_text())
        if row.get('repetition', 0) > 0:
            meta = json.loads((path.parent / 'meta.json').read_text())
            classification = meta.get('completion_classification', {})
            row.setdefault('boundary_operation_errors', classification.get('boundary_failed_operations', classification.get('boundary_query_errors', 0)))
            row.setdefault('boundary_cleanup_errors', classification.get('boundary_terminal_cleanup_errors', 0))
            row['clean_full_run'] = meta['status'] == 'completed' and not row['boundary_operation_errors'] and not row['boundary_cleanup_errors']
            cases.append(row)
    write_csv(output / 'cases.csv', cases)
    pairs = []
    for family in ('hammerdb', 'go-tpc'):
        for placement in ('local', 'private_lan'):
            for repetition in (1, 2):
                selected = {row['engine']: row for row in cases if row['family'] == family and row['placement'] == placement and row['repetition'] == repetition and row.get('valid')}
                if set(selected) != {'original', 'stroppy'}:
                    continue
                original = selected['original']['new_orders_per_second']
                sdk = selected['stroppy']['new_orders_per_second']
                pairs.append({'family': family, 'placement': placement, 'repetition': repetition, 'original_new_orders_per_second': original, 'sdk_new_orders_per_second': sdk, 'sdk_over_original': sdk / original, 'sdk_change_percent': 100 * (sdk / original - 1)})
    write_csv(output / 'pairs.csv', pairs)
    complete = len(cases) == 16 and all(row.get('valid') for row in cases) and len(pairs) == 8
    report = {'status': 'complete' if complete else 'in_progress_or_incomplete', 'valid_cases': sum(row.get('valid', False) for row in cases), 'planned_cases': 16, 'completed_pairs': len(pairs), 'pairs': pairs, 'groups': []}
    for family in ('hammerdb', 'go-tpc'):
        for placement in ('local', 'private_lan'):
            selected = [row for row in pairs if row['family'] == family and row['placement'] == placement]
            if selected:
                report['groups'].append({'family': family, 'placement': placement, 'repetitions': len(selected), 'original_median_new_orders_per_second': statistics.median(row['original_new_orders_per_second'] for row in selected), 'sdk_median_new_orders_per_second': statistics.median(row['sdk_new_orders_per_second'] for row in selected), 'paired_ratio_median': statistics.median(row['sdk_over_original'] for row in selected), 'paired_ratio_min': min(row['sdk_over_original'] for row in selected), 'paired_ratio_max': max(row['sdk_over_original'] for row in selected)})
    lines = ['# TPC-C head-to-head results', '', f"Status: **{report['status']}** — {report['valid_cases']}/16 valid measured cases, {len(pairs)}/8 paired comparisons.", '', 'Rates below are committed district-counter New-Order progress over complete external sample intervals after five-minute warm-up. Each planned measurement lasts ten minutes; actual complete sample window is retained per case. Native logical operations may include expected rollback and are not substituted for committed progress.', '', 'Two repetitions are an order/spread check, not a confidence interval. MySQL is single-node, binlog-off, durable InnoDB commit flushing. Workload families have different SQL and must not be ranked against each other. Local/private-LAN contrasts include co-location effects, not pure additive network cost.', '']
    for group in report['groups']:
        lines += [f"## {group['family']} / {group['placement']}", '', f"Original median: {group['original_median_new_orders_per_second']:,.1f} committed New-Orders/s. SDK median: {group['sdk_median_new_orders_per_second']:,.1f}/s. Median paired SDK/original ratio: {group['paired_ratio_median']:.4f}; range {group['paired_ratio_min']:.4f}–{group['paired_ratio_max']:.4f}; n={group['repetitions']}.", '']
    boundary = [row for row in cases if row.get('boundary_operation_errors', 0) or row.get('boundary_cleanup_errors', 0)]
    lines += ['## Timeout-boundary errors', '', f'{len(boundary)} cases retain budget-boundary operation/cleanup failures. A valid steady window is not a clean full run. Original go-tpc timeout histograms and SDK completed-with-errors JSON remain unchanged; classifiers require all workers present through measurement and timestamp/count reconciliation at the deadline. In-window failures remain invalid.', '']
    for row in boundary:
        lines.append(f"- {row['id']}: boundary operations={row.get('boundary_operation_errors', 0)}, cleanup={row.get('boundary_cleanup_errors', 0)}, raw status={row.get('client_status')}")
    lines += ['', '## Evidence and limits', '', 'See cases.csv, pairs.csv, runtime.html, per-run raw samples/stdout/stderr, frozen configs, physical snapshot/restore hash manifests, binary checksums and build metadata. Initial failed smokes/auth calibration remain excluded but retained. Reusable SDK prepared-statement gap remains open; this is a complete client-path comparison. Final report is not a blog publication or an audited TPC result.', '']
    report['boundary_error_cases'] = [{'id': row['id'], 'operation_errors': row.get('boundary_operation_errors', 0), 'cleanup_errors': row.get('boundary_cleanup_errors', 0), 'raw_status': row.get('client_status')} for row in boundary]
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')

    (output / 'results.md').write_text('\n'.join(lines))
    print(json.dumps({'status': report['status'], 'valid_cases': report['valid_cases'], 'pairs': len(pairs)}))


if __name__ == '__main__':
    main()
