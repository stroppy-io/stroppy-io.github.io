#!/usr/bin/env python3
"""Run approved, pre-existing case specifications sequentially; stop on any invalid case."""
import argparse
import json
from pathlib import Path
import subprocess

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('family', choices=['hammerdb', 'go-tpc'])
    args = parser.parse_args()
    for path in sorted((ROOT / 'specs/matrix-proposed').glob('*.json')):
        spec = json.loads(path.read_text())
        if spec['family']['name'] != args.family:
            continue
        directory = ROOT / 'runs' / spec['id']
        if directory.exists():
            summary = directory / 'summary.json'
            if summary.exists() and json.loads(summary.read_text()).get('valid'):
                continue
            raise RuntimeError('existing non-validated run requires diagnosis: ' + spec['id'])
        subprocess.run(['python3', '-I', str(ROOT / 'scripts/run-case.py'), str(path)], check=True)
        subprocess.run(['python3', '-I', str(ROOT / 'scripts/summarize.py'), str(directory)], check=True)
        subprocess.run(['python3', '-I', str(ROOT / 'scripts/charts.py'), str(ROOT / 'runs'), str(ROOT / 'summaries/runtime.html')], check=True)
        summaries = []
        for summary in sorted((ROOT / 'runs').glob('*/summary.json')):
            value = json.loads(summary.read_text())
            if value.get('repetition', 0) > 0:
                summaries.append(value)
        (ROOT / 'summaries/results.json').write_text(json.dumps(summaries, indent=2) + '\n')
        (ROOT / 'STATUS-RUNTIME.json').write_text(json.dumps({'last_completed': spec['id'], 'valid_measured_cases': sum(value.get('valid', False) for value in summaries), 'target_cases': 16}, indent=2) + '\n')


if __name__ == '__main__':
    main()
