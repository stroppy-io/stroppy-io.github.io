#!/usr/bin/env python3
"""Load the second family only after every first-family measurement validated."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')
for path in sorted((ROOT / 'specs/matrix-proposed').glob('*.json')):
    spec = json.loads(path.read_text())
    if spec['family']['name'] != 'hammerdb':
        continue
    summary = ROOT / 'runs' / spec['id'] / 'summary.json'
    while not summary.exists():
        state = subprocess.check_output(['systemctl', 'show', 'bench-h2h-hammer-measurements', '-p', 'ActiveState', '--value'], text=True).strip()
        if state not in ('active', 'activating'):
            raise SystemExit('first-family campaign stopped before all valid cases')
        time.sleep(15)
    if not json.loads(summary.read_text()).get('valid'):
        raise SystemExit('first-family run invalid')
# Keep pristine HammerDB snapshot; remove only its working schema while preparing the next independent family.
subprocess.run(['mysql', '--socket=' + str(ROOT / 'mysql.sock'), '-e', 'DROP DATABASE hammer_sf1000'], check=True)
monitor_dir = ROOT / 'logs/gotpc-load-monitor'
monitor_dir.mkdir(exist_ok=False)
monitor = subprocess.Popen(['taskset', '-c', '56-59', 'python3', '-I', str(ROOT / 'scripts/sampler.py'), str(monitor_dir), '--interval=10'])
try:
    subprocess.run(['taskset', '-c', '24-31', 'bash', str(ROOT / 'scripts/load-gotpc.sh')], check=True)
finally:
    monitor.terminate()
    monitor.wait(timeout=20)
subprocess.run(['python3', '-I', str(ROOT / 'scripts/validate-population.py'), 'gotpc_sf1000', str(ROOT / 'runs/load-gotpc-sf1000/population.json')], check=True)
subprocess.run(['python3', '-I', str(ROOT / 'scripts/snapshot.py'), 'save', 'go-tpc', str(ROOT / 'snapshots/gotpc-pristine')], check=True)
(ROOT / 'configs/ready-for-gotpc-calibration').write_text('population and full cold snapshot validated\n')
