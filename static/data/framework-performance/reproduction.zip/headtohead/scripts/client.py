#!/usr/bin/env python3
"""Execute one frozen client specification and preserve exact command, timing, and exit state."""
import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/opt/stroppy-tpcc-headtohead-20261028')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('spec', type=Path)
    args = parser.parse_args()
    spec = json.loads(args.spec.read_text())
    directory = ROOT / 'runs' / spec['id']
    directory.mkdir(exist_ok=False)
    save(directory / 'spec.json', spec)
    family, engine = spec['family']['name'], spec['engine']
    db, host = spec['database'], spec['placement']['database_host']
    env = os.environ.copy()
    env.update({'GOMAXPROCS': '8', 'HOME': str(ROOT / 'homes' / spec['id'])})
    Path(env['HOME']).mkdir(parents=True)
    duration = spec['warmup_seconds'] + spec['measurement_seconds']
    clients = spec['active_clients']
    cwd = directory
    if engine == 'original' and family == 'hammerdb':
        env.update({'LD_LIBRARY_PATH': str(ROOT / 'artifacts/mysql-client-lib/extracted/usr/lib/x86_64-linux-gnu'), 'CAMPAIGN_ROOT': str(ROOT), 'BENCH_RUN_DIR': str(directory), 'BENCH_DATABASE': db, 'BENCH_HOST': host, 'BENCH_CLIENTS': str(clients), 'BENCH_RAMPUP_MINUTES': str(spec['warmup_seconds'] // 60), 'BENCH_DURATION_MINUTES': str(spec['measurement_seconds'] // 60), 'TMP': str(directory)})
        cwd = ROOT / 'artifacts/HammerDB-6.1'
        command = ['./hammerdbcli', 'auto', str(ROOT / 'scripts/hammerdb-run.tcl')]
    elif engine == 'original':
        command = [str(ROOT / 'artifacts/go-tpc'), '-d', 'mysql', '-H', host, '-P', '3307', '-U', 'bench', '-p', 'bench', '-D', db, '-T', str(clients), '--time', f'{duration}s', '--isolation', '2', '--count', '0', '--max-procs', '8', '--interval', '10s', 'tpcc', '--warehouses', '1000', 'run', '--weight', '45,43,4,4,4', '--wait=false', '--ignore-error=false']
    else:
        command = [str(ROOT / 'artifacts/stroppy'), 'run', spec['family']['sdk_workload'], '-d', 'mysql', '-D', f'url=bench:bench@tcp({host}:3307)/{db}?parseTime=true', '-D', f'sql.maxOpenConns={clients+1}', '-D', f'sql.maxIdleConns={clients+1}', '--vus', str(clients), '--log-level', 'warn', '--report-file', str(directory / 'report.json')]
        if family == 'hammerdb':
            command += ['--mode=timed', f'--rampup={spec["warmup_seconds"]}s', f'--duration={spec["measurement_seconds"]}s', '--iterations=2147483647', '--prepared=false', '--keyandthink=false', '--allwarehouse=false', '--async-scale=false', '--raiseerror=true']
        else:
            command += ['--warehouses=1000', '--weight=45,43,4,4,4', '--wait=false', '--isolation=2', '--ignore-error=false', '--count=0', f'--duration={duration}s', '--seed=0', '--conn-refresh-interval=0s']
    metadata = {'id': spec['id'], 'status': 'waiting', 'command': command, 'cwd': str(cwd), 'environment': {key: value for key, value in env.items() if key in ('GOMAXPROCS', 'HOME', 'LD_LIBRARY_PATH', 'CAMPAIGN_ROOT', 'BENCH_RUN_DIR', 'BENCH_DATABASE', 'BENCH_HOST', 'BENCH_CLIENTS', 'BENCH_RAMPUP_MINUTES', 'BENCH_DURATION_MINUTES', 'TMP')}, 'scheduled_start_epoch': spec['start_epoch'], 'prepared_utc': utc()}
    save(directory / 'meta.json', metadata)
    preflight = subprocess.run(['mysql', '-h', host, '-P', '3307', '-u', 'bench', '--password=bench', '--get-server-public-key', '-N', '-B', '-e', 'SELECT @@version,@@transaction_isolation'], capture_output=True, text=True, timeout=15)
    (directory / 'authentication-preflight.stdout').write_text(preflight.stdout)
    (directory / 'authentication-preflight.stderr').write_text(preflight.stderr)
    if preflight.returncode != 0:
        metadata.update(status='preflight_failed', exit_code=preflight.returncode)
        save(directory / 'meta.json', metadata)
        raise SystemExit('MySQL authentication preflight failed')
    while time.time() < spec['start_epoch']:
        time.sleep(min(0.2, spec['start_epoch'] - time.time()))
    metadata.update(status='running', started_utc=utc(), started_epoch=time.time(), started_monotonic=time.monotonic())
    save(directory / 'meta.json', metadata)
    with (directory / 'stdout.log').open('x') as stdout, (directory / 'stderr.log').open('x') as stderr:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
        (directory / 'client.pid').write_text(str(process.pid))
        try:
            code = process.wait(timeout=duration + 180)
        except subprocess.TimeoutExpired:
            process.send_signal(signal.SIGTERM)
            try:
                code = process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()
                code = process.wait()
            metadata['watchdog_expired'] = True
    metadata.update(status='completed' if code == 0 else 'failed', exit_code=code, finished_utc=utc(), finished_epoch=time.time())
    if (directory / 'report.json').exists():
        report = json.loads((directory / 'report.json').read_text())
        metadata['errors'] = report.get('errors')
        metadata['workload_reports'] = report.get('workload_reports')
        if report.get('errors', {}).get('terminal_errors', 0):
            metadata['status'] = 'completed_with_errors'
    text = (directory / 'stdout.log').read_text(errors='replace') + (directory / 'stderr.log').read_text(errors='replace')
    if engine == 'original' and family == 'hammerdb':
        metadata['native_result_present'] = 'TEST RESULT :' in text
        if 'FINISHED FAILED' in text or 'Error in Virtual User' in text or 'TEST RESULT :' not in text:
            metadata['status'] = 'invalid'
        if code != 0:
            metadata['status'] = 'failed'
    if engine == 'original' and family == 'go-tpc':
        save(directory / 'meta.json', metadata)
        classification = subprocess.run(['python3', '-I', str(ROOT / 'scripts/classify-gotpc.py'), str(directory)], capture_output=True, text=True)
        metadata['completion_classification'] = json.loads((directory / 'completion-classification.json').read_text())
        if classification.returncode != 0:
            metadata['status'] = 'invalid'
    if engine == 'stroppy' and family == 'go-tpc' and metadata['status'] == 'completed_with_errors':
        metadata['requires_server_boundary_classification'] = True
    save(directory / 'meta.json', metadata)
    raise SystemExit(0 if metadata['status'] == 'completed' or metadata.get('requires_server_boundary_classification') else 1)


if __name__ == '__main__':
    main()
