#!/usr/bin/env python3
"""Keep campaign evidence current locally and stop on external completion or failure."""
import argparse
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
KEY = '/Users/ariel/.ssh/ssh-key-postgres-august'
HOST = 'root@185.184.128.203'
REMOTE = '/opt/stroppy-tpcc-headtohead-20261028'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=int, default=43200)
    parser.add_argument('--until-pairs', type=int, default=0)
    args = parser.parse_args()
    started = time.monotonic()
    seen = set()
    while time.monotonic()-started < args.seconds:
        probe = subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','-i',KEY,HOST,f"find {REMOTE}/runs -maxdepth 2 -name summary.json -printf '%h\\n'; systemctl show bench-h2h-hammer-measurements bench-h2h-next-family bench-h2h-gotpc-boundary-resume -p Id -p ActiveState -p ExecMainStatus; test ! -f {REMOTE}/cleanup/complete.json || printf 'CAMPAIGN_RESTORED\\n'"],capture_output=True,text=True,timeout=60)
        if probe.returncode:
            print('Remote observation unavailable; preserving existing work and retrying',flush=True)
            time.sleep(120);continue
        lines = probe.stdout.splitlines()
        completed = {line for line in lines if line.startswith(REMOTE+'/runs/') and 'calibration' not in line}
        if completed-seen or 'CAMPAIGN_RESTORED' in lines or 'ActiveState=failed' in lines:
            subprocess.run(['bash',str(ROOT/'scripts/sync.sh')],check=True)
            seen |= completed
            print(json.dumps({'valid_summaries_seen':len(completed),'new':sorted(completed),'states':[line for line in lines if not line.startswith('/')]}),flush=True)
            results = json.loads((ROOT/'summaries/results.json').read_text())
            if args.until_pairs and results['completed_pairs'] >= args.until_pairs:
                return
        if 'ActiveState=failed' in lines:
            raise SystemExit('Campaign supervisor failed; inspect preserved evidence before retry')
        if 'CAMPAIGN_RESTORED' in lines:
            subprocess.run(['python3','-I',str(ROOT/'scripts/report.py'),str(ROOT)],check=True)
            return
        time.sleep(120)
    raise SystemExit('Local watch deadline reached; remote work is not canceled')


if __name__ == '__main__':
    main()
