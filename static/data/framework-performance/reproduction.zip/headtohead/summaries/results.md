# TPC-C head-to-head results

Status: **complete** — 16/16 valid measured cases, 8/8 paired comparisons.

Rates below are committed district-counter New-Order progress over complete external sample intervals after five-minute warm-up. Each planned measurement lasts ten minutes; actual complete sample window is retained per case. Native logical operations may include expected rollback and are not substituted for committed progress.

Two repetitions are an order/spread check, not a confidence interval. MySQL is single-node, binlog-off, durable InnoDB commit flushing. Workload families have different SQL and must not be ranked against each other. Local/private-LAN contrasts include co-location effects, not pure additive network cost.

## hammerdb / local

Original median: 10,141.4 committed New-Orders/s. SDK median: 10,039.1/s. Median paired SDK/original ratio: 0.9900; range 0.9764–1.0036; n=2.

## hammerdb / private_lan

Original median: 9,760.1 committed New-Orders/s. SDK median: 9,588.4/s. Median paired SDK/original ratio: 0.9824; range 0.9823–0.9825; n=2.

## go-tpc / local

Original median: 6,442.8 committed New-Orders/s. SDK median: 3,847.1/s. Median paired SDK/original ratio: 0.5972; range 0.5896–0.6047; n=2.

## go-tpc / private_lan

Original median: 5,691.0 committed New-Orders/s. SDK median: 3,455.7/s. Median paired SDK/original ratio: 0.6073; range 0.6025–0.6120; n=2.

## Timeout-boundary errors

8 cases retain budget-boundary operation/cleanup failures. A valid steady window is not a clean full run. Original go-tpc timeout histograms and SDK completed-with-errors JSON remain unchanged; classifiers require all workers present through measurement and timestamp/count reconciliation at the deadline. In-window failures remain invalid.

- tpcc-headtohead-20261028-go-tpc-local-original-r1: boundary operations=32, cleanup=0, raw status=completed
- tpcc-headtohead-20261028-go-tpc-local-original-r2: boundary operations=30, cleanup=0, raw status=completed
- tpcc-headtohead-20261028-go-tpc-local-stroppy-r1: boundary operations=32, cleanup=27, raw status=completed_with_errors
- tpcc-headtohead-20261028-go-tpc-local-stroppy-r2: boundary operations=32, cleanup=27, raw status=completed_with_errors
- tpcc-headtohead-20261028-go-tpc-private_lan-original-r1: boundary operations=31, cleanup=0, raw status=completed
- tpcc-headtohead-20261028-go-tpc-private_lan-original-r2: boundary operations=30, cleanup=0, raw status=completed
- tpcc-headtohead-20261028-go-tpc-private_lan-stroppy-r1: boundary operations=30, cleanup=22, raw status=completed_with_errors
- tpcc-headtohead-20261028-go-tpc-private_lan-stroppy-r2: boundary operations=32, cleanup=30, raw status=completed_with_errors

## Evidence and limits

See cases.csv, pairs.csv, runtime.html, per-run raw samples/stdout/stderr, frozen configs, physical snapshot/restore hash manifests, binary checksums and build metadata. Initial failed smokes/auth calibration remain excluded but retained. Reusable SDK prepared-statement gap remains open; this is a complete client-path comparison. Final report is not a blog publication or an audited TPC result.
