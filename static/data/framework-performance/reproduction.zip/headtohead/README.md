# TPC-C head-to-head evidence — 2026-10-28

This directory contains measurement evidence and reproduction materials, not a database backup or a published benchmark article. See [current status](STATUS.md) and [paired results](summaries/results.md). A result is final only when `summaries/results.json` reports all 16 valid steady-window cases and eight pairs; service/key cleanup and archive verification are separate completion checks.

## Read the results

- [Offline runtime charts](summaries/runtime.html): family, placement and repetition filters; light/dark modes; distinct line patterns; tooltips and sample tables. No network access needed.
- [Results JSON](summaries/results.json), [case CSV](summaries/cases.csv), [paired CSV](summaries/pairs.csv).
- `runs/bm1/<case>/summary.json`: committed district-counter progress over actual complete measurement intervals, timestamps, session continuity and validity gates.
- `runs/bm1/<case>/meta.json`, `stdout.log`, `stderr.log`, `report.json` where available: commands, environment, process timing, exit status and unchanged native reports.
- `runs/bm1/<case>/monitor/samples.jsonl`: database/host/process counters sampled every five seconds. `runtime.csv` contains derived interval rates. Remote-client samples are under `client-monitor/`.
- `remote/bm1/restores/<case>/`: verified cold-restore records, effective MySQL variables and schema/routine definitions.
- `remote/bm1/manifests/`: physical-template file hashes, binary hashes and frozen configuration identity.
- `remote/bm1/runs/` also retains loaders, population validation, calibration and failed smokes. They are not additional measured repetitions.
- `remote/bm0/` retains original remote-client evidence. `runs/` and `remote/` intentionally contain overlapping copies; do not count them as separate runs.

Charts include warm-up, deadline and post-deadline samples where recorded. Shutdown drops are not steady-window throughput. Missing checkpoint counters in early cases mean unavailable data, not zero checkpoint age. Network/disk graphs show whole-host counters, not transaction-level attribution.

## Comparison boundary

Two separate workload families:

- HammerDB v6.1 TPROC-C against Stroppy `hammerdb-tpcc`: original stored-procedure workload, 10:10:1:1:1 transaction mix.
- Unmodified pingcap/go-tpc commit `a9ca4818625deef91ff80f6c395a575ccae22b7c` against Stroppy `go-tpc-tpcc`: client-managed transactions, 45/43/4/4/4 mix.

Compare each original only with its own port. Schemas, generators and SQL differ between families. This is not a cross-family database ranking or audited TPC result.

Frozen Stroppy collection: personal-fork commit `5210a29a839979904f102298701505b7d62f44ae`, SDK v6.2.1. Exact downloads, binaries, build information and checksums are under `artifacts/`. Do not substitute a later `latest` artifact.

Native go-tpc has reusable `database/sql` prepared statements and connection handling not exposed by the tested SDK. The port uses the SDK query path; issue [#233](https://github.com/stroppy-io/stroppy/issues/233) tracks reusable session-scoped prepared handles. Results compare complete released client paths, not scheduler overhead alone. These measurements do not isolate the cause of any gap.

## Matched setup

- Two dual-socket EPYC 9374F hosts, 64 physical cores each, about 751 GiB RAM, Linux/Ubuntu versions and full topology recorded under `inventory/`.
- Database always bm1. Local client uses TCP `127.0.0.1:3307`; separate client bm0 uses private TCP `10.88.0.2:3307` over bonded 25 GbE links. No artificial latency or public database listener.
- Database: 48 physical cores `0-23,32-55`; each client: eight physical cores `24-31`; observers: `56-59`; Go `GOMAXPROCS=8`. NUMA memory interleaved. No extra SMT worker cores.
- MySQL 8.4.11, 512 GiB buffer pool, 16 buffer-pool instances, 32 GiB redo, 64 MiB log buffer, `O_DIRECT`, doublewrite/redo on, commit flushing `1`, binary logging off, READ-COMMITTED. Exact configuration: `configs/mysql.cnf` and per-case effective-variable snapshots.
- SF1000, 32 active unpaced clients, no added transaction retries, 300 seconds warm-up plus 600 seconds planned measurement. HammerDB adds one monitor connection.
- Two repetitions per engine/placement. Engine order reversed between repetitions. Only one client invocation active at a time.
- Original loader creates each family's independent SF1000 population. Full cold datadir template restored and file-hash verified before every calibration/measured invocation; buffer-pool dump/load disabled. Same idle settling and warm-up for paired clients.

Local versus private-LAN results include co-location, NUMA, cache and interrupt effects; they are not a pure additive network-latency experiment. Initial ICMP RTT is context, not SQL round-trip latency.

## Measurement and errors

Primary rate is `delta SUM(d_next_o_id) / monotonic seconds` over complete samples after warm-up and before the planned deadline. Five-second sampling normally yields a 595-second complete counter window inside the ten-minute budget. Exact timestamps and denominators remain in every summary. Global `Com_commit + Com_rollback` is secondary and includes identical observer overhead. Native full-run tpmC/NOPM summaries are not substituted for this post-warm-up rate.

Expected New-Order rollback is not a committed New-Order. All 32 worker sessions must remain present through measurement; sample gaps/errors and early worker failures invalidate a case.

Both go-tpc paths can fail in-flight work when their duration budget expires. Native timeout histograms and SDK `completed_with_errors` reports remain unchanged. `completion-classification.json` and pre-classification metadata retain the evidence used to distinguish steady-window validity from full-run errors. SDK deadline operation failures and connection-cleanup errors are separate counts, potentially overlapping; do not add them into a single transaction count. Valid steady windows must never be described as clean full runs.

Two repetitions show order/spread, not confidence intervals or statistical significance. Failed preparation/calibration attempts remain in the bundle, excluded from paired medians.

## Recompute locally

From any directory, pass this evidence root explicitly:

```bash
python3 -I /path/to/evidence/scripts/report.py /path/to/evidence
python3 -I /path/to/evidence/scripts/charts.py \
  /path/to/evidence/runs/bm1 /path/to/evidence/summaries/runtime.html
```

These commands regenerate derived reports/charts only. Preserve an immutable copy before changing a finalized bundle or its catalog. Per-case `summarize.py` also writes derived files; use it only on a working copy if reproducing calculations after archival.

## Reproduce on new infrastructure

Use `plans/execution-plan.md`, `plans/mysql-tuning-research.md`, frozen specifications, exact per-case command/environment metadata, generated HammerDB drivers and effective server configurations as the runbook. Use the pinned artifacts, not current upstream defaults. Provision independent empty campaign paths and private-only benchmark accounts, validate small-scale connectivity, load each original family, check population, create complete stopped-server templates, then follow the recorded restore/warm-up/order/measurement sequence.

The remote controllers under `scripts/` contain campaign-specific absolute paths, service names, credentials and destructive working-copy restoration. **Do not execute loaders, snapshot/restore scripts, old supervisors or service-restoration scripts against an existing installation unchanged.** Review and adapt them for a new isolated deployment. Never copy a live InnoDB datadir or point restoration at historical data/templates. Benchmark-only `bench` credentials in commands are not suitable for public or production access.

Original server datasets, rentals and historical frozen campaign evidence remain outside this bundle. Physical SF1000 templates remain on bm1; the laptop archive records their manifests, not the data files. Private SSH/control keys are excluded. Nothing here authorizes publishing results, destroying data or canceling machines.
