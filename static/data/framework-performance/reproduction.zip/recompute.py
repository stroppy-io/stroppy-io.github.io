#!/usr/bin/env python3
"""Verify rates and efficiency costs against the bundled raw counter windows."""
import datetime
import json
import math
from pathlib import Path
root = Path(__file__).resolve().parent
count = 0
for campaign in ['headtohead', 'no-reuse', 'client-efficiency']:
    for path in sorted((root/campaign/'runs').glob('*/summary.json')):
        summary = json.loads(path.read_text())
        meta = json.loads((path.parent/'meta.json').read_text())
        spec = json.loads((path.parent/'spec.json').read_text())
        rows = [json.loads(line) for line in (path.parent/'monitor/samples.jsonl').read_text().splitlines()]
        measured = [row for row in rows if 'mysql' in row and 'new_orders' in row and spec['warmup_seconds'] <= datetime.datetime.fromisoformat(row['utc']).timestamp()-meta['started_epoch'] <= spec['warmup_seconds']+spec['measurement_seconds']]
        first, last = measured[0], measured[-1]
        seconds = last['monotonic']-first['monotonic']
        orders = last['new_orders']-first['new_orders']
        assert orders == summary['committed_new_orders']
        assert math.isclose(orders/seconds, summary['new_orders_per_second'], rel_tol=1e-12), path
        if campaign == 'client-efficiency':
            for key, label in [('client.pid','client'), ('mysql.pid','database')]:
                ticks = sum(last[key][field]-first[key][field] for field in ['utime_ticks','stime_ticks'])
                cpu = ticks/last['clock_ticks_per_second']
                assert math.isclose(cpu, summary[label+'_cpu_seconds'], rel_tol=1e-12), path
        count += 1
assert count == 27
print(f'Verified {count} raw measurement windows and seven client/database CPU-cost pairs.')
